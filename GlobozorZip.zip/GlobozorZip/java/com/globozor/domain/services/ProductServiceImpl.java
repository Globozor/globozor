package com.globozor.domain.services;

import java.util.List;

import org.springframework.transaction.annotation.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.globozor.domain.entity.Product;
import com.globozor.domain.entity.SubCategory;
import com.globozor.domain.repository.ProductRepository;

@Service
@Transactional
public class ProductServiceImpl implements ProductService{

	@Autowired
	ProductRepository productRepository;
	
	@Override
	public List<Product> getProductBySubCategory(SubCategory subCategory) {
		return productRepository.findBySubCategory(subCategory);
	}
	
}
