package com.globozor.domain.services;

import com.globozor.domain.dtos.SellerDto;
import com.globozor.domain.entity.MasterTable;

public interface EntityDtoMapper {

	public SellerDto sellerEntityToDto(MasterTable masterTable);

}
