package com.globozor.domain.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.globozor.domain.dtos.SellerDto;
import com.globozor.domain.entity.AddressDetails;
import com.globozor.domain.entity.MasterTable;
import com.globozor.domain.entity.SellerProduct;
import com.globozor.domain.entity.SellerProductImage;

@Service
@Transactional
public class EntityDtoMapperImpl implements EntityDtoMapper{

	@Override
	public SellerDto sellerEntityToDto(MasterTable masterTable) {
		SellerDto sellerDto = new SellerDto();
		SellerProduct sellerProduct2 = new SellerProduct();
		List<String> sellerProductImages= new ArrayList<String>();
		String sellerProductImage = "";
		Set<SellerProduct> sellerProducts = masterTable.getSellerProducts();
		int priority=0;
		int count=0;
		for (SellerProduct sellerProduct : sellerProducts) {
			if(count==0){
				priority=sellerProduct.getPriority();
				sellerProduct2 = sellerProduct;
				count++;
			}else{
				if(sellerProduct.getPriority()<priority){
					priority=sellerProduct.getPriority();
					sellerProduct2 = sellerProduct;
				}
			}
		}
		
		Set<SellerProductImage> productImages = sellerProduct2.getSellerProductImage();
		for (SellerProductImage sellerProductImage2 : productImages) {
				sellerProductImage = sellerProductImage2.getFilePath();
				sellerProductImages.add(sellerProductImage);
		}
		sellerDto.setUnitPrice(sellerProduct2.getUnitPrice());
		sellerDto.setMinimumQuantity(sellerProduct2.getMinimumQuantity());
		sellerDto.setProductMaturity(sellerProduct2.getProductMaturity());
		sellerDto.setProductCertification(sellerProduct2.getProductCertification());
		sellerDto.setProductWeight(sellerProduct2.getProductWeight());
		sellerDto.setProductSize(sellerProduct2.getProductSize());
		sellerDto.setProductPlaceOfOrigin(sellerProduct2.getProductPlaceOfOrigin());
		sellerDto.setProductShape(sellerProduct2.getProductShape());
		sellerDto.setProductCultivationType(sellerProduct2.getProductCultivationType());
		sellerDto.setSellerProductDescription(sellerProduct2.getSellerProductDescription());
		sellerDto.setSellerProductName(sellerProduct2.getSellerProductName());
		sellerDto.setSellerProductImage(sellerProductImages);
		sellerDto.setSellerName(masterTable.getFirstName()+" "+masterTable.getMiddleName()+" "+masterTable.getLastName());
		Set<AddressDetails> addressDetails = masterTable.getAddressDetails();
		int count2 = 0;
		for (AddressDetails addressDetails2 : addressDetails) {
			if(count2==0){
				sellerDto.setSellerCountry(addressDetails2.getCountryLookup().getCountryName());
				count2++;
			}
		}
		sellerDto.setSellerMembershipType(masterTable.getSellerDescription().getMembershipType().getMembershipTypeName());
		sellerDto.setVerified(masterTable.isVerified());
		sellerDto.setSellerCompanyName(masterTable.getCompanyName());
		sellerDto.setSellerTurnover(masterTable.getSellerDescription().getTurnover());
		return sellerDto;
	}

}
