package com.globozor.domain.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.globozor.domain.entity.Product;
import com.globozor.domain.entity.SubCategory;
import com.globozor.domain.services.ProductService;

@RestController
@RequestMapping("/product")
public class ProductController {

	@Autowired
	ProductService productService;
	
	@RequestMapping(value="getProduct")
	public List<Product> getProduct(@RequestParam long subCategoryId){
		SubCategory subCategory = new SubCategory();
		subCategory.setSubCategoryId(subCategoryId);
		return productService.getProductBySubCategory(subCategory);
	}
}