package com.globozor.domain.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Table(name="enquiry")
@Entity(name="enquiry")
public class Enquiry {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column
	private long enquiryId;
	
	@ManyToOne
	@JoinColumn(name="buyerId")
	private MasterTable buyer;
	
	@Column(name="subproductId")
	private long subProductId;
	
	@Column
	private long quantity;
	
	@Column
	private String unit;
	
	@Column
	private String enqiryDescription;
	
	@Column
	private String filepathAttachments;
	
	public long getEnquiryId() {
		return enquiryId;
	}

	public void setEnquiryId(long enquiryId) {
		this.enquiryId = enquiryId;
	}

	public MasterTable getBuyer() {
		return buyer;
	}

	public void setBuyer(MasterTable buyer) {
		this.buyer = buyer;
	}

	public long getSubProductId() {
		return subProductId;
	}

	public void setSubProductId(long subProductId) {
		this.subProductId = subProductId;
	}

	public long getQuantity() {
		return quantity;
	}

	public void setQuantity(long quantity) {
		this.quantity = quantity;
	}

	public String getUnit() {
		return unit;
	}

	public void setUnit(String unit) {
		this.unit = unit;
	}

	public String getEnqiryDescription() {
		return enqiryDescription;
	}

	public void setEnqiryDescription(String enqiryDescription) {
		this.enqiryDescription = enqiryDescription;
	}

	public String getFilepathAttachments() {
		return filepathAttachments;
	}

	public void setFilepathAttachments(String filepathAttachments) {
		this.filepathAttachments = filepathAttachments;
	}
	
}