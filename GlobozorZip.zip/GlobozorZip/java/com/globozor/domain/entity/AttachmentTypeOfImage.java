package com.globozor.domain.entity;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table
public class AttachmentTypeOfImage {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column
	private long attachmentTypeOfImageId;
	
	@Column
	private String attachmentDescription;
	
	@OneToMany(mappedBy="attachmentTypeOfImage")
	@JsonIgnore
	private List<Image> images;

	public long getAttachmentTypeOfImageId() {
		return attachmentTypeOfImageId;
	}

	public void setAttachmentTypeOfImageId(long attachmentTypeOfImageId) {
		this.attachmentTypeOfImageId = attachmentTypeOfImageId;
	}

	public String getAttachmentDescription() {
		return attachmentDescription;
	}

	public void setAttachmentDescription(String attachmentDescription) {
		this.attachmentDescription = attachmentDescription;
	}

	public List<Image> getImages() {
		return images;
	}

	public void setImages(List<Image> images) {
		this.images = images;
	}
	
}
