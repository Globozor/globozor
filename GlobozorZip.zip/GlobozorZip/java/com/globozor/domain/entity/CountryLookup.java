package com.globozor.domain.entity;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table
public class CountryLookup {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column
	private long countryLookupId;
	
	@Column
	private String countryName;
	
	@Column
	private String icoField;
	
	@Column
	private String extension;
	
	@OneToMany(mappedBy="countryLookup")
	private Set<StateLookup> stateLookupList;

	public String getExtension() {
		return extension;
	}

	public void setExtension(String extension) {
		this.extension = extension;
	}

	public long getCountryLookupId() {
		return countryLookupId;
	}

	public void setCountryLookupId(long countryLookupId) {
		this.countryLookupId = countryLookupId;
	}

	public String getCountryName() {
		return countryName;
	}

	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}

	public String getIcoField() {
		return icoField;
	}

	public void setIcoField(String icoField) {
		this.icoField = icoField;
	}

	public Set<StateLookup> getStateLookupList() {
		return stateLookupList;
	}

	public void setStateLookupList(Set<StateLookup> stateLookupList) {
		this.stateLookupList = stateLookupList;
	}

}
