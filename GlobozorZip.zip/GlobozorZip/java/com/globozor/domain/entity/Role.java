package com.globozor.domain.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class Role {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column
	private long roleId;
	
	@Column
	private String roleDescrition;

	public long getRoleId() {
		return roleId;
	}

	public void setRoleId(long roleId) {
		this.roleId = roleId;
	}

	public String getRoleDescrition() {
		return roleDescrition;
	}

	public void setRoleDescrition(String roleDescrition) {
		this.roleDescrition = roleDescrition;
	}
}
