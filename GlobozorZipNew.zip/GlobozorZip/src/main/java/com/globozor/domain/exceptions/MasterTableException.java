package com.globozor.domain.exceptions;

public class MasterTableException extends Exception {

	private static final long serialVersionUID = 1L;

	public MasterTableException() {
		super();
	}

	public MasterTableException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public MasterTableException(String message, Throwable cause) {
		super(message, cause);
	}

	public MasterTableException(String message) {
		super(message);
	}

	public MasterTableException(Throwable cause) {
		super(cause);
	}
}
