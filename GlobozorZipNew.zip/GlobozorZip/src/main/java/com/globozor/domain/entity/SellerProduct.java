package com.globozor.domain.entity;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Table(name="sellerProduct")
@Entity
public class SellerProduct {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long sellerProductId;
	
	@OneToOne
	@JoinColumn(name="subproductId")
	private SubProduct subProduct;
	
	@ManyToOne
	@JoinColumn(name="masterTableId")
	@JsonIgnore
	private MasterTable masterTable;
	
	@Column
	private String sellerProductName;
	
	@Column
	private String sellerProductDescription;
	
	@Column
	private long minimumQuantity;
	
	@Column	
	private long unitPrice;
	
	@Column
	private String productMaturity;

	@Column
	private String productCertification;
	
	@Column
	private String productWeight;
	
	@Column
	private String productSize;
	
	@Column
	private String productPlaceOfOrigin;
	
	@Column
	private String productShape;
	
	@Column
	private String productCultivationType;
	
	@Column
	private boolean isVerified;
	
	@Column
	private int priority;
	
	@OneToMany(mappedBy="sellerProduct",cascade=CascadeType.ALL)
	private Set<SellerProductImage> sellerProductImage;

	public long getSellerProductId() {
		return sellerProductId;
	}

	public void setSellerProductId(long sellerProductId) {
		this.sellerProductId = sellerProductId;
	}

	public SubProduct getSubProduct() {
		return subProduct;
	}

	public void setSubProduct(SubProduct subProduct) {
		this.subProduct = subProduct;
	}

	public MasterTable getMasterTable() {
		return masterTable;
	}

	public void setMasterTable(MasterTable masterTable) {
		this.masterTable = masterTable;
	}

	public String getSellerProductName() {
		return sellerProductName;
	}

	public void setSellerProductName(String sellerProductName) {
		this.sellerProductName = sellerProductName;
	}

	public String getSellerProductDescription() {
		return sellerProductDescription;
	}

	public void setSellerProductDescription(String sellerProductDescription) {
		this.sellerProductDescription = sellerProductDescription;
	}

	public long getMinimumQuantity() {
		return minimumQuantity;
	}

	public void setMinimumQuantity(long minimumQuantity) {
		this.minimumQuantity = minimumQuantity;
	}

	public long getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(long unitPrice) {
		this.unitPrice = unitPrice;
	}

	public Set<SellerProductImage> getSellerProductImage() {
		return sellerProductImage;
	}

	public void setSellerProductImage(Set<SellerProductImage> sellerProductImage) {
		this.sellerProductImage = sellerProductImage;
	}
	
	public String getProductMaturity() {
		return productMaturity;
	}

	public void setProductMaturity(String productMaturity) {
		this.productMaturity = productMaturity;
	}

	public String getProductCertification() {
		return productCertification;
	}

	public void setProductCertification(String productCertification) {
		this.productCertification = productCertification;
	}

	public String getProductWeight() {
		return productWeight;
	}

	public void setProductWeight(String productWeight) {
		this.productWeight = productWeight;
	}

	public String getProductSize() {
		return productSize;
	}

	public void setProductSize(String productSize) {
		this.productSize = productSize;
	}

	public String getProductPlaceOfOrigin() {
		return productPlaceOfOrigin;
	}

	public void setProductPlaceOfOrigin(String productPlaceOfOrigin) {
		this.productPlaceOfOrigin = productPlaceOfOrigin;
	}

	public String getProductShape() {
		return productShape;
	}

	public void setProductShape(String productShape) {
		this.productShape = productShape;
	}

	public String getProductCultivationType() {
		return productCultivationType;
	}

	public void setProductCultivationType(String productCultivationType) {
		this.productCultivationType = productCultivationType;
	}
	
	public boolean isVerified() {
		return isVerified;
	}

	public void setVerified(boolean isVerified) {
		this.isVerified = isVerified;
	}

	public int getPriority() {
		return priority;
	}

	public void setPriority(int priority) {
		this.priority = priority;
	}
}
