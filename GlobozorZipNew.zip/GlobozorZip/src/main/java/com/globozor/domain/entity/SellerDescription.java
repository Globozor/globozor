package com.globozor.domain.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Table(name="sellerDescription")
@Entity(name="sellerDescription")
public class SellerDescription {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long sellerDescriptionId;
	
	@Column
	private String descriptionAboutCompany;

	@Column
	private int establishment;
	
	@Column
	private long maximumCapacity;

	@Column
	private String turnover;

	@Column
	private String port;

	@Column
	private long numberOfEmployees;
	
	@Column
	private Date membershipStartDate;

	@OneToOne
	@JoinColumn(name="membershipTypeId")
	private MembershipType membershipType;
	
	@OneToOne
	@JoinColumn(name="masterTableId")
	@JsonIgnore
	private MasterTable masterTable;

	public long getSellerDescriptionId() {
		return sellerDescriptionId;
	}

	public void setSellerDescriptionId(long sellerDescriptionId) {
		this.sellerDescriptionId = sellerDescriptionId;
	}

	public String getDescriptionAboutCompany() {
		return descriptionAboutCompany;
	}

	public void setDescriptionAboutCompany(String descriptionAboutCompany) {
		this.descriptionAboutCompany = descriptionAboutCompany;
	}

	public int getEstablishment() {
		return establishment;
	}

	public void setEstablishment(int establishment) {
		this.establishment = establishment;
	}

	public long getMaximumCapacity() {
		return maximumCapacity;
	}

	public void setMaximumCapacity(long maximumCapacity) {
		this.maximumCapacity = maximumCapacity;
	}

	public String getTurnover() {
		return turnover;
	}

	public void setTurnover(String turnover) {
		this.turnover = turnover;
	}

	public String getPort() {
		return port;
	}

	public void setPort(String port) {
		this.port = port;
	}

	public long getNumberOfEmployees() {
		return numberOfEmployees;
	}

	public void setNumberOfEmployees(long numberOfEmployees) {
		this.numberOfEmployees = numberOfEmployees;
	}

	public MembershipType getMembershipType() {
		return membershipType;
	}

	public void setMembershipType(MembershipType membershipType) {
		this.membershipType = membershipType;
	}

	public MasterTable getMasterTable() {
		return masterTable;
	}

	public void setMasterTable(MasterTable masterTable) {
		this.masterTable = masterTable;
	}

	public Date getMembershipStartDate() {
		return membershipStartDate;
	}

	public void setMembershipStartDate(Date membershipStartDate) {
		this.membershipStartDate = membershipStartDate;
	}
}