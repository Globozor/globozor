package com.globozor.domain.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table
public class Image {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column
	private long imageId;
	
	@Column
	private String imageFilepath;

	@ManyToOne
	@JoinColumn(name="masterTableId")
	@JsonIgnore
	private MasterTable masterTable;
	
	@ManyToOne
	@JoinColumn(name="attachmentTypeOfImageId")
	private AttachmentTypeOfImage attachmentTypeOfImage;
	
	public long getImageId() {
		return imageId;
	}

	public void setImageId(long imageId) {
		this.imageId = imageId;
	}

	public String getImageFilepath() {
		return imageFilepath;
	}

	public void setImageFilepath(String imageFilepath) {
		this.imageFilepath = imageFilepath;
	}

	public MasterTable getMasterTable() {
		return masterTable;
	}

	public void setMasterTable(MasterTable masterTable) {
		this.masterTable = masterTable;
	}

	public AttachmentTypeOfImage getAttachmentTypeOfImage() {
		return attachmentTypeOfImage;
	}

	public void setAttachmentTypeOfImage(AttachmentTypeOfImage attachmentTypeOfImage) {
		this.attachmentTypeOfImage = attachmentTypeOfImage;
	}
}
