package com.globozor.domain.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.globozor.domain.entity.Category;
import com.globozor.domain.entity.SubCategory;
import com.globozor.domain.services.SubCategoryService;

@RestController
@RequestMapping("/subCategory")
public class SubCategoryController {

	@Autowired
	SubCategoryService subCategoryService;
	
	@RequestMapping(value="getProduct")
	public List<SubCategory> getProduct(@RequestParam long categoryId){
		Category category = new Category();
		category.setCategoryId(categoryId);
		return subCategoryService.getSubCategoryByCategory(category);
	}
}
