package com.globozor.domain.services;

import java.util.List;
import java.util.Set;

import com.globozor.domain.entity.Enquiry;
import com.globozor.domain.entity.MasterTable;
import com.globozor.domain.exceptions.MasterTableException;

public interface UserService {

	public MasterTable login(MasterTable masterTable) throws MasterTableException;
	public MasterTable signup(MasterTable masterTable) throws MasterTableException;
	public Object searchProduct(String searchProduct);
	public Set<MasterTable> searchSellers(Object object);
	public List<MasterTable> enquiryProduct(Enquiry enquiry);
	public Set<MasterTable> getSelectedSuppliers();
	public Set<MasterTable> getUserByRegion(String region , int roleId);
	public List<String> getResultList();
}
