package com.globozor.domain.controllers;

import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.globozor.domain.dtos.MasterTableDto;
import com.globozor.domain.dtos.SellerDto;
import com.globozor.domain.entity.Enquiry;
import com.globozor.domain.entity.MasterTable;
import com.globozor.domain.entity.SellerProduct;
import com.globozor.domain.entity.SubProduct;
import com.globozor.domain.exceptions.MasterTableException;
import com.globozor.domain.services.EntityDtoMapper;
import com.globozor.domain.services.UserService;

@RestController
@RequestMapping("/user")
public class UserController {

	@Autowired
	UserService userService;
	
	@Autowired
	EntityDtoMapper entityDtoMapper;
	
	@RequestMapping(value="/login",method=RequestMethod.POST)
	private MasterTable login(@RequestBody MasterTable masterTable){
		System.out.println("mastertable is "+masterTable);
		try {
			return userService.login(masterTable);
		} catch (MasterTableException e) {
			e.getMessage();
		}
		return masterTable;
	}
	
	/*@RequestMapping(value="/signup",method=RequestMethod.POST)
	private MasterTable signup(@RequestBody MasterTableDto masterTableDto){
		MasterTable masterTable = new MasterTable();
		try {
			masterTable = entityDtoMapper.masterTableDtoToEntity(masterTableDto);
			masterTable = userService.signup(masterTable);
		} catch (MasterTableException e) {
			e.printStackTrace();
		}
		System.out.println("master is "+masterTable);
		return masterTable;
	}*/
	
	@RequestMapping(value="/signup",method=RequestMethod.POST)
	private MasterTable signup(@RequestBody MasterTable masterTable){
		try {
			masterTable = userService.signup(masterTable);
		} catch (MasterTableException e) {
			e.printStackTrace();
		}
		System.out.println("master is "+masterTable);
		return masterTable;
	}
	
	@RequestMapping(value="/searchProduct",method=RequestMethod.GET)
	public Set<SellerDto> searchProduct(@RequestParam String searchProduct){
		Set<SellerDto> sellerDtos = new HashSet<SellerDto>();
		Object object = userService.searchProduct(searchProduct);
		Set<MasterTable> sellerList = userService.searchSellers(object);
		if(object instanceof SubProduct || object instanceof SellerProduct){
			for (MasterTable masterTable : sellerList) {
				//Set<SellerProduct> sellerProducts = masterTable.getSellerProducts();
				Iterator<SellerProduct> iterator = masterTable.getSellerProducts().iterator();
				//for (SellerProduct sellerProduct : sellerProducts) {
				while(iterator.hasNext()){
					SellerProduct sellerProduct = iterator.next();
					if(!(sellerProduct.getSellerProductName().equals(searchProduct))){
						iterator.remove();
					}
				}
				//}
			}
		}
		for (MasterTable masterTable : sellerList) {
			SellerDto sellerDto1 = entityDtoMapper.sellerEntityToDto(masterTable);
			sellerDtos.add(sellerDto1);
		}
		
		return sellerDtos;
	}
	
	@RequestMapping(value="/enquiryProduct",method=RequestMethod.POST)
	public List<MasterTable> enquiryProduct(@RequestBody Enquiry enquiry){

		/*try {
			emailSender.sendEmail();
		} catch (MailException e) {
			e.printStackTrace();
		}*/
		/*try {
			sendOtpService.sendOtp();
		} catch (Exception e) {
			e.printStackTrace();
		}*/
		List<MasterTable> sellerList = userService.enquiryProduct(enquiry);
		return sellerList;
	}
	
	@RequestMapping(value="/getSelectedSuppliers")
	public Set<SellerDto> getSelectedSuppliers(){
		Set<SellerDto> sellerDtos = new HashSet<SellerDto>();
		Set<MasterTable> sellerList = userService.getSelectedSuppliers();
		for (MasterTable masterTable : sellerList) {
			SellerDto sellerDto1 = entityDtoMapper.sellerEntityToDto(masterTable);
			sellerDtos.add(sellerDto1);
		}
		
		return sellerDtos;
	}
	
	@RequestMapping(value="/getSuppliersByRegion") 
	public Set<SellerDto> getSuppliersByRegion(@RequestParam String region){
		Set<SellerDto> sellerDtos = new HashSet<SellerDto>();
		Set<MasterTable> sellerList = userService.getUserByRegion(region , 2);
		for (MasterTable masterTable : sellerList) {
			SellerDto sellerDto1 = entityDtoMapper.sellerEntityToDto(masterTable);
			sellerDtos.add(sellerDto1);
		}
		
		return sellerDtos;
	}
	
	@RequestMapping(value="/getBuyerByRegion")
	public Set<MasterTable> getBuyerByRegion(@RequestParam String region){
		return userService.getUserByRegion(region , 3);
	}
	
	@RequestMapping(value="/getSearchList")
	public List<String> getSearchList(){
		return userService.getResultList();
	}
}
