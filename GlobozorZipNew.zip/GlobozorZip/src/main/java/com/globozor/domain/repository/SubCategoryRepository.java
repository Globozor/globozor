package com.globozor.domain.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.globozor.domain.entity.Category;
import com.globozor.domain.entity.SubCategory;

public interface SubCategoryRepository extends JpaRepository<SubCategory, Long>{

	public List<SubCategory> findByCategory(Category category);
	public SubCategory findBySubCategoryName(String subCategoryName);
	@Query("select s.subCategoryName from SubCategory s")
	public List<String> findSubCategoryNames();
}
