package com.globozor.domain.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.globozor.domain.entity.Product;
import com.globozor.domain.entity.SubProduct;
import com.globozor.domain.services.SubProductService;

@RestController
@RequestMapping("/subProduct")
public class SubProductController {

	@Autowired
	SubProductService subProductService;
	
	@RequestMapping(value="getProduct")
	public List<SubProduct> getProduct(@RequestParam long productId){
		Product product = new Product();
		product.setProductId(productId);
		return subProductService.getSubProductByProduct(product);
	}
}
