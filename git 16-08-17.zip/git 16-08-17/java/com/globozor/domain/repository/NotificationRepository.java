package com.globozor.domain.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.globozor.domain.entity.Notification;

public interface NotificationRepository extends JpaRepository<Notification, Long>{

	@Query("select n from Notification n where n.masterTable.masterTableId=?1 and n.isActive = true order by n.createdTime desc")
	public List<Notification> findAllNotifications(long masterTableId);

}
