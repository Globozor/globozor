package com.globozor.domain.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.globozor.domain.entity.SampleRequest;

public interface SampleRequestRepository extends JpaRepository<SampleRequest, Long>{

	@Query("select s from SampleRequest s where s.status=?2 and s.sellerEnquiryResponse.buyer.masterTableId=?1")
	public List<SampleRequest> findSampleByStatusBuyer(long masterTableId, String status);
	@Query("select s from SampleRequest s where s.status=?2 and s.sellerEnquiryResponse.seller.masterTableId=?1")
	public List<SampleRequest> findSampleByStatusSeller(long masterTableId,
			String status);

}
