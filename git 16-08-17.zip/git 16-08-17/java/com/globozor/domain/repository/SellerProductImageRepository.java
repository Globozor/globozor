package com.globozor.domain.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.globozor.domain.entity.SellerProductImage;

public interface SellerProductImageRepository extends JpaRepository<SellerProductImage, Long>{

}
