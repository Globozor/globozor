package com.globozor.domain.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.globozor.domain.entity.CompanyProfile;

public interface CompanyProfileRespository extends JpaRepository<CompanyProfile, Long>{

	@Query("select c from CompanyProfile c where c.masterTable.masterTableId=?1")
	public CompanyProfile findUnique(long masterTableId);

}
