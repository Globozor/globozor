package com.globozor.domain.dtos;

public class SampleRequestDto {

	private long sampleRequestId;
	private long sellerEnquiryResponseId;
	private String quantity;
	private String unitPrice;
	private String commission;
	private String totalAmount;
	private String sampleRequestDate;
	private String status;
	public long getSampleRequestId() {
		return sampleRequestId;
	}
	public void setSampleRequestId(long sampleRequestId) {
		this.sampleRequestId = sampleRequestId;
	}
	public long getSellerEnquiryResponseId() {
		return sellerEnquiryResponseId;
	}
	public void setSellerEnquiryResponseId(long sellerEnquiryResponseId) {
		this.sellerEnquiryResponseId = sellerEnquiryResponseId;
	}
	public String getQuantity() {
		return quantity;
	}
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}
	public String getUnitPrice() {
		return unitPrice;
	}
	public void setUnitPrice(String unitPrice) {
		this.unitPrice = unitPrice;
	}
	public String getCommission() {
		return commission;
	}
	public void setCommission(String commission) {
		this.commission = commission;
	}
	public String getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount() {
		this.totalAmount=String.valueOf(Double.valueOf(this.quantity)*Double.valueOf(this.unitPrice)+Double.valueOf(this.commission));
	}
	public String getSampleRequestDate() {
		return sampleRequestDate;
	}
	public void setSampleRequestDate(String sampleRequestDate) {
		this.sampleRequestDate = sampleRequestDate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
}
