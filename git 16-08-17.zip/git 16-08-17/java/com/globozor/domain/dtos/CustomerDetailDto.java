package com.globozor.domain.dtos;

public class CustomerDetailDto {

	private long customerId;
	private String customerName;
	private String customerCountry;
	private String annualTurnover;
	private String[] productSupply;
	private String transactionDocument;
	public long getCustomerId() {
		return customerId;
	}
	public void setCustomerId(long customerId) {
		this.customerId = customerId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCustomerCountry() {
		return customerCountry;
	}
	public void setCustomerCountry(String customerCountry) {
		this.customerCountry = customerCountry;
	}
	public String getAnnualTurnover() {
		return annualTurnover;
	}
	public void setAnnualTurnover(String annualTurnover) {
		this.annualTurnover = annualTurnover;
	}
	public String[] getProductSupply() {
		return productSupply;
	}
	public void setProductSupply(String[] productSupply) {
		this.productSupply = productSupply;
	}
	public String getTransactionDocument() {
		return transactionDocument;
	}
	public void setTransactionDocument(String transactionDocument) {
		this.transactionDocument = transactionDocument;
	}

}
