package com.globozor.domain.dtos;

import java.util.Set;

public class MasterTableDto {

	private long masterTableId;
	private String userName;
	private String emailId;
	private String mobileNumber;
	private String password;
	private String firstName;
	private String middleName;
	private String lastName;
	private String companyName;
	private String websiteUrl;
	private String panNumber;
	private String IecCodeNumber;
	private String gstNumber;
	private boolean isVerified;
	private String[] paymentMethods;
	private long roleId;
	private String role;
	private String[] images;
	private long sellerDescriptionId;
	private long[] addressDetailIds;
	private long[] sellerProductIds;
	private long membershipTypeId;
	private String membershipType;
	public long getMasterTableId() {
		return masterTableId;
	}
	public void setMasterTableId(long masterTableId) {
		this.masterTableId = masterTableId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getMiddleName() {
		return middleName;
	}
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getWebsiteUrl() {
		return websiteUrl;
	}
	public void setWebsiteUrl(String websiteUrl) {
		this.websiteUrl = websiteUrl;
	}
	public String getPanNumber() {
		return panNumber;
	}
	public void setPanNumber(String panNumber) {
		this.panNumber = panNumber;
	}
	public String getIecCodeNumber() {
		return IecCodeNumber;
	}
	public void setIecCodeNumber(String iecCodeNumber) {
		IecCodeNumber = iecCodeNumber;
	}
	public String getGstNumber() {
		return gstNumber;
	}
	public void setGstNumber(String gstNumber) {
		this.gstNumber = gstNumber;
	}
	public boolean isVerified() {
		return isVerified;
	}
	public void setVerified(boolean isVerified) {
		this.isVerified = isVerified;
	}
	public long getSellerDescriptionId() {
		return sellerDescriptionId;
	}
	public void setSellerDescriptionId(long sellerDescriptionId) {
		this.sellerDescriptionId = sellerDescriptionId;
	}
	public long[] getAddressDetailIds() {
		return addressDetailIds;
	}
	public void setAddressDetailIds(long[] addressDetailIds) {
		this.addressDetailIds = addressDetailIds;
	}
	public long[] getSellerProductIds() {
		return sellerProductIds;
	}
	public void setSellerProductIds(long[] sellerProductIds) {
		this.sellerProductIds = sellerProductIds;
	}
	public String[] getPaymentMethods() {
		return paymentMethods;
	}
	public void setPaymentMethods(String[] paymentMethods) {
		this.paymentMethods = paymentMethods;
	}
	public long getRoleId() {
		return roleId;
	}
	public void setRoleId(long roleId) {
		this.roleId = roleId;
	}
	public String[] getImages() {
		return images;
	}
	public void setImages(String[] images) {
		this.images = images;
	}
	public long getMembershipTypeId() {
		return membershipTypeId;
	}
	public void setMembershipTypeId(long membershipTypeId) {
		this.membershipTypeId = membershipTypeId;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getMembershipType() {
		return membershipType;
	}
	public void setMembershipType(String membershipType) {
		this.membershipType = membershipType;
	}
}
