package com.globozor.domain.dtos;

public class SellerDescriptionDto {

	private long sellerDescriptionId;
	private String descriptionAboutCompany;
	private int establishment;
	private String maximumCapacity;
	private String turnover;
	private String port;
	private long numberOfEmployees;
	private String membershipType;
	public long getSellerDescriptionId() {
		return sellerDescriptionId;
	}
	public void setSellerDescriptionId(long sellerDescriptionId) {
		this.sellerDescriptionId = sellerDescriptionId;
	}
	public String getDescriptionAboutCompany() {
		return descriptionAboutCompany;
	}
	public void setDescriptionAboutCompany(String descriptionAboutCompany) {
		this.descriptionAboutCompany = descriptionAboutCompany;
	}
	public int getEstablishment() {
		return establishment;
	}
	public void setEstablishment(int establishment) {
		this.establishment = establishment;
	}
	public String getMaximumCapacity() {
		return maximumCapacity;
	}
	public void setMaximumCapacity(String maximumCapacity) {
		this.maximumCapacity = maximumCapacity;
	}
	public String getTurnover() {
		return turnover;
	}
	public void setTurnover(String turnover) {
		this.turnover = turnover;
	}
	public String getPort() {
		return port;
	}
	public void setPort(String port) {
		this.port = port;
	}
	public long getNumberOfEmployees() {
		return numberOfEmployees;
	}
	public void setNumberOfEmployees(long numberOfEmployees) {
		this.numberOfEmployees = numberOfEmployees;
	}
	public String getMembershipType() {
		return membershipType;
	}
	public void setMembershipType(String membershipType) {
		this.membershipType = membershipType;
	}
	
}
