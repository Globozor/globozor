package com.globozor.domain.dtos;

import java.util.Set;

public class SellerEnquiryDto {

	private String buyerCompanyName;
	private String subProductName;
	private long quantity;
	private String unit;
	private String description;
	private String attachments;
	private String sellerProductName;
	
	public String getBuyerCompanyName() {
		return buyerCompanyName;
	}
	public void setBuyerCompanyName(String buyerCompanyName) {
		this.buyerCompanyName = buyerCompanyName;
	}
	public String getSubProductName() {
		return subProductName;
	}
	public void setSubProductName(String subProductName) {
		this.subProductName = subProductName;
	}
	public long getQuantity() {
		return quantity;
	}
	public void setQuantity(long quantity) {
		this.quantity = quantity;
	}
	public String getUnit() {
		return unit;
	}
	public void setUnit(String unit) {
		this.unit = unit;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getAttachments() {
		return attachments;
	}
	public void setAttachments(String attachments) {
		this.attachments = attachments;
	}
	public String getSellerProductName() {
		return sellerProductName;
	}
	public void setSellerProductName(String sellerProductName) {
		this.sellerProductName = sellerProductName;
	}
}
