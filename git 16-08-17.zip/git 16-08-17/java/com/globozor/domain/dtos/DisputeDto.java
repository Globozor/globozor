package com.globozor.domain.dtos;

public class DisputeDto {

	private long disputeId;
	private long transactionId;
	private String buyerName;
	private String sellerName;
	private String disputeName;
	private String description;
	private String status;
	public long getDisputeId() {
		return disputeId;
	}
	public void setDisputeId(long disputeId) {
		this.disputeId = disputeId;
	}
	public long getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(long transactionId) {
		this.transactionId = transactionId;
	}
	public String getBuyerName() {
		return buyerName;
	}
	public void setBuyerName(String buyerName) {
		this.buyerName = buyerName;
	}
	public String getSellerName() {
		return sellerName;
	}
	public void setSellerName(String sellerName) {
		this.sellerName = sellerName;
	}
	public String getDisputeName() {
		return disputeName;
	}
	public void setDisputeName(String disputeName) {
		this.disputeName = disputeName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
}
