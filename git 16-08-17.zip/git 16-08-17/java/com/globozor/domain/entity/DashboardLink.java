package com.globozor.domain.entity;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Table
@Entity
public class DashboardLink {

	@Id
	private long dashboardLinkId;
	
	@Column(name="dashboardLinkName")
	private String links;
	
	@Column
	private String role;
	
	@OneToMany(mappedBy="dashboardLink")
	private Set<SubLink> subLinks;

	public long getDashboardLinkId() {
		return dashboardLinkId;
	}

	public void setDashboardLinkId(long dashboardLinkId) {
		this.dashboardLinkId = dashboardLinkId;
	}

	public String getLinks() {
		return links;
	}

	public void setLinks(String links) {
		this.links = links;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public Set<SubLink> getSubLinks() {
		return subLinks;
	}

	public void setSubLinks(Set<SubLink> subLinks) {
		this.subLinks = subLinks;
	}
	
}
