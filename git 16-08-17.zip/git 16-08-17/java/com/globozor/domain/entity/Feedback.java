package com.globozor.domain.entity;

public class Feedback {

}
