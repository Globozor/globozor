package com.globozor.domain.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table
public class TransactionFile {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column
	private long transactionFileId;
	
	@OneToOne
	@JoinColumn(name="transactionId")
	private Transaction transaction;
	
	@Column
	private String buyerFilepath;
	
	@Column
	private String sellerFilepath;

	public long getTransactionFileId() {
		return transactionFileId;
	}

	public void setTransactionFileId(long transactionFileId) {
		this.transactionFileId = transactionFileId;
	}

	public Transaction getTransaction() {
		return transaction;
	}

	public void setTransaction(Transaction transaction) {
		this.transaction = transaction;
	}

	public String getBuyerFilepath() {
		return buyerFilepath;
	}

	public void setBuyerFilepath(String buyerFilepath) {
		this.buyerFilepath = buyerFilepath;
	}

	public String getSellerFilepath() {
		return sellerFilepath;
	}

	public void setSellerFilepath(String sellerFilepath) {
		this.sellerFilepath = sellerFilepath;
	}
}
