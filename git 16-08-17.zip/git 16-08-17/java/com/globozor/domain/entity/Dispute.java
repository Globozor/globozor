package com.globozor.domain.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@Table
public class Dispute {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long disputeId;
	
	@OneToOne
	@JoinColumn(name="transactionId")
	@JsonManagedReference
	private Transaction transaction;
	
	@Column
	private String disputeName;
	
	@Column
	private String description;
	
	@OneToOne
	@JoinColumn(name="raisedBy")
	private MasterTable raisedBy;
	
	@OneToOne
	@JoinColumn(name="raisedFor")
	private MasterTable raisedFor;

	public long getDisputeId() {
		return disputeId;
	}

	public void setDisputeId(long disputeId) {
		this.disputeId = disputeId;
	}

	public Transaction getTransaction() {
		return transaction;
	}

	public void setTransaction(Transaction transaction) {
		this.transaction = transaction;
	}

	public String getDisputeName() {
		return disputeName;
	}

	public void setDisputeName(String disputeName) {
		this.disputeName = disputeName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public MasterTable getRaisedBy() {
		return raisedBy;
	}

	public void setRaisedBy(MasterTable raisedBy) {
		this.raisedBy = raisedBy;
	}

	public MasterTable getRaisedFor() {
		return raisedFor;
	}

	public void setRaisedFor(MasterTable raisedFor) {
		this.raisedFor = raisedFor;
	}

}
