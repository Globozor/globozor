package com.globozor.domain.services;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.globozor.domain.entity.Favourite;

public interface FavouriteRepository extends JpaRepository<Favourite, Long>{

	@Query("select f from Favourite f where f.buyer.masterTableId=?1")
	public List<Favourite> getAllFavourites(long masterTableId);

}
