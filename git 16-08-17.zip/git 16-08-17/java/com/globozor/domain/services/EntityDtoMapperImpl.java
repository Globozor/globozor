package com.globozor.domain.services;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.globozor.domain.dtos.BuyerRatingDto;
import com.globozor.domain.dtos.CompanyProfileDto;
import com.globozor.domain.dtos.CustomerDetailDto;
import com.globozor.domain.dtos.DisputeDto;
import com.globozor.domain.dtos.MasterTableDto;
import com.globozor.domain.dtos.SampleRequestDto;
import com.globozor.domain.dtos.SellerDescriptionDto;
import com.globozor.domain.dtos.SellerDto;
import com.globozor.domain.dtos.SellerEnquiryDto;
import com.globozor.domain.dtos.SellerEnquiryResponseDto;
import com.globozor.domain.dtos.SellerProductDto;
import com.globozor.domain.dtos.SellerRatingDto;
import com.globozor.domain.dtos.TradeShowDto;
import com.globozor.domain.dtos.TransactionDto;
import com.globozor.domain.entity.AddressDetails;
import com.globozor.domain.entity.BuyerRating;
import com.globozor.domain.entity.CompanyProfile;
import com.globozor.domain.entity.CustomerDetail;
import com.globozor.domain.entity.Dispute;
import com.globozor.domain.entity.Image;
import com.globozor.domain.entity.MasterTable;
import com.globozor.domain.entity.PaymentMethod;
import com.globozor.domain.entity.Role;
import com.globozor.domain.entity.SampleRequest;
import com.globozor.domain.entity.SellerDescription;
import com.globozor.domain.entity.SellerEnquiry;
import com.globozor.domain.entity.SellerEnquiryResponse;
import com.globozor.domain.entity.SellerProduct;
import com.globozor.domain.entity.SellerProductImage;
import com.globozor.domain.entity.SellerRating;
import com.globozor.domain.entity.TradeShow;
import com.globozor.domain.entity.Transaction;

@Service
@Transactional
public class EntityDtoMapperImpl implements EntityDtoMapper{

	DateFormat formatter = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
	
	@Override
	public SellerDto sellerEntityToDto(MasterTable masterTable) {
		SellerDto sellerDto = new SellerDto();
		SellerProduct sellerProduct2 = new SellerProduct();
		List<String> sellerProductImages= new ArrayList<String>();
		String sellerProductImage = "";
		Set<SellerProduct> sellerProducts = masterTable.getSellerProducts();
		int priority=0;
		int count=0;
		for (SellerProduct sellerProduct : sellerProducts) {
			if(count==0){
				priority=sellerProduct.getPriority();
				sellerProduct2 = sellerProduct;
				count++;
			}else{
				if(sellerProduct.getPriority()<priority){
					priority=sellerProduct.getPriority();
					sellerProduct2 = sellerProduct;
				}
			}
		}
		if(sellerProduct2.getSellerProductImage()!=null){
		Set<SellerProductImage> productImages = sellerProduct2.getSellerProductImage();
		System.out.println("se is "+productImages);
			for (SellerProductImage sellerProductImage2 : productImages) {
					sellerProductImage = sellerProductImage2.getFilePath();
					sellerProductImages.add(sellerProductImage);
			}
		}
		sellerDto.setUnitPrice(sellerProduct2.getUnitPrice());
		sellerDto.setMinimumQuantity(sellerProduct2.getMinimumQuantity());
		sellerDto.setProductMaturity(sellerProduct2.getProductMaturity());
		sellerDto.setProductCertification(sellerProduct2.getProductCertification());
		sellerDto.setProductWeight(sellerProduct2.getProductWeight());
		sellerDto.setProductSize(sellerProduct2.getProductSize());
		sellerDto.setProductPlaceOfOrigin(sellerProduct2.getProductPlaceOfOrigin());
		sellerDto.setProductShape(sellerProduct2.getProductShape());
		sellerDto.setProductCultivationType(sellerProduct2.getProductCultivationType());
		sellerDto.setSellerProductDescription(sellerProduct2.getSellerProductDescription());
		sellerDto.setSellerProductName(sellerProduct2.getSellerProductName());
		sellerDto.setSellerProductImage(sellerProductImages);
		sellerDto.setSellerName(masterTable.getFirstName()+" "+masterTable.getMiddleName()+" "+masterTable.getLastName());
		Set<AddressDetails> addressDetails = masterTable.getAddressDetails();
		if(addressDetails!=null){
			int count2 = 0;
			for (AddressDetails addressDetails2 : addressDetails) {
				if(count2==0){
					sellerDto.setSellerCountry(addressDetails2.getCountryLookup().getCountryName());
					count2++;
				}
			}
		}
		sellerDto.setSellerMembershipType(masterTable.getSellerDescription().getMembershipType().getMembershipTypeName());
		sellerDto.setVerified(masterTable.isVerified());
		sellerDto.setSellerCompanyName(masterTable.getCompanyName());
		sellerDto.setSellerTurnover(masterTable.getSellerDescription().getTurnover());
		return sellerDto;
	}
	
	@Override
	public MasterTableDto masterTableEntityToDto(MasterTable masterTable) {
		MasterTableDto masterTableDto = new MasterTableDto();
		masterTableDto.setMasterTableId(masterTable.getMasterTableId());
		masterTableDto.setEmailId(masterTable.getEmailId());
		masterTableDto.setUserName(masterTable.getUserName());
		masterTableDto.setMobileNumber(masterTable.getMobileNumber());
		masterTableDto.setFirstName(masterTable.getFirstName());
		masterTableDto.setMiddleName(masterTable.getMiddleName());
		masterTableDto.setLastName(masterTable.getLastName());
		masterTableDto.setCompanyName(masterTable.getCompanyName());
		masterTableDto.setWebsiteUrl(masterTable.getWebsiteUrl());
		masterTableDto.setPanNumber(masterTable.getPanNumber());
		masterTableDto.setIecCodeNumber(masterTable.getIecCodeNumber());
		masterTableDto.setGstNumber(masterTable.getGstNumber());
		masterTableDto.setVerified(masterTable.isVerified());
		masterTableDto.setRoleId(masterTable.getRole().getRoleId());
		if(masterTable.getRole().getRoleDescription()!=null){
			masterTableDto.setRole(masterTable.getRole().getRoleDescription());
		}
		if(masterTable.getSellerDescription()!=null){
			masterTableDto.setMembershipTypeId(masterTable.getSellerDescription().getMembershipType().getMembershipTypeId());
			if(masterTable.getSellerDescription().getMembershipType().getMembershipTypeName()!=null){
				masterTableDto.setMembershipType(masterTable.getSellerDescription().getMembershipType().getMembershipTypeName());
			}
		}else if (masterTable.getBuyerDescription()!=null) {
			masterTableDto.setMembershipTypeId(masterTable.getBuyerDescription().getMembershipType().getMembershipTypeId());
			if(masterTable.getBuyerDescription().getMembershipType().getMembershipTypeName()!=null){
				masterTableDto.setMembershipType(masterTable.getBuyerDescription().getMembershipType().getMembershipTypeName());
			}
		}
		return masterTableDto;
	}

	/*@Override
	public MasterTable masterTableDtoToEntity(MasterTableDto masterTableDto) {
		MasterTable masterTable = new MasterTable();
		System.out.println("dto is "+masterTableDto);
		System.out.println("mas ids "+masterTable);
		masterTable.setMasterTableId(masterTableDto.getMasterTableId());
		masterTable.setUserName(masterTableDto.getUserName());
		masterTable.setEmailId(masterTableDto.getEmailId());
		masterTable.setMobileNumber(masterTableDto.getMobileNumber());
		masterTable.setPassword(masterTableDto.getPassword());
		masterTable.setFirstName(masterTableDto.getFirstName());
		masterTable.setMiddleName(masterTableDto.getMiddleName());
		masterTable.setLastName(masterTableDto.getLastName());
		masterTable.setCompanyName(masterTableDto.getCompanyName());
		masterTable.setWebsiteUrl(masterTableDto.getWebsiteUrl());		
		masterTable.setPanNumber(masterTableDto.getPanNumber());
		masterTable.setIecCodeNumber(masterTableDto.getIecCodeNumber());
		masterTable.setGstNumber(masterTableDto.getGstNumber());
		masterTable.setVerified(masterTableDto.isVerified());
		if(masterTableDto.getRoleId()!=0){
			Role role = new Role();
			role.setRoleId(masterTableDto.getRoleId());
			masterTable.setRole(role);
		}
		if(masterTableDto.getSellerDescriptionId() != 0){
			SellerDescription sellerDescription = new SellerDescription();
			sellerDescription.setSellerDescriptionId(masterTableDto.getSellerDescriptionId());
			masterTable.setSellerDescription(sellerDescription);
		}
		System.out.println("m is "+masterTable);
		Set<PaymentMethod> paymentMethods = new HashSet<PaymentMethod>();
		if(masterTableDto.getPaymentMethodIds() != null){
			for(int i = 0 ; i<masterTableDto.getPaymentMethodIds().length ; i++){
				PaymentMethod paymentMethod = new PaymentMethod();
				paymentMethod.setPaymentMethodId(masterTableDto.getPaymentMethodIds()[i]);
				paymentMethods.add(paymentMethod);
			}
			masterTable.setPaymentMethod(paymentMethods);
		}
		Set<Image> images = new HashSet<Image>();
		if(masterTableDto.getImagesId() != null){
			for(int i = 0 ; i<masterTableDto.getImagesId().length ; i++){
				Image image = new Image();
				image.setImageId(masterTableDto.getImagesId()[i]);
				images.add(image);
			}
			masterTable.setProfileImages(images);
		}
		Set<AddressDetails> addressDetailSet = new HashSet<AddressDetails>();
		if(masterTableDto.getAddressDetailIds() != null){
			for(int i = 0 ; i<masterTableDto.getAddressDetailIds().length ; i++){
				AddressDetails addressDetails = new AddressDetails();
				addressDetails.setAddressDetailsId(masterTableDto.getAddressDetailIds()[i]);
				addressDetailSet.add(addressDetails);
			}
			masterTable.setAddressDetails(addressDetailSet);
		}
		Set<SellerProduct> sellerProducts = new HashSet<SellerProduct>();
		if(masterTableDto.getSellerProductIds() != null){
			for (int i = 0; i < masterTableDto.getSellerProductIds().length; i++) {
				SellerProduct sellerProduct = new SellerProduct();
				sellerProduct.setSellerProductId(masterTableDto.getSellerProductIds()[i]);
				sellerProducts.add(sellerProduct);
			}
			masterTable.setSellerProducts(sellerProducts);
		}
		return masterTable;
	}*/

	@Override
	public SellerProductDto sellerProductToDto(SellerProduct sellerProduct) {
		SellerProductDto sellerProductDto = new SellerProductDto();
		sellerProductDto.setSellerProductName(sellerProduct.getSellerProductName());
		sellerProductDto.setSubProductName(sellerProduct.getSubProduct().getSubProductName());
		sellerProductDto.setSellerProductDesc(sellerProduct.getSellerProductDescription());
		sellerProductDto.setMinimumQuantity(sellerProduct.getMinimumQuantity());
		sellerProductDto.setUnitPrice(sellerProduct.getUnitPrice());
		sellerProductDto.setPriority(sellerProduct.getPriority());
		sellerProductDto.setSellerProductId(sellerProduct.getSellerProductId());
		sellerProductDto.setProductMaturity(sellerProduct.getProductMaturity());
		sellerProductDto.setProductCertification(sellerProduct.getProductCertification());
		sellerProductDto.setProductWeight(sellerProduct.getProductWeight());
		sellerProductDto.setProductSize(sellerProduct.getProductSize());
		sellerProductDto.setProductPlaceOfOrigin(sellerProduct.getProductPlaceOfOrigin());
		sellerProductDto.setProductShape(sellerProduct.getProductShape());
		sellerProductDto.setProductCultivationType(sellerProduct.getProductCultivationType());
		Set<SellerProductImage> sellerProductImages = sellerProduct.getSellerProductImage();
		if(sellerProductImages != null){
			Set<String> filepaths = new HashSet<String>();
			for (SellerProductImage sellerProductImage : sellerProductImages) {
				String filePath;
				filePath = sellerProductImage.getFilePath();
				filepaths.add(filePath);
			}
		sellerProductDto.setSellerProductImage(filepaths);	
		}
		return sellerProductDto;
	}

	@Override
	public SellerEnquiryDto sellerEnquiryToDto(SellerEnquiry sellerEnquiry) {
		SellerEnquiryDto sellerEnquiryDto = new SellerEnquiryDto();
		sellerEnquiryDto.setBuyerCompanyName(sellerEnquiry.getId().getEnquiry().getBuyer().getCompanyName());
		sellerEnquiryDto.setSubProductName(sellerEnquiry.getId().getEnquiry().getSubProduct().getSubProductName());
		sellerEnquiryDto.setDescription(sellerEnquiry.getId().getEnquiry().getEnqiryDescription());
		sellerEnquiryDto.setQuantity(sellerEnquiry.getId().getEnquiry().getQuantity());
		sellerEnquiryDto.setUnit(sellerEnquiry.getId().getEnquiry().getUnit());
		sellerEnquiryDto.setAttachments(sellerEnquiry.getId().getEnquiry().getFilepathAttachments());
		sellerEnquiryDto.setSellerProductName(sellerEnquiry.getId().getEnquiry().getSellerProduct().getSellerProductName());
		return sellerEnquiryDto;
	}

	@Override
	public CompanyProfileDto companyProfileToDto(CompanyProfile companyProfile) {
		CompanyProfileDto companyProfileDto = new CompanyProfileDto();
		Set<Image> images = companyProfile.getMasterTable().getProfileImages();
		if(images != null){
			for (Image image : images) {
				if(image.getAttachmentTypeOfImage().getAttachmentTypeOfImageId()==2){
					companyProfileDto.setLogo(image.getImageFilepath());
				}
			}
		}
		companyProfileDto.setBusinessType(companyProfile.getBusinessType());
		companyProfileDto.setExportPercentage(companyProfile.getExportPercentage());
		companyProfileDto.setSourceAcrossMultipleIndustries(companyProfile.getSourceAcrossMultipleIndustries());
		companyProfileDto.setAverageLeadTime(companyProfile.getAverageLeadTime());
		companyProfileDto.setOverseasOffice(companyProfile.getOverseasOffice());
		companyProfileDto.setDescriptioAboutCompany(companyProfile.getMasterTable().getSellerDescription().getDescriptionAboutCompany());
		companyProfileDto.setEstablishment(companyProfile.getMasterTable().getSellerDescription().getEstablishment());
		companyProfileDto.setMaximumCapacity(companyProfile.getMasterTable().getSellerDescription().getMaximumCapacity());
		companyProfileDto.setTurnOver(companyProfile.getMasterTable().getSellerDescription().getTurnover());
		companyProfileDto.setPort(companyProfile.getMasterTable().getSellerDescription().getPort());
		companyProfileDto.setNumberOfEmployees(companyProfile.getMasterTable().getSellerDescription().getNumberOfEmployees());
		Set<AddressDetails> addressDetails = companyProfile.getMasterTable().getAddressDetails();
		int count = 0;
		for (AddressDetails addressDetails2 : addressDetails) {
			if(count==0){
				companyProfileDto.setAddressLine1(addressDetails2.getAddressLine1());
				companyProfileDto.setAddressLine2(addressDetails2.getAddressLine2());
				companyProfileDto.setPincode(addressDetails2.getPincode());
				companyProfileDto.setCity(addressDetails2.getCity());
				companyProfileDto.setAddressType(addressDetails2.getAddressType());
				companyProfileDto.setCountry(addressDetails2.getCountryLookup().getCountryName());
				companyProfileDto.setState(addressDetails2.getStateLookup().getStateName());
				count++;
			}
		}
		return null;
	}

	@Override
	public SellerDescriptionDto sellerDescEntityToDto(
			SellerDescription sellerDescription) {
		SellerDescriptionDto sellerDescriptionDto = new SellerDescriptionDto();
		sellerDescriptionDto.setSellerDescriptionId(sellerDescription.getSellerDescriptionId());
		sellerDescriptionDto.setDescriptionAboutCompany(sellerDescription.getDescriptionAboutCompany());
		sellerDescriptionDto.setEstablishment(sellerDescription.getEstablishment());
		sellerDescriptionDto.setMaximumCapacity(sellerDescription.getMaximumCapacity());
		sellerDescriptionDto.setTurnover(sellerDescription.getTurnover());
		sellerDescriptionDto.setPort(sellerDescription.getPort());
		sellerDescriptionDto.setNumberOfEmployees(sellerDescription.getNumberOfEmployees());
		sellerDescriptionDto.setMembershipType(sellerDescription.getMembershipType().getMembershipTypeName());
		return sellerDescriptionDto;
	}

	@Override
	public TradeShowDto tradeShowEntityToDto(TradeShow tradeShow) {
		TradeShowDto tradeShowDto = new TradeShowDto();
		tradeShowDto.setTradeShowId(tradeShow.getTradeShowId());
		tradeShowDto.setTradeShowName(tradeShow.getTradeShowName());
		tradeShowDto.setTradeShowDate(tradeShow.getTradeShowDate());
		tradeShowDto.setTradeShowHost(tradeShow.getTradeShowHost());
		tradeShowDto.setTradeShowDescription(tradeShow.getTradeShowDescription());
		if(tradeShow.getTradeShowFilepath()!=null){
			tradeShowDto.setTradeShowFilepath(tradeShow.getTradeShowFilepath());
		}
		return tradeShowDto;
	}

	@Override
	public CustomerDetailDto customerEntityToDto(CustomerDetail customerDetail) {
		CustomerDetailDto customerDetailDto = new CustomerDetailDto();
		customerDetailDto.setCustomerId(customerDetail.getCustomerId());
		customerDetailDto.setCustomerName(customerDetail.getCustomerName());
		customerDetailDto.setCustomerCountry(customerDetail.getCustomerCountry());
		customerDetailDto.setAnnualTurnover(customerDetail.getAnnualTurnover());
		customerDetailDto.setTransactionDocument(customerDetail.getTransactionDocument());
		if(customerDetail.getProductSupply()!=null){
			customerDetailDto.setProductSupply(customerDetail.getProductSupply());
		}
		return customerDetailDto;
	}

	@Override
	public SellerEnquiryResponseDto sellerEnqResponseToDto(
			SellerEnquiryResponse sellerEnquiryResponse) {
		SellerEnquiryResponseDto sellerEnquiryResponseDto =  new SellerEnquiryResponseDto();
		sellerEnquiryResponseDto.setSellerEnquiryResponseId(sellerEnquiryResponse.getSellerEnquiryResponseId());
		sellerEnquiryResponseDto.setSellerCompanyName(sellerEnquiryResponse.getSeller().getCompanyName());
		sellerEnquiryResponseDto.setQuantity(String.valueOf(sellerEnquiryResponse.getQuantity()));
		sellerEnquiryResponseDto.setUnit(sellerEnquiryResponse.getUnit());
		sellerEnquiryResponseDto.setUnitPrice(sellerEnquiryResponse.getUnitPrice());
		sellerEnquiryResponseDto.setEnquiryDescription(sellerEnquiryResponse.getEnquiryDescription());
		sellerEnquiryResponseDto.setStatus(sellerEnquiryResponse.getStatus());
		sellerEnquiryResponseDto.setSellerProductName(sellerEnquiryResponse.getEnquiry().getSellerProduct().getSellerProductName());
		return sellerEnquiryResponseDto;
	}

	@Override
	public DisputeDto disputeEntityToDto(Dispute dispute) {
		DisputeDto disputeDto = new DisputeDto();
		disputeDto.setDisputeId(dispute.getDisputeId());
		disputeDto.setTransactionId(dispute.getTransaction().getTransactionId());
		disputeDto.setBuyerName(dispute.getTransaction().getBuyer().getFirstName()+dispute.getTransaction().getBuyer().getLastName());
		disputeDto.setSellerName(dispute.getTransaction().getSeller().getFirstName()+dispute.getTransaction().getSeller().getLastName());
		disputeDto.setDescription(dispute.getDescription());
		disputeDto.setDisputeName(dispute.getDisputeName());
		return disputeDto;
	}

	@Override
	public BuyerRatingDto buyerRatingToDto(BuyerRating buyerRating) {
		BuyerRatingDto buyerRatingDto = new BuyerRatingDto();
		buyerRatingDto.setBuyerRatingId(buyerRating.getBuyerRatingId());
		buyerRatingDto.setTransactionId(buyerRating.getTransaction().getTransactionId());
		buyerRatingDto.setBuyerName(buyerRating.getTransaction().getBuyer().getFirstName()+buyerRating.getTransaction().getBuyer().getLastName());
		buyerRatingDto.setSellerName(buyerRating.getTransaction().getSeller().getFirstName()+buyerRating.getTransaction().getSeller().getLastName());
		buyerRatingDto.setDescription(buyerRating.getDescription());
		buyerRatingDto.setRating(String.valueOf(buyerRating.getRating()));
		return buyerRatingDto;
	}

	@Override
	public SellerRatingDto sellerRatingToDto(SellerRating sellerRating) {
		SellerRatingDto sellerRatingDto = new SellerRatingDto();
		sellerRatingDto.setSellerRatingId(sellerRating.getSellerRatingId());
		sellerRatingDto.setTransactionId(sellerRating.getTransaction().getTransactionId());
		sellerRatingDto.setBuyerName(sellerRating.getTransaction().getBuyer().getFirstName()+sellerRating.getTransaction().getBuyer().getLastName());
		sellerRatingDto.setSellerName(sellerRating.getTransaction().getSeller().getFirstName()+sellerRating.getTransaction().getSeller().getLastName());
		sellerRatingDto.setDescription(sellerRating.getDescription());
		sellerRatingDto.setRating(String.valueOf(sellerRating.getRating()));
		return sellerRatingDto;
	}

	@Override
	public TransactionDto transactionEntityToDto(Transaction transaction) {
		TransactionDto transactionDto = new TransactionDto();
		transactionDto.setTransactionId(transaction.getTransactionId());
		transactionDto.setSellerCompanyName(transaction.getSeller().getCompanyName());
		transactionDto.setSellerName((transaction.getSeller().getFirstName()+transaction.getSeller().getLastName()));
		transactionDto.setBuyerName(transaction.getBuyer().getFirstName()+transaction.getBuyer().getLastName());
		transactionDto.setSellerProductName(transaction.getSellerProduct().getSellerProductName());
		transactionDto.setUnitPrice(String.valueOf(transaction.getUnitPrice()));
		transactionDto.setQuantity(String.valueOf(transaction.getQuantity()));
		transactionDto.setTotalAmount(String.valueOf(transaction.getTradeAmount()));
		transactionDto.setCommission(String.valueOf(transaction.getCommission()));
		transactionDto.setCloseTradeDate(formatter.format(transaction.getCloseTradeDate()));
		return transactionDto;
	}

	@Override
	public SampleRequestDto sampleRequestToDto(SampleRequest sampleRequest) {
		SampleRequestDto sampleRequestDto = new SampleRequestDto();
		sampleRequestDto.setSampleRequestId(sampleRequest.getSampleRequestId());
		sampleRequestDto.setSellerEnquiryResponseId(sampleRequest.getSellerEnquiryResponse().getSellerEnquiryResponseId());
		sampleRequestDto.setQuantity(sampleRequest.getQuantity());
		sampleRequestDto.setUnitPrice(sampleRequest.getUnitPrice());
		sampleRequestDto.setCommission(sampleRequest.getCommission());
		sampleRequestDto.setTotalAmount();
		sampleRequestDto.setSampleRequestDate(formatter.format(sampleRequest.getSampleRequestDate()));
		sampleRequestDto.setStatus(sampleRequest.getStatus());
		return sampleRequestDto;
	}

}
