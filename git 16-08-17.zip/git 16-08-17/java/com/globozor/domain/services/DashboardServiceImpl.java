package com.globozor.domain.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.globozor.domain.entity.DashboardLink;
import com.globozor.domain.repository.DashboardRepository;

@Service
@Transactional
public class DashboardServiceImpl implements DashboardService{

	@Autowired
	DashboardRepository dashboardRepository;
	
	@Override
	public List<DashboardLink> getLinks(String role) {
		return dashboardRepository.findByRole(role);
	}

}
