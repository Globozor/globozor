package com.globozor.domain.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.globozor.domain.entity.Enquiry;
import com.globozor.domain.repository.EnquiryRepository;

@Service
public class EnquiryServiceImpl implements EnquiryService{

	@Autowired
	EnquiryRepository enquiryRepository;
	
	@Override
	public Enquiry getEnquiry(long enquiryId) {
		return enquiryRepository.findOne(enquiryId);
	}
	
}
