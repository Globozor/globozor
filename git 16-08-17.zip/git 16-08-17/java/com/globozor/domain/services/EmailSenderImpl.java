package com.globozor.domain.services;

import java.util.Date;

import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.globozor.domain.entity.MasterTable;

@Service
@Transactional
public class EmailSenderImpl implements EmailSender {

	public JavaMailSender javaMailSender;
	
	@Autowired
	public EmailSenderImpl(JavaMailSender javaMailSender){
		this.javaMailSender=javaMailSender;
	}

	public void sendEmail() throws MailException{
		SimpleMailMessage message = new SimpleMailMessage();
		message.setTo("arch@globozor.com");
		message.setFrom("megirjesh4150@gmail.com");
		message.setSubject("dummy");
		message.setText("Hello , success");
		
		javaMailSender.send(message);
	}

	@Override
	public void sendEmail(JSONObject jsonObject , MasterTable masterTable) throws MailException {
		String to = (String) jsonObject.get("to");
		String from = masterTable.getEmailId();
		String subject = (String) jsonObject.get("subject");
		String text = (String) jsonObject.get("text");
		
		SimpleMailMessage message = new SimpleMailMessage();
		message.setTo(to);
		message.setFrom(from);
		message.setSubject(subject);
		message.setText(text);
		message.setSentDate(new Date());
		
		javaMailSender.send(message);
	}

	
   /* public void setMailSender(JavaMailSender javaMailSender) {
        this.javaMailSender = javaMailSender;
    }
	
	@Override
	public void sendEmail() {
		 MimeMessagePreparator preparator = new MimeMessagePreparator() {

	            public void prepare(MimeMessage mimeMessage) throws Exception {

	                mimeMessage.setRecipient(Message.RecipientType.TO,
	                        new InternetAddress("archbavishi@gmail.com"));
	                mimeMessage.setFrom(new InternetAddress("megirjesh4150@gmail.com"));
	                mimeMessage.setText(
	                        "success");
	            }
	        };

	        try {
	            mailSender.send(preparator);
	        }
	        catch (MailException ex) {
	            // simply log it and go on...
	            System.err.println(ex.getMessage());
	        }
	}

*/
	}
