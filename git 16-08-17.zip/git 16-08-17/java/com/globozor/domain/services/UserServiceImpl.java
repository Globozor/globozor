package com.globozor.domain.services;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.globozor.domain.entity.AddressDetails;
import com.globozor.domain.entity.BuyerDescription;
import com.globozor.domain.entity.Enquiry;
import com.globozor.domain.entity.Image;
import com.globozor.domain.entity.MasterTable;
import com.globozor.domain.entity.Product;
import com.globozor.domain.entity.SellerDescription;
import com.globozor.domain.entity.SellerEnquiry;
import com.globozor.domain.entity.SellerEnquiryPk;
import com.globozor.domain.entity.SellerProduct;
import com.globozor.domain.entity.SubCategory;
import com.globozor.domain.entity.SubProduct;
import com.globozor.domain.exceptions.MasterTableException;
import com.globozor.domain.repository.AddressDetailsRepository;
import com.globozor.domain.repository.BuyerDescriptionRepository;
import com.globozor.domain.repository.EnquiryRepository;
import com.globozor.domain.repository.ImageRepository;
import com.globozor.domain.repository.MasterTableRepository;
import com.globozor.domain.repository.ProductRepository;
import com.globozor.domain.repository.SellerDescriptionRepository;
import com.globozor.domain.repository.SellerEnquiryRepository;
import com.globozor.domain.repository.SellerProductRepository;
import com.globozor.domain.repository.SubCategoryRepository;
import com.globozor.domain.repository.SubProductRepository;

@Service
public class UserServiceImpl implements UserService{
	
	private static final Logger log = LoggerFactory.getLogger(UserServiceImpl.class);

	@Autowired
	MasterTableRepository masterTableRepository;
	
	@Autowired
	SubCategoryRepository subCategoryRepository;
	
	@Autowired
	ProductRepository productRepository;
	
	@Autowired
	SubProductRepository subProductRepository;
	
	@Autowired
	SellerProductRepository sellerProductRepository;
	
	@Autowired
	EnquiryRepository enquiryRepository;
	
	@Autowired
	SellerEnquiryRepository sellerEnquiryRepository;
	
	@Autowired
	SellerDescriptionRepository sellerDescriptionRepository;
	
	@Autowired
	AddressDetailsRepository addressDetailsRepository;
	
	@Autowired
	ImageRepository imageRepository;
	
	@Autowired
	BuyerDescriptionRepository buyerDescriptionRepository;
	
	
	@Override
	public MasterTable login(MasterTable masterTable) throws MasterTableException{
		MasterTable masterTable2 = new MasterTable();
		System.out.println("mas is "+masterTable);
		//masterTable2 = masterTableRepository.findByUserName(masterTable.getUserName());
		if(masterTable.getMobileNumber() != null){
			System.out.println("1st");
			masterTable2 = masterTableRepository.findByMobileNumber(masterTable.getMobileNumber());
		}else if(masterTable.getUserName() != null){
			System.out.println("2nd");
			masterTable2 = masterTableRepository.findByUserName(masterTable.getUserName().toLowerCase());
		}else if(masterTable.getEmailId() != null){
			System.out.println("3rd");
			masterTable2 = masterTableRepository.findByEmailId(masterTable.getEmailId().toLowerCase());
		}
		System.out.println("maste is "+masterTable2);
		if(masterTable2 != null && masterTable.getPassword().equals(masterTable2.getPassword())){
			return masterTable2;
		}else{
			throw new MasterTableException("Username or password is incorrect");
		}
	}

	@Override
	public MasterTable signup(MasterTable masterTable)
			throws MasterTableException {
		try {
			SellerDescription sellerDescription = masterTable.getSellerDescription();
			masterTable.setSellerDescription(null);
			masterTable = masterTableRepository.save(masterTable);
			sellerDescription.setMasterTable(masterTable);
			sellerDescription = sellerDescriptionRepository.save(sellerDescription);
			masterTable.setSellerDescription(sellerDescription);
		} catch (Exception e) {
			String exception="";
			if(e.getMessage().contains("unique_user_name")){
				exception = "User Name has been taken";
			}if(e.getMessage().contains("unique_email_id")){
				exception="Email id is registered";
			}if(e.getMessage().contains("unique_mobile_number")){
				exception="Mobile Number is registered";
			}if(exception.equals("")){
				exception=e.getMessage();
			}
			throw new MasterTableException(exception);
		}
		return masterTable;
	}
	
	@Override
	public MasterTable updateUser(MasterTable masterTable){
		MasterTable existingMaster = null;
		if(masterTable.getMasterTableId() != 0){
			existingMaster = masterTableRepository.findOne(masterTable.getMasterTableId());
			System.out.println("masterTable is "+masterTable);
			System.out.println("existing is "+existingMaster);
			if(masterTable.getUserName() != null){
				existingMaster.setUserName(masterTable.getUserName());
			}
			if(masterTable.getEmailId() != null){
				existingMaster.setEmailId(masterTable.getEmailId());
			}
			if(masterTable.getMobileNumber() != null){
				existingMaster.setMobileNumber(masterTable.getMobileNumber());
			}
			if(masterTable.getPassword() != null){
				existingMaster.setPassword(masterTable.getPassword());
			}
			if(masterTable.getFirstName() != null){
				existingMaster.setFirstName(masterTable.getFirstName());
			}
			if(masterTable.getMiddleName() != null){
				existingMaster.setMiddleName(masterTable.getMiddleName());
			}
			if(masterTable.getLastName() != null){
				existingMaster.setLastName(masterTable.getLastName());
			}
			if(masterTable.getCompanyName() != null){
				existingMaster.setCompanyName(masterTable.getCompanyName());
			}
			if(masterTable.getWebsiteUrl() != null){
				existingMaster.setWebsiteUrl(masterTable.getWebsiteUrl());
			}
			if(masterTable.getPanNumber() != null){
				existingMaster.setPanNumber(masterTable.getPanNumber());
			}
			if(masterTable.getIecCodeNumber() != null){
				existingMaster.setIecCodeNumber(masterTable.getIecCodeNumber());
			}
			if(masterTable.getGstNumber() != null){
				existingMaster.setGstNumber(masterTable.getGstNumber());
			}
			if(masterTable.getUserName() != null){
				existingMaster.setUserName(masterTable.getUserName());
			}
			if(masterTable.getRole() != null){
				existingMaster.setRole(masterTable.getRole());
			}
			if(masterTable.getProfileImages() != null){
				Set<Image> images = imageRepository.findImagesByMasterTableId(masterTable.getMasterTableId());
				Set<Image> imagesList = masterTable.getProfileImages();
				existingMaster.setProfileImages(null);
				for (Image image : imagesList) {
					image.setMasterTable(existingMaster);
					image = imageRepository.save(image);
					images.add(image);
				}
				existingMaster.setProfileImages(images);
			}
			if(masterTable.getSellerDescription() != null){
				/*SellerDescription sellerDescription = masterTable.getSellerDescription();
				
				//sellerDescription.getMasterTable().setMasterTableId(masterTable.getMasterTableId());
				//sellerDescription = sellerDescriptionRepository.save(sellerDescription);
				sellerDescription = updateSellerDescription(sellerDescription, masterTable.getMasterTableId());
				existingMaster.setSellerDescription(sellerDescription);*/
				
				SellerDescription sellerDescription = masterTable.getSellerDescription();
				if(existingMaster.getSellerDescription()!=null){
					sellerDescription.setSellerDescriptionId(existingMaster.getSellerDescription().getSellerDescriptionId());
					sellerDescription = sellerDescriptionRepository.save(sellerDescription);
					existingMaster.setSellerDescription(sellerDescription);
				}else if(existingMaster.getSellerDescription()==null){
					existingMaster.setSellerDescription(null);
					sellerDescription.setMasterTable(existingMaster);
					sellerDescription=sellerDescriptionRepository.save(sellerDescription);
					existingMaster.setSellerDescription(sellerDescription);
				}
			}
			if(masterTable.getBuyerDescription() != null){
				BuyerDescription buyerDescription = masterTable.getBuyerDescription();
				if(existingMaster.getBuyerDescription()!=null){
					buyerDescription.setBuyerDescriptionId(existingMaster.getBuyerDescription().getBuyerDescriptionId());
					buyerDescription = buyerDescriptionRepository.save(buyerDescription);
					existingMaster.setBuyerDescription(buyerDescription);
				}else if(existingMaster.getBuyerDescription()==null){
					existingMaster.setBuyerDescription(null);
					buyerDescription.setBuyer(existingMaster);
					buyerDescription=buyerDescriptionRepository.save(buyerDescription);
					existingMaster.setBuyerDescription(buyerDescription);
				}
			}
			if(masterTable.getAddressDetails() != null){
				/*Set<AddressDetails> addressDetails = masterTable.getAddressDetails();
				for (AddressDetails addressDetails2 : addressDetails) {
					addressDetails.remove(addressDetails2);
					MasterTable addressMasterTable = new MasterTable();
					addressMasterTable.setMasterTableId(masterTable.getMasterTableId());
					addressDetails2.setMasterTable(addressMasterTable);
					addressDetails2 = addressDetailsRepository.save(addressDetails2);
					addressDetails.add(addressDetails2);
				}
				existingMaster.setAddressDetails(addressDetails);*/
				
				Set<AddressDetails> addressDetails = masterTable.getAddressDetails();
				Set<AddressDetails> addressDetailsList= existingMaster.getAddressDetails();
				for (AddressDetails addressDetails2 : addressDetails) {
						existingMaster.setAddressDetails(null);
						if(addressDetails2.getAddressDetailsId()!=0){
							addressDetailsList.remove(addressDetails2);
						}
						addressDetails2 = addressDetailsRepository.save(addressDetails2);
						addressDetailsList.add(addressDetails2);
				}
				existingMaster.setAddressDetails(addressDetailsList);
			}
			if(masterTable.getPaymentMethod() != null){
				existingMaster.setPaymentMethod(masterTable.getPaymentMethod());
			}
			if(masterTable.getSellerProducts() != null){
				existingMaster.setSellerProducts(masterTable.getSellerProducts());
			}
			if(masterTable.getLanguages() != null){
				existingMaster.setLanguages(masterTable.getLanguages());
			}
			if(masterTable.getCurrencies() != null){
				existingMaster.setCurrencies(masterTable.getCurrencies());
			}
			if(masterTable.getEnquiry() != null){
				existingMaster.setEnquiry(masterTable.getEnquiry());
			}
			if(masterTable.getTransaction() != null){
				existingMaster.setTransaction(masterTable.getTransaction());
			}
			if(masterTable.getNotifications() != null){
				existingMaster.setNotifications(masterTable.getNotifications());
			}
		}
		masterTable = masterTableRepository.save(existingMaster);
		return masterTable;
	}
	
	@Override
	public Object searchProduct(String searchProduct) {
		SubCategory subCategory = subCategoryRepository.findBySubCategoryName(searchProduct);
		if(!(subCategory==null)){
			return subCategory;
		}
		Product product = productRepository.findByProductName(searchProduct);
		if(!(product==null)){
			return product;
		}
		
		SubProduct subProduct = subProductRepository.findBySubProductName(searchProduct);
		if(!(subProduct==null)){
			return subProduct;
		}
		return null;
	}

	@Override
	public Set<MasterTable> searchSellers(Object object) {
		Set<MasterTable> sellerList = new HashSet<MasterTable>();
		SubProduct subProduct = new SubProduct();
		List<SellerProduct> sellerProductList=new ArrayList<SellerProduct>();
		if(object instanceof SubProduct){
			subProduct = (SubProduct) object;
			sellerProductList = 
					sellerProductRepository.findBySubProductId(subProduct.getSubProductId());
		}else if(object instanceof Product){
			Product product = (Product) object;
			List<SubProduct> subProductList = product.getSubProduct();
			System.out.println("sellerproductlist is "+sellerProductList);
			for (SubProduct subProduct2 : subProductList) {
				List<SellerProduct> sellerProductList1 = 
						sellerProductRepository.findBySubProductId(subProduct2.getSubProductId());
				System.out.println("sellerproductlist is "+sellerProductList);
				sellerProductList.addAll(sellerProductList1);
			}
		}else if(object instanceof SubCategory){
			SubCategory subCategory = (SubCategory) object;
			List<Product> productList = subCategory.getProduct();
			for (Product product : productList) {
				List<SubProduct> subProductList = product.getSubProduct();
				for (SubProduct subProduct2 : subProductList) {
					List<SellerProduct> sellerProductList1 = 
							sellerProductRepository.findBySubProductId(subProduct2.getSubProductId());
					System.out.println("sellerproductlist is "+sellerProductList);
					sellerProductList.addAll(sellerProductList1);
				}
			}
		}
		for (SellerProduct sellerProduct : sellerProductList) {
			System.out.println("seller is "+sellerProduct);
			MasterTable seller = 
					masterTableRepository.findByMasterTableId(sellerProduct.getMasterTable().getMasterTableId());
			sellerList.add(seller);
		}
		System.out.println("seller list is "+sellerList);
		return sellerList;
	}
	
	@Override
	public List<MasterTable> enquiryProduct(Enquiry enquiry) {
		enquiry = enquiryRepository.save(enquiry);
		List<SellerProduct> sellerProductList=new ArrayList<SellerProduct>();
		List<MasterTable> sellerList = new ArrayList<MasterTable>();
		if(enquiry.getSellerProduct().getSellerProductId()!=0){
			SellerProduct sellerProduct = sellerProductRepository.findOne(enquiry.getSellerProduct().getSellerProductId());
			MasterTable seller = masterTableRepository.findByMasterTableId(sellerProduct.getMasterTable().getMasterTableId());
			sellerList.add(seller);
		}else if(enquiry.getSubProduct().getSubProductId()!=0){
			sellerProductList = 
					sellerProductRepository.findBySubProductId(enquiry.getSubProduct().getSubProductId());
			for (SellerProduct sellerProduct : sellerProductList) {
				MasterTable seller = 
						masterTableRepository.findByMasterTableId(sellerProduct.getMasterTable().getMasterTableId());
				sellerList.add(seller);
			}
		}
		
		for (MasterTable masterTable : sellerList) {
			SellerEnquiry sellerEnquiry = new SellerEnquiry();
			SellerEnquiryPk sellerEnquiryPk = new SellerEnquiryPk();
			sellerEnquiryPk.setSeller(masterTable);
			sellerEnquiryPk.setEnquiry(enquiry);
			sellerEnquiry.setId(sellerEnquiryPk);
			sellerEnquiry.setActive(true);
			sellerEnquiryRepository.save(sellerEnquiry);
		}
		return sellerList;
	}

	@Override
	public Set<MasterTable> getSelectedSuppliers() {
		Set<MasterTable> masterTables = new HashSet<MasterTable>();
			int count=1;
			masterTables = masterTableRepository.getSelectedSuppliers(count);
			if(masterTables==null){
				log.info("in a ");
				masterTables = new HashSet<MasterTable>();
			}
			while((masterTables.size()<=4 && count <=3)){
				log.info("in count "+count);
				masterTables.addAll(masterTableRepository.getSelectedSuppliers(count+1));
				count++;
			}
			/*while((masterTables == null)&&count<=3){
				masterTables=masterTableRepository.getSelectedSuppliers(count+1);
				count++;
			}*/
			return masterTables;
			/*if((!(null == masterTables)) && masterTables.size()>=5){
				return masterTables;
			}else if((!(null == masterTables)) && masterTables.size()<5){
				
			}
		}
		return null;*/
	}

	@Override
	public Set<MasterTable> getUserByRegion(String region , int roleId) {
		if(roleId == 2){
			return masterTableRepository.findByState(region);
		}else if(roleId == 3){
			return masterTableRepository.findByCountry(region);	
		}
		//return masterTableRepository.findUserByRegion(region , roleId);
		return null;
	}

	@Override
	public List<String> getResultList() {
		List<String> searchList = new ArrayList<String>();
		
		List<String> subCategories = subCategoryRepository.findSubCategoryNames();
		searchList.addAll(subCategories);
		List<String> products = productRepository.findProductNames();
		searchList.addAll(products);
		List<String> subProducts = subProductRepository.findSubProductNames();
		searchList.addAll(subProducts);
		List<String> sellerProducts = sellerProductRepository.findSellerProductNames();
		searchList.addAll(sellerProducts);
		
		return searchList;
	}

	public SellerDescription updateSellerDescription(SellerDescription sellerDescription, long id){
		sellerDescription.getMasterTable().setMasterTableId(id);
		SellerDescription sellerDescription2 = sellerDescriptionRepository.findBySellerId(id);
		if(sellerDescription2!=null){
			sellerDescription.setSellerDescriptionId(sellerDescription2.getSellerDescriptionId());
		}
		return sellerDescriptionRepository.save(sellerDescription);
	}
}
