package com.globozor.domain.services;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.json.simple.JSONArray;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.globozor.domain.dtos.CompanyProfileDto;
import com.globozor.domain.entity.BuyerRating;
import com.globozor.domain.entity.CompanyProfile;
import com.globozor.domain.entity.CustomerDetail;
import com.globozor.domain.entity.Dispute;
import com.globozor.domain.entity.Feedback;
import com.globozor.domain.entity.MasterTable;
import com.globozor.domain.entity.Notification;
import com.globozor.domain.entity.SampleRequest;
import com.globozor.domain.entity.SellerDescription;
import com.globozor.domain.entity.SellerEnquiry;
import com.globozor.domain.entity.SellerEnquiryResponse;
import com.globozor.domain.entity.SellerProduct;
import com.globozor.domain.entity.SellerProductImage;
import com.globozor.domain.entity.SellerRating;
import com.globozor.domain.entity.TradeShow;
import com.globozor.domain.entity.Transaction;
import com.globozor.domain.exceptions.SellerException;
import com.globozor.domain.repository.BuyerRatingRepository;
import com.globozor.domain.repository.CompanyProfileRespository;
import com.globozor.domain.repository.CustomerDetailRepository;
import com.globozor.domain.repository.DisputeRepository;
import com.globozor.domain.repository.NotificationRepository;
import com.globozor.domain.repository.SampleRequestRepository;
import com.globozor.domain.repository.SellerDescriptionRepository;
import com.globozor.domain.repository.SellerEnquiryRepository;
import com.globozor.domain.repository.SellerEnquiryResponseRepository;
import com.globozor.domain.repository.SellerProductImageRepository;
import com.globozor.domain.repository.SellerProductRepository;
import com.globozor.domain.repository.SellerRatingRepository;
import com.globozor.domain.repository.TradeShowRepository;
import com.globozor.domain.repository.TransactionRepository;

@Service
public class SellerServiceImpl implements SellerService{

	@Autowired
	SellerEnquiryResponseRepository sellerEnquiryResponseRepository;
	
	@Autowired
	NotificationRepository notificationRepository;
	
	@Autowired
	SellerProductRepository sellerProductRepository;
	
	@Autowired
	SellerEnquiryRepository sellerEnquiryRepository;
	
	@Autowired
	SellerDescriptionRepository sellerDescriptionRepository;
	
	@Autowired
	CompanyProfileRespository companyProfileRespository;
	
	@Autowired
	TradeShowRepository tradeShowRepository;
	
	@Autowired
	CustomerDetailRepository customerDetailRepository;
	
	@Autowired
	DisputeRepository disputeRepository;
	
	/*@Autowired
	FeedbackRepository feedbackRepository;*/
	
	@Autowired
	BuyerRatingRepository buyerRatingRepository;
	
	@Autowired
	SellerRatingRepository sellerRatingRepository;
	
	@Autowired
	TransactionRepository transactionRepository;
	
	@Autowired
	SampleRequestRepository sampleRequestRepository;
	
	@Autowired
	SellerProductImageRepository sellerProductImageRepository;
	
	@Override
	public SellerEnquiryResponse responseEnquiry(
			SellerEnquiryResponse sellerEnquiryResponse) {
		sellerEnquiryResponse = sellerEnquiryResponseRepository.save(sellerEnquiryResponse);
		Set<Notification> notifications = sellerEnquiryResponse.getEnquiry().getBuyer().getNotifications();
		Notification notification = new Notification();
		notification.setMasterTable(sellerEnquiryResponse.getEnquiry().getBuyer());
		notification.setNotificationDesc("New response for your enquiry with id "+sellerEnquiryResponse.getEnquiry().getEnquiryId()+" from "+sellerEnquiryResponse.getSeller().getUserName());
		notification.setNotificationType("RFQ response");
		notification.setActive(true);
		notification.setCreatedTime(new Date());
		notification = notificationRepository.save(notification);
		notifications.add(notification);
		sellerEnquiryResponse.getEnquiry().getBuyer().setNotifications(notifications);
		return sellerEnquiryResponse;
	}

	@Override
	public List<Notification> getNotifications(MasterTable masterTable) {
		return notificationRepository.findAllNotifications(masterTable.getMasterTableId());
	}

	@Override
	public SellerProduct addSellerProduct(SellerProduct sellerProduct,MasterTable masterTable) {
		sellerProduct.setStatus("pending_approval");
		sellerProduct.setActive(true);
		sellerProduct.setMasterTable(masterTable);
		Set<SellerProductImage> sellerProductImages = new HashSet<SellerProductImage>();
		if(sellerProduct.getSellerProductImage()!=null){
			sellerProductImages = sellerProduct.getSellerProductImage();
			sellerProduct.setSellerProductImage(null);
		}
		sellerProduct = sellerProductRepository.save(sellerProduct);
		if(sellerProductImages!=null){
			Set<SellerProductImage> productImages = new HashSet<SellerProductImage>();
			for (SellerProductImage sellerProductImage : sellerProductImages) {
				sellerProductImage.setSellerProduct(sellerProduct);
				sellerProductImage = sellerProductImageRepository.save(sellerProductImage);
				productImages.add(sellerProductImage);
			}
			sellerProduct.setSellerProductImage(productImages);
		}
		return sellerProduct;
	}

	@Override
	public String removeSellerProduct(long sellerProductId,MasterTable masterTable) throws SellerException{
		SellerProduct sellerProduct = sellerProductRepository.findBySellerProductId(sellerProductId);
		if(sellerProduct.getMasterTable().getMasterTableId() == masterTable.getMasterTableId()){
			sellerProduct.setActive(false);
			String message = "";
			try {
				sellerProductRepository.save(sellerProduct);
				message = "Product successfully removed";
			} catch (Exception e) {
				message = "Unable to delete object";
				throw new SellerException("Unable to delete product");
			}
			return message;
		}else{
			throw new SellerException("You are not allowed to remove this product");
		}
	}

	@Override
	public List<SellerProduct> getSellerProduct(MasterTable masterTable , String status) {
		return sellerProductRepository.findByStatus(status , masterTable.getMasterTableId());
	}

	@Override
	public List<SellerEnquiry> getSellerEnquiry(MasterTable masterTable) {
		return sellerEnquiryRepository.findByIsActive(true,masterTable.getMasterTableId());
	}

	@Override
	public List<SellerProduct> getSellerProductShowCase(MasterTable masterTable) {
		int priority=0;
		int membershipTypeId=7;
		if(membershipTypeId==1){
			priority = 40;
		}else if(membershipTypeId==2){
			priority = 25;
		}else if(membershipTypeId==3){
			priority=15;
		}else{
			priority=1;
		}
		return sellerProductRepository.getSellerProductShowCase(priority,masterTable.getMasterTableId());
	}

	@Override
	public SellerProduct setSellerProductPriority(long sellerProductId,
			int priority , MasterTable masterTable) throws SellerException {
		SellerProduct sellerProduct = sellerProductRepository.findOne(sellerProductId);
		if(sellerProduct!=null){
			if(sellerProduct.getMasterTable().getMasterTableId()==masterTable.getMasterTableId()){
				sellerProduct.setPriority(priority);
				sellerProduct = sellerProductRepository.save(sellerProduct);
			}else{
				throw new SellerException("You are not allowed to change priority of this product");
			}
			return sellerProduct;
		}else{
			throw new SellerException("You are not allowed to change priority of this product");
		}
	}

	@Override
	public SellerEnquiry rejectEnquiry(long enquiryId) {
		SellerEnquiry sellerEnquiry = sellerEnquiryRepository.findByEnquiry(enquiryId);
		sellerEnquiry.setActive(false);
		sellerEnquiry = sellerEnquiryRepository.save(sellerEnquiry); 
		return sellerEnquiry;
	}

	@Override
	public SellerDescription getSellerDescription(MasterTable masterTable) {
		SellerDescription sellerDescription = sellerDescriptionRepository.findBySellerId(masterTable.getMasterTableId());
		return sellerDescription;
	}

	@Override
	public TradeShow saveTradeShow(TradeShow tradeShow) {
		tradeShow = tradeShowRepository.save(tradeShow);
		return tradeShow;
	}

	@Override
	public CustomerDetail saveCustomerDetail(CustomerDetail customerDetail) {
		customerDetail = customerDetailRepository.save(customerDetail);
		return customerDetail;
	}

	/*@Override
	public CompanyProfileDto saveCompanyProfile(JSONArray companyProfileDto) {
		CompanyProfile companyProfile = (CompanyProfile) companyProfileDto.get(0);
		companyProfile = companyProfileRespository.save(companyProfile);
		System.out.println("com is "+companyProfile);
		if(companyProfileDto.get(1)!=null){
			TradeShow tradeShow = (TradeShow) companyProfileDto.get(1);
			tradeShow.setCompanyProfile(companyProfile);
			tradeShow = saveTradeShow(tradeShow);
			System.out.println("trade show is "+tradeShow);
		}
		if(companyProfileDto.get(2)!=null){
			CustomerDetail customerDetail = (CustomerDetail) companyProfileDto.get(2);
			customerDetail.setCompanyProfile(companyProfile);
			customerDetail=saveCustomerDetail(customerDetail);
			System.out.println("customer is "+customerDetail);
		}
		return new CompanyProfileDto();
		
		CompanyProfile companyProfile = companyProfileDto.getCompanyProfile();
		CompanyProfileDto profileDto = new CompanyProfileDto();
		companyProfile = companyProfileRespository.save(companyProfile);
		profileDto.setCompanyProfile(companyProfile);
		if(companyProfileDto.getTradeShow()!=null){
			TradeShow tradeShow = companyProfileDto.getTradeShow();
			tradeShow.setCompanyProfile(companyProfile);
			tradeShow = saveTradeShow(tradeShow);
			profileDto.setTradeShow(tradeShow);
		}
		if(companyProfileDto.getCustomerDetail()!=null){
			CustomerDetail customerDetail = companyProfileDto.getCustomerDetail();
			customerDetail.setCompanyProfile(companyProfile);
			customerDetail=saveCustomerDetail(customerDetail);
			profileDto.setCustomerDetail(customerDetail);
		}
		return profileDto;
	}*/

	@Override
	public Dispute createDispute(Dispute dispute,MasterTable masterTable) throws SellerException {
		Transaction transaction = transactionRepository.findOne(dispute.getTransaction().getTransactionId());
		if(transaction!=null&&transaction.getSeller().getMasterTableId()==masterTable.getMasterTableId()){
			dispute.setRaisedBy(masterTable);
			dispute.setRaisedFor(dispute.getTransaction().getBuyer());
			return disputeRepository.save(dispute);
		}
		else if(transaction==null){
			throw new SellerException("You can not raise a dispute for this transaction");
		}
		else{
			throw new SellerException("You can not raise a dispute for this transaction");
		}
	}

	@Override
	public List<Dispute> getAllDisputes(MasterTable masterTable,String type) throws SellerException {
		if(type.equals("raised")){
			return disputeRepository.findAllRaisedBy(masterTable.getMasterTableId());
		}else if(type.equals("received")){
			return disputeRepository.findAllRecievedBy(masterTable.getMasterTableId());
		}else{
			throw new SellerException("No dispute found");
		}
	}

	/*
	@Override
	public Feedback createFeedback(Feedback feedback) {
		return feedbackRepository.save(feedback);
	}

	@Override
	public List<Feedback> getAllFeedbacks(MasterTable masterTable) {
		return feedbackRepository.findAllById();
	}
*/
	@Override
	public BuyerRating rateBuyer(BuyerRating buyerRating,MasterTable masterTable) throws SellerException {
		Transaction transaction = transactionRepository.findOne(buyerRating.getTransaction().getTransactionId());
		if(transaction!=null&&transaction.getSeller().getMasterTableId()==masterTable.getMasterTableId()){
			return buyerRatingRepository.save(buyerRating);
		}else if(transaction==null){
			throw new SellerException("You have not transacted with this Buyer");
		}else{
			throw new SellerException("You have not transacted with this Buyer");
		}
	}

	@Override
	public List<SellerRating> getAllSellerRating(MasterTable masterTable) {
		return sellerRatingRepository.findAllById(masterTable.getMasterTableId());
	}

	@Override
	public List<Transaction> getAllSellerOrders(MasterTable masterTable) {
		return transactionRepository.getAllSellerOrder(masterTable.getMasterTableId());
	}

	@Override
	public List<SampleRequest> getAllSampleRequest(MasterTable masterTable,
			String status) {
		return sampleRequestRepository.findSampleByStatusSeller(masterTable.getMasterTableId(),status);
	}

	@Override
	public CompanyProfile saveCompanyProfile(CompanyProfile companyProfile) {
		CompanyProfile companyProfile2 = 
				companyProfileRespository.findUnique	(companyProfile.getMasterTable().getMasterTableId());
		if(companyProfile2 == null){
			List<TradeShow> tradeShows = companyProfile.getTradeShow();
			List<CustomerDetail> customerDetails = companyProfile.getCustomerDetails();
			List<TradeShow> tradeShows2 = new ArrayList<TradeShow>();
			List<CustomerDetail> customerDetails2 = new ArrayList<CustomerDetail>();
			companyProfile.setTradeShow(null);
			companyProfile.setCustomerDetails(null);
			companyProfile = companyProfileRespository.save(companyProfile);
			for (TradeShow tradeShow : tradeShows) {
				tradeShow.setCompanyProfile(companyProfile);
				tradeShow = tradeShowRepository.save(tradeShow);
				tradeShows2.add(tradeShow);
			}
			for (CustomerDetail customerDetail : customerDetails) {
				customerDetail.setCompanyProfile(companyProfile);
				customerDetail = customerDetailRepository.save(customerDetail);
				customerDetails2.add(customerDetail);
			}
			companyProfile.setTradeShow(tradeShows2);
			companyProfile.setCustomerDetails(customerDetails2);
			return companyProfile;
		}else{
			companyProfile.setCompanyProfileId(companyProfile2.getCompanyProfileId());
			return companyProfileRespository.save(companyProfile);
		}
	}

	@Override
	public SampleRequest setSampleRequestStatus(String status,
			long sampleRequestId, MasterTable masterTable) throws SellerException {
		SampleRequest sampleRequest = sampleRequestRepository.findOne(sampleRequestId);
		if(sampleRequest.getSellerEnquiryResponse().getSeller().getMasterTableId()==masterTable.getMasterTableId()){
			sampleRequest.setStatus(status);
			return sampleRequestRepository.save(sampleRequest);
		}else{
			throw new SellerException("You are not authorised to change the status of this request");
		}
	}

}
