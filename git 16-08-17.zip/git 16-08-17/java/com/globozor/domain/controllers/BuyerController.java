package com.globozor.domain.controllers;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.globozor.domain.dtos.ResponseDto;
import com.globozor.domain.entity.BuyerRating;
import com.globozor.domain.entity.CompanyProfile;
import com.globozor.domain.entity.Dispute;
import com.globozor.domain.entity.Enquiry;
import com.globozor.domain.entity.Favourite;
import com.globozor.domain.entity.MasterTable;
import com.globozor.domain.entity.SampleRequest;
import com.globozor.domain.entity.SellerEnquiryResponse;
import com.globozor.domain.entity.SellerRating;
import com.globozor.domain.entity.Transaction;
import com.globozor.domain.services.BuyerService;
import com.globozor.domain.services.EmailSender;

@RestController
@RequestMapping("/buyer")
public class BuyerController {

	@Autowired
	BuyerService buyerService;
	
	@Autowired
	EmailSender emailSender;
	
	@RequestMapping(value="/getBuyerAllOrders")
	public List<Transaction> getAllOrders(HttpServletRequest request){
		HttpSession session = request.getSession(false);
		ResponseDto responseDto = new ResponseDto();
		if(session!=null){
			Object object = session.getAttribute("mastertable");
			MasterTable masterTable = (MasterTable) object;
			return buyerService.getAllOrders(masterTable);
		}
		return null;
	}
	
	@RequestMapping("/rateSeller")
	public SellerRating rateSeller(@RequestBody SellerRating sellerRating){
		return buyerService.rateSeller(sellerRating);
	}
	
	@RequestMapping("/getBuyerAllRatings")
	public List<BuyerRating> getAllBuyerRating(HttpServletRequest request){
		HttpSession session = request.getSession(false);
		ResponseDto responseDto = new ResponseDto();
		if(session!=null){
			Object object = session.getAttribute("mastertable");
			MasterTable masterTable = (MasterTable) object;
			return buyerService.getAllBuyerRating(masterTable);
		}
		return null;
	}
	
	@RequestMapping("/createDispute")
	public Dispute createDispute(@RequestBody Dispute dispute){
		return buyerService.createDispute(dispute);
	}
	
	@RequestMapping("/getBuyerAllDisputes")
	public List<Dispute> getAllDisputes(HttpServletRequest request){
		HttpSession session = request.getSession(false);
		ResponseDto responseDto = new ResponseDto();
		if(session!=null){
			Object object = session.getAttribute("mastertable");
			MasterTable masterTable = (MasterTable) object;
			return buyerService.getAllDisputes(masterTable);
		}
		return null;
	}
	
	@RequestMapping("/getBuyerAllSampleRequest")
	public List<SampleRequest> getAllSampleRequest(@RequestParam String status , HttpServletRequest request){
		HttpSession session = request.getSession(false);
		ResponseDto responseDto = new ResponseDto();
		if(session!=null){
			Object object = session.getAttribute("mastertable");
			MasterTable masterTable = (MasterTable) object;
			return buyerService.getAllSampleRequest(masterTable,status);
		}
		return null;
	}
	
	@RequestMapping("/getBuyerAllEnquiries")
	public List<Enquiry> getBuyerAllEnquiries(HttpServletRequest request){
		HttpSession session = request.getSession(false);
		ResponseDto responseDto = new ResponseDto();
		if(session!=null){
			Object object = session.getAttribute("mastertable");
			MasterTable masterTable = (MasterTable) object;
			return buyerService.getBuyerAllEnquiries(masterTable);
		}
		return null;
	}
	
	@RequestMapping("/getSellerEnquiryResponse")
	//two types of response all responses plus negotiated responses
	public List<SellerEnquiryResponse> getSellerEnquiryResponse(@RequestParam String type , HttpServletRequest request){
		HttpSession session = request.getSession(false);
		ResponseDto responseDto = new ResponseDto();
		if(session!=null){
			Object object = session.getAttribute("mastertable");
			MasterTable masterTable = (MasterTable) object;
			return buyerService.getSellerEnquiryResponse(type,masterTable);
		}
		return null;
	}
	
	@RequestMapping("/saveBuyerCompanyProfile")
	public CompanyProfile saveCompanyProfile(@RequestBody CompanyProfile companyProfile , HttpServletRequest request){
		HttpSession session = request.getSession(false);
		ResponseDto responseDto = new ResponseDto();
		if(session!=null){
			Object object = session.getAttribute("mastertable");
			MasterTable masterTable = (MasterTable) object;
			companyProfile.setMasterTable(masterTable);
			return buyerService.saveCompanyProfile(companyProfile);
		}
		return null;
	}
	
	@SuppressWarnings("unchecked")
	@RequestMapping("/subscribeNow")
	public void subscribeNow(HttpServletRequest request){
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("to", "");
		jsonObject.put("from", "");
		jsonObject.put("subject", "");
		jsonObject.put("text", "");
		HttpSession session = request.getSession(false);
		ResponseDto responseDto = new ResponseDto();
		if(session!=null){
			Object object = session.getAttribute("mastertable");
			MasterTable masterTable = (MasterTable) object;
			emailSender.sendEmail(jsonObject, masterTable);
		}
	}
	
	@RequestMapping("/addFavourite")
	public Favourite addFavourite(@RequestParam long id , HttpServletRequest request){
		HttpSession session = request.getSession(false);
		ResponseDto responseDto = new ResponseDto();
		if(session!=null){
			Object object = session.getAttribute("mastertable");
			MasterTable masterTable = (MasterTable) object;
			return buyerService.addFavourite(masterTable,id);
		}
		return null;
	}
	
	@RequestMapping("/getAllFavourites")
	public List<Favourite> getAllFavourites(HttpServletRequest request){
		HttpSession session = request.getSession(false);
		ResponseDto responseDto = new ResponseDto();
		if(session!=null){
			Object object = session.getAttribute("mastertable");
			MasterTable masterTable = (MasterTable) object;
			return buyerService.getAllFavourites(masterTable);
		}
		return null;
	}
}
