package com.globozor.domain.controllers;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.globozor.domain.dtos.MasterTableDto;
import com.globozor.domain.dtos.ResponseDto;
import com.globozor.domain.dtos.SellerDto;
import com.globozor.domain.entity.Enquiry;
import com.globozor.domain.entity.MasterTable;
import com.globozor.domain.entity.PaymentMethod;
import com.globozor.domain.entity.SellerProduct;
import com.globozor.domain.entity.SubProduct;
import com.globozor.domain.exceptions.MasterTableException;
import com.globozor.domain.services.EntityDtoMapper;
import com.globozor.domain.services.UserService;

@RestController
@RequestMapping("/user")
public class UserController {

	@Autowired
	UserService userService;
	
	@Autowired
	EntityDtoMapper mapper;
	
	@RequestMapping(value="/login",method=RequestMethod.POST)
	private ResponseDto login(@RequestBody MasterTable masterTable , HttpServletRequest request){
		HttpSession session = request.getSession(true);
		ResponseDto responseDto = new ResponseDto();
		try {
			List<Object> objects = new ArrayList<Object>();
			masterTable = userService.login(masterTable);
			session.setAttribute("mastertable", masterTable);
			MasterTableDto masterTableDto = mapper.masterTableEntityToDto(masterTable);
			objects.add(masterTableDto);
			responseDto = new ResponseDto(objects);
			return responseDto;
		} catch (MasterTableException e) {
			responseDto = new ResponseDto(e.getMessage());
			return responseDto;
		}
	}
	
	/*@RequestMapping(value="/signup",method=RequestMethod.POST)
	private MasterTable signup(@RequestBody MasterTableDto masterTableDto){
		MasterTable masterTable = new MasterTable();
		try {
			masterTable = entityDtoMapper.masterTableDtoToEntity(masterTableDto);
			masterTable = userService.signup(masterTable);
		} catch (MasterTableException e) {
			e.printStackTrace();
		}
		System.out.println("master is "+masterTable);
		return masterTable;
	}*/
	
	@RequestMapping(value="/signup",method=RequestMethod.POST)
	private ResponseDto signup(@RequestBody MasterTable masterTable){
		ResponseDto responseDto = new ResponseDto();
		Set<PaymentMethod> paymentMethods = masterTable.getPaymentMethod();
		if(paymentMethods!=null){
			Iterator<PaymentMethod> iterator = paymentMethods.iterator();
			while(iterator.hasNext()){
				PaymentMethod paymentMethod = iterator.next();
				if(paymentMethod.getPaymentMethodId()==0){
					iterator.remove();
				}
			}
		}
		try {
			masterTable = userService.signup(masterTable);
			System.out.println("mastertable is "+masterTable);
			MasterTableDto masterTableDto = mapper.masterTableEntityToDto(masterTable);
			List<Object> objects = new ArrayList<Object>();
			objects.add(masterTableDto);
			responseDto = new ResponseDto(objects);
			return responseDto;
		} catch (MasterTableException e) {
			responseDto = new ResponseDto(e.getMessage());
			return responseDto;
		}
	}
	
	@RequestMapping(value="updateUser",method=RequestMethod.POST)
	private ResponseDto updateUser(@RequestBody MasterTable masterTable){
		ResponseDto responseDto=new ResponseDto();
		masterTable= userService.updateUser(masterTable);
		MasterTableDto masterTableDto=mapper.masterTableEntityToDto(masterTable);
		List<Object> objects = new ArrayList<Object>();
		objects.add(masterTableDto);
		responseDto = new ResponseDto(objects);
		return responseDto;
	}
	
	@RequestMapping(value="/searchProduct",method=RequestMethod.GET)
	public ResponseDto searchProduct(@RequestParam String searchProduct){
		ResponseDto responseDto=new ResponseDto();
		Set<SellerDto> sellerDtos = new HashSet<SellerDto>();
		Object object = userService.searchProduct(searchProduct);
		Set<MasterTable> sellerList = userService.searchSellers(object);
		if(object instanceof SubProduct || object instanceof SellerProduct){
			for (MasterTable masterTable : sellerList) {
				//Set<SellerProduct> sellerProducts = masterTable.getSellerProducts();
				Iterator<SellerProduct> iterator = masterTable.getSellerProducts().iterator();
				//for (SellerProduct sellerProduct : sellerProducts) {
				while(iterator.hasNext()){
					SellerProduct sellerProduct = iterator.next();
					if(!(sellerProduct.getSellerProductName().equals(searchProduct))){
						iterator.remove();
					}
				}
				//}
			}
		}
		for (MasterTable masterTable : sellerList) {
			SellerDto sellerDto1 = mapper.sellerEntityToDto(masterTable);
			sellerDtos.add(sellerDto1);
		}
		List<Object> objects = new ArrayList<Object>();
		objects.add(sellerDtos);
		responseDto = new ResponseDto(objects);
		return responseDto;
	}
	
	@RequestMapping(value="/enquiryProduct",method=RequestMethod.POST)
	public ResponseDto enquiryProduct(@RequestBody Enquiry enquiry,HttpServletRequest request){

		/*try {
			emailSender.sendEmail();
		} catch (MailException e) {
			e.printStackTrace();
		}*/
		/*try {
			sendOtpService.sendOtp();
		} catch (Exception e) {
			e.printStackTrace();
		}*/
		
		HttpSession session = request.getSession(false);
		ResponseDto responseDto = new ResponseDto();
		if(session!=null){
			Object object = session.getAttribute("mastertable");
			MasterTable masterTable = (MasterTable) object;
			if(masterTable.getRole().getRoleId()==3){
				List<MasterTable> sellerList = userService.enquiryProduct(enquiry);
				List<MasterTableDto> sellerDtos = new ArrayList<MasterTableDto>();
				for (MasterTable seller : sellerList) {
					MasterTableDto sellerDto = mapper.masterTableEntityToDto(seller);
					sellerDtos.add(sellerDto);
				}
				List<Object> objects = new ArrayList<Object>();
				objects.add(sellerDtos);
				responseDto.setObject(objects);
				responseDto.setMessage("Your RFQ has been sent to respective Sellers. They will revert you back soon!!!");
			}else{
				responseDto = new ResponseDto("Seller are not allowed for enquiry");
			}
		}
		return responseDto;
	}
	
	@RequestMapping(value="/getSelectedSuppliers")
	public ResponseDto getSelectedSuppliers(){
		ResponseDto responseDto = new ResponseDto();
		Set<SellerDto> sellerDtos = new HashSet<SellerDto>();
		Set<MasterTable> sellerList = userService.getSelectedSuppliers();
		for (MasterTable masterTable : sellerList) {
			SellerDto sellerDto1 = mapper.sellerEntityToDto(masterTable);
			sellerDtos.add(sellerDto1);
		}
		List<Object> objects = new ArrayList<Object>();
		objects.add(sellerDtos);
		responseDto = new ResponseDto(objects);
		return responseDto;
	}
	
	@RequestMapping(value="/getSuppliersByRegion") 
	public ResponseDto getSuppliersByRegion(@RequestParam String region){
		ResponseDto responseDto = new ResponseDto();
		Set<SellerDto> sellerDtos = new HashSet<SellerDto>();
		Set<MasterTable> sellerList = userService.getUserByRegion(region , 2);
		for (MasterTable masterTable : sellerList) {
			SellerDto sellerDto1 = mapper.sellerEntityToDto(masterTable);
			sellerDtos.add(sellerDto1);
		}
		List<Object> objects = new ArrayList<Object>();
		objects.add(sellerDtos);
		responseDto = new ResponseDto(objects);
		return responseDto;
	}
	
	@RequestMapping(value="/getBuyerByRegion")
	public Set<MasterTable> getBuyerByRegion(@RequestParam String region){
		return userService.getUserByRegion(region , 3);
	}
	
	@RequestMapping(value="/getSearchList")
	public List<String> getSearchList(){
		return userService.getResultList();
	}
	
	@RequestMapping(value="/logout")
	public ResponseDto logout(HttpServletRequest request){
		HttpSession session = request.getSession(false);
		session.invalidate();
		ResponseDto responseDto = new ResponseDto();
		responseDto.setMessage("logged out successfully");
		return responseDto;
	}
}
