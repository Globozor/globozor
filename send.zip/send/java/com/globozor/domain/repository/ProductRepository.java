package com.globozor.domain.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.globozor.domain.entity.Category;
import com.globozor.domain.entity.Product;
import com.globozor.domain.entity.SubCategory;

public interface ProductRepository extends JpaRepository<Product, Long>{

	public List<Product> findBySubCategory(SubCategory subCategory);

	public Product findByProductName(String productName);
	@Query("select p.productName from Product p")
	public List<String> findProductNames();
}
