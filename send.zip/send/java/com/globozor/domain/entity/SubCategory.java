package com.globozor.domain.entity;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;


@Table(name="subcategory")
@Entity
public class SubCategory {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="subcategoryId")
	private long subCategoryId;
	
	@Column(name="subcategoryName")
	private String subCategoryName;
	
	@ManyToMany(mappedBy="subCategory")
	@JsonIgnore
	private Set<Category> category;
	
	@ManyToMany(cascade=CascadeType.ALL)
	@JoinTable(name = "subcategoryProduct", joinColumns = @JoinColumn(name = "subcategoryId", referencedColumnName = "subcategoryId"), inverseJoinColumns = @JoinColumn(name = "productId", referencedColumnName = "productId"))
	private List<Product> product;
	
	public SubCategory() {
		// TODO Auto-generated constructor stub
	}

	public SubCategory(long subCategoryId,
			String subCategoryName, List<Product> product) {
		super();
		this.subCategoryId = subCategoryId;
		this.subCategoryName = subCategoryName;
		this.product = product;
	}

	public long getSubCategoryId() {
		return subCategoryId;
	}

	public void setSubCategoryId(long subCategoryId) {
		this.subCategoryId = subCategoryId;
	}

	public String getSubCategoryName() {
		return subCategoryName;
	}

	public void setSubCategoryName(String subCategoryName) {
		this.subCategoryName = subCategoryName;
	}

	public List<Product> getProduct() {
		return product;
	}

	public void setProduct(List<Product> product) {
		this.product = product;
	}
	
	public Set<Category> getCategory() {
		return category;
	}

	public void setCategory(Set<Category> category) {
		this.category = category;
	}
}
