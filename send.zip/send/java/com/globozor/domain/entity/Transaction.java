package com.globozor.domain.entity;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Table(name="transaction")
@Entity(name="transaction")
public class Transaction {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column
	private long transactionId;
	
	@OneToOne
	@JoinColumn(name="sellerId")
	private MasterTable seller;
	
	@OneToOne
	@JoinColumn(name="sellerProductId")
	private SellerProduct sellerProduct;
	
	@OneToOne
	@JoinColumn(name="buyerId")
	private MasterTable buyer;
	
	@OneToOne
	@JoinColumn(name="paymentMethodId")
	private PaymentMethod paymentMethod;
	
	@Column
	private BigDecimal unitPrice;
	
	@Column
	private BigDecimal quantity;
	
	@Column
	private BigDecimal tradeAmount;
	
	@Column(nullable=true)
	private BigDecimal commission;
	
	@Column
	private String vesselName;
	
	@Column
	private Date expectedShippingDate;
	
	@Column
	private Date expectedArrivalDate;
	
	@Column
	private Date requestTradeDate;
	
	@Column
	private Date approvedTradeDate;
	
	@Column
	private Date closeTradeDate;
	
	@Column
	private boolean isApprovedTradeDate;
	
	@OneToOne(mappedBy="transaction")
	@JsonIgnore
	private TransactionFile transactionFile;
	
	public long getTransactionId() {
		return transactionId;
	}


	public void setTransactionId(long transactionId) {
		this.transactionId = transactionId;
	}

	public SellerProduct getSellerProduct() {
		return sellerProduct;
	}


	public void setSellerProduct(SellerProduct sellerProduct) {
		this.sellerProduct = sellerProduct;
	}

	public PaymentMethod getPaymentMethod() {
		return paymentMethod;
	}

	public void setPaymentMethod(PaymentMethod paymentMethod) {
		this.paymentMethod = paymentMethod;
	}

	public BigDecimal getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(BigDecimal unitPrice) {
		this.unitPrice = unitPrice;
	}

	public BigDecimal getQuantity() {
		return quantity;
	}

	public void setQuantity(BigDecimal quantity) {
		this.quantity = quantity;
	}

	public BigDecimal getTradeAmount() {
		return tradeAmount;
	}

	public void setTradeAmount(BigDecimal tradeAmount) {
		this.tradeAmount = tradeAmount;
	}

	public BigDecimal getCommission() {
		return commission;
	}

	public void setCommission(BigDecimal commission) {
		this.commission = commission;
	}

	public String getVesselName() {
		return vesselName;
	}

	public void setVesselName(String vesselName) {
		this.vesselName = vesselName;
	}

	public Date getExpectedShippingDate() {
		return expectedShippingDate;
	}

	public void setExpectedShippingDate(Date expectedShippingDate) {
		this.expectedShippingDate = expectedShippingDate;
	}

	public Date getExpectedArrivalDate() {
		return expectedArrivalDate;
	}

	public void setExpectedArrivalDate(Date expectedArrivalDate) {
		this.expectedArrivalDate = expectedArrivalDate;
	}

	public Date getRequestTradeDate() {
		return requestTradeDate;
	}

	public void setRequestTradeDate(Date requestTradeDate) {
		this.requestTradeDate = requestTradeDate;
	}

	public Date getApprovedTradeDate() {
		return approvedTradeDate;
	}

	public void setApprovedTradeDate(Date approvedTradeDate) {
		this.approvedTradeDate = approvedTradeDate;
	}

	public Date getCloseTradeDate() {
		return closeTradeDate;
	}

	public void setCloseTradeDate(Date closeTradeDate) {
		this.closeTradeDate = closeTradeDate;
	}

	public MasterTable getSeller() {
		return seller;
	}


	public void setSeller(MasterTable seller) {
		this.seller = seller;
	}


	public MasterTable getBuyer() {
		return buyer;
	}


	public void setBuyer(MasterTable buyer) {
		this.buyer = buyer;
	}


	public boolean isApprovedTradeDate() {
		return isApprovedTradeDate;
	}


	public void setApprovedTradeDate(boolean isApprovedTradeDate) {
		this.isApprovedTradeDate = isApprovedTradeDate;
	}
}
