package com.globozor.domain.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table
public class StateLookup {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column
	private long stateLookupId;
	
	@Column
	private String stateName;
	
	@ManyToOne
	@JoinColumn(name="countryLookupId")
	@JsonIgnore
	private CountryLookup countryLookup;

	public long getStateLookupId() {
		return stateLookupId;
	}

	public void setStateLookupId(long stateLookupId) {
		this.stateLookupId = stateLookupId;
	}

	public String getStateName() {
		return stateName;
	}

	public void setStateName(String stateName) {
		this.stateName = stateName;
	}

	public CountryLookup getCountryLookup() {
		return countryLookup;
	}

	public void setCountryLookup(CountryLookup countryLookup) {
		this.countryLookup = countryLookup;
	}
	
}
