package com.globozor.domain.entity;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

@Entity
@NamedNativeQueries({
@NamedNativeQuery(name = "MasterTable.findByState" , query="select m.* from address_details a , master_table m , state_lookup s "
			+ "where (s.state_name = :region) and (m.master_table_id = a.master_table_id "
			+ "and s.state_lookup_id=a.state_lookup_id)",resultClass = MasterTable.class),
@NamedNativeQuery(name = "MasterTable.findByCountry" , query="select m.* from address_details a , master_table m , country_lookup c "
		+ "where (c.country_name = :region) and (m.master_table_id = a.master_table_id "
		+ "and c.country_lookup_id=a.country_lookup_id)",resultClass = MasterTable.class)})
@Table
public class MasterTable {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column
	private long masterTableId;
	
	@Column
	private String userName;
	
	@Column
	private String emailId;
	
	@Column
	private String mobileNumber;
	
	@Column
	@JsonIgnore
	private String password;
	
	@Column
	private String firstName;

	@Column
	private String middleName;

	@Column
	private String lastName;
	
	@Column
	private String companyName;
	
	@Column
	private String websiteUrl;
	
	@Column
	private String panNumber;
	
	@Column
	private String IecCodeNumber;
	
	@Column
	private String gstNumber;
	
	@Column
	private boolean isVerified;
	
	@ManyToMany
	@JoinTable(name="seller_paymentmethod", joinColumns = @JoinColumn(name="sellerId",referencedColumnName="masterTableId"), inverseJoinColumns=@JoinColumn(name="paymentMethodId",referencedColumnName="paymentMethodId"))
	private Set<PaymentMethod> paymentMethod;
	
	@ManyToOne
	@JoinColumn(name="roleId")
	private Role role;

	@OneToMany(mappedBy="masterTable")
	private Set<Image> profileImages;
	
	@OneToOne(mappedBy="masterTable")
	private SellerDescription sellerDescription;
	
	@OneToMany(mappedBy="masterTable")
	private Set<AddressDetails> addressDetails;
	
	@OneToMany(mappedBy="masterTable")
	private Set<SellerProduct> sellerProducts;
	
	@ManyToMany
	@JoinTable(name="mastertable_language", joinColumns = @JoinColumn(name="masterTableId",referencedColumnName="masterTableId"), inverseJoinColumns=@JoinColumn(name="languageId",referencedColumnName="languageId"))
	private Set<Language> languages;
	
	@ManyToMany
	@JoinTable(name="seller_currency", joinColumns = @JoinColumn(name="masterTableId",referencedColumnName="masterTableId"), inverseJoinColumns=@JoinColumn(name="currencyId",referencedColumnName="currencyId"))
	private Set<Currency> currencies;
	
	@OneToOne(mappedBy="masterTable")
	@JsonIgnore
	private Enquiry enquiry;
	
	@OneToOne(mappedBy="masterTable")
	@JsonIgnore
	private Transaction transaction;
	
	@OneToMany(mappedBy="masterTable")
	private Set<Notification> notifications;
	
	public long getMasterTableId() {
		return masterTableId;
	}

	public void setMasterTableId(long masterTableId) {
		this.masterTableId = masterTableId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	@JsonIgnore
	public String getPassword() {
		return password;
	}

	@JsonProperty
	public void setPassword(String password) {
		this.password = password;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getWebsiteUrl() {
		return websiteUrl;
	}

	public void setWebsiteUrl(String websiteUrl) {
		this.websiteUrl = websiteUrl;
	}

	public String getPanNumber() {
		return panNumber;
	}

	public void setPanNumber(String panNumber) {
		this.panNumber = panNumber;
	}

	public String getIecCodeNumber() {
		return IecCodeNumber;
	}

	public void setIecCodeNumber(String iecCodeNumber) {
		IecCodeNumber = iecCodeNumber;
	}

	public String getGstNumber() {
		return gstNumber;
	}

	public void setGstNumber(String gstNumber) {
		this.gstNumber = gstNumber;
	}

	public boolean isVerified() {
		return isVerified;
	}

	public void setVerified(boolean isVerified) {
		this.isVerified = isVerified;
	}

	public Role getRole() {
		return role;
	}

	public void setRole(Role role) {
		this.role = role;
	}
	
	public Set<Image> getProfileImages() {
		return profileImages;
	}

	public void setProfileImages(Set<Image> profileImages) {
		this.profileImages = profileImages;
	}

	public SellerDescription getSellerDescription() {
		return sellerDescription;
	}

	public void setSellerDescription(SellerDescription sellerDescription) {
		this.sellerDescription = sellerDescription;
	}

	public Set<AddressDetails> getAddressDetails() {
		return addressDetails;
	}

	public void setAddressDetails(Set<AddressDetails> addressDetails) {
		this.addressDetails = addressDetails;
	}
	
	public Set<PaymentMethod> getPaymentMethod() {
		return paymentMethod;
	}

	public void setPaymentMethod(Set<PaymentMethod> paymentMethod) {
		this.paymentMethod = paymentMethod;
	}
	
	public Set<SellerProduct> getSellerProducts() {
		return sellerProducts;
	}

	public void setSellerProducts(Set<SellerProduct> sellerProducts) {
		this.sellerProducts = sellerProducts;
	}

	public Set<Language> getLanguages() {
		return languages;
	}

	public void setLanguages(Set<Language> languages) {
		this.languages = languages;
	}

	public Set<Currency> getCurrencies() {
		return currencies;
	}

	public void setCurrencies(Set<Currency> currencies) {
		this.currencies = currencies;
	}

	public Enquiry getEnquiry() {
		return enquiry;
	}

	public void setEnquiry(Enquiry enquiry) {
		this.enquiry = enquiry;
	}

	public Transaction getTransaction() {
		return transaction;
	}

	public void setTransaction(Transaction transaction) {
		this.transaction = transaction;
	}

	public Set<Notification> getNotifications() {
		return notifications;
	}

	public void setNotifications(Set<Notification> notifications) {
		this.notifications = notifications;
	}

	@Override
	public String toString() {
		return "MasterTable [masterTableId=" + masterTableId + ", userName="
				+ userName + ", emailId=" + emailId + ", mobileNumber="
				+ mobileNumber + ", password=" + password + ", firstName="
				+ firstName + ", middleName=" + middleName + ", lastName="
				+ lastName + ", companyName=" + companyName + ", websiteUrl="
				+ websiteUrl + ", panNumber=" + panNumber + ", IecCodeNumber="
				+ IecCodeNumber + ", gstNumber=" + gstNumber + ", isVerified="
				+ isVerified + ", paymentMethod=" + paymentMethod + ", role="
				+ role + ", sellerDescription=" + sellerDescription + "]";
	}
	
}
