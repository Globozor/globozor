package com.globozor.domain.dtos;

import java.util.List;

public class SellerDto {

	private List<String> sellerProductImage;
	private String sellerProductName;
	private long unitPrice;
	private long minimumQuantity;
	private String productMaturity;
	private String productCertification;
	private String productWeight;
	private String productSize;
	private String productPlaceOfOrigin;
	private String productShape;
	private String productCultivationType;
	private String sellerProductDescription;
	private String sellerName;
	private String sellerCountry;
	private String sellerMembershipType;
	private boolean isVerified;
	private String sellerCompanyName;
	private String sellerTurnover;
	
	public List<String> getSellerProductImage() {
		return sellerProductImage;
	}
	public void setSellerProductImage(List<String> sellerProductImage) {
		this.sellerProductImage = sellerProductImage;
	}
	public long getUnitPrice() {
		return unitPrice;
	}
	public void setUnitPrice(long unitPrice) {
		this.unitPrice = unitPrice;
	}
	
	public long getMinimumQuantity() {
		return minimumQuantity;
	}
	public void setMinimumQuantity(long minimumQuantity) {
		this.minimumQuantity = minimumQuantity;
	}
	public String getProductMaturity() {
		return productMaturity;
	}
	public void setProductMaturity(String productMaturity) {
		this.productMaturity = productMaturity;
	}
	public String getProductCertification() {
		return productCertification;
	}
	public void setProductCertification(String productCertification) {
		this.productCertification = productCertification;
	}
	public String getProductWeight() {
		return productWeight;
	}
	public void setProductWeight(String productWeight) {
		this.productWeight = productWeight;
	}
	public String getProductSize() {
		return productSize;
	}
	public void setProductSize(String productSize) {
		this.productSize = productSize;
	}
	public String getProductPlaceOfOrigin() {
		return productPlaceOfOrigin;
	}
	public void setProductPlaceOfOrigin(String productPlaceOfOrigin) {
		this.productPlaceOfOrigin = productPlaceOfOrigin;
	}
	public String getProductShape() {
		return productShape;
	}
	public void setProductShape(String productShape) {
		this.productShape = productShape;
	}
	public String getProductCultivationType() {
		return productCultivationType;
	}
	public void setProductCultivationType(String productCultivationType) {
		this.productCultivationType = productCultivationType;
	}
	public String getSellerProductDescription() {
		return sellerProductDescription;
	}
	public void setSellerProductDescription(String sellerProductDescription) {
		this.sellerProductDescription = sellerProductDescription;
	}
	public String getSellerName() {
		return sellerName;
	}
	public void setSellerName(String sellerName) {
		this.sellerName = sellerName;
	}
	public String getSellerCountry() {
		return sellerCountry;
	}
	public void setSellerCountry(String sellerCountry) {
		this.sellerCountry = sellerCountry;
	}
	public String getSellerMembershipType() {
		return sellerMembershipType;
	}
	public void setSellerMembershipType(String sellerMembershipType) {
		this.sellerMembershipType = sellerMembershipType;
	}
	public boolean isVerified() {
		return isVerified;
	}
	public void setVerified(boolean isVerified) {
		this.isVerified = isVerified;
	}
	public String getSellerCompanyName() {
		return sellerCompanyName;
	}
	public void setSellerCompanyName(String sellerCompanyName) {
		this.sellerCompanyName = sellerCompanyName;
	}
	public String getSellerTurnover() {
		return sellerTurnover;
	}
	public void setSellerTurnover(String sellerTurnover) {
		this.sellerTurnover = sellerTurnover;
	}
	public String getSellerProductName() {
		return sellerProductName;
	}
	public void setSellerProductName(String sellerProductName) {
		this.sellerProductName = sellerProductName;
	}
}
