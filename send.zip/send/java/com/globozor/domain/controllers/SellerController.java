package com.globozor.domain.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.globozor.domain.entity.Notification;
import com.globozor.domain.entity.SellerEnquiryResponse;
import com.globozor.domain.entity.SellerProduct;
import com.globozor.domain.services.SellerService;

@RestController
@RequestMapping("/seller")
public class SellerController {

	@Autowired
	SellerService sellerService;
	
	@RequestMapping(value="/responseEnquiry",method=RequestMethod.POST)
	public SellerEnquiryResponse responseEnquiry(@RequestBody SellerEnquiryResponse sellerEnquiryResponse){
		return sellerService.responseEnquiry(sellerEnquiryResponse);
	}
	
	@RequestMapping(value="/getNotifications",method=RequestMethod.GET)
	public List<Notification> getNotifications() {
		return sellerService.getNotifications();
	}
	
	@RequestMapping("/addSellerProduct")
	public SellerProduct addSellerProduct(@RequestBody SellerProduct sellerProduct){
		return sellerService.addSellerProduct(sellerProduct);
	}
	
}
