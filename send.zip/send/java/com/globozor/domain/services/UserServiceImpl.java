package com.globozor.domain.services;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.globozor.domain.entity.Enquiry;
import com.globozor.domain.entity.MasterTable;
import com.globozor.domain.entity.Product;
import com.globozor.domain.entity.SellerProduct;
import com.globozor.domain.entity.SubCategory;
import com.globozor.domain.entity.SubProduct;
import com.globozor.domain.exceptions.MasterTableException;
import com.globozor.domain.repository.EnquiryRepository;
import com.globozor.domain.repository.MasterTableRepository;
import com.globozor.domain.repository.ProductRepository;
import com.globozor.domain.repository.SellerProductRepository;
import com.globozor.domain.repository.SubCategoryRepository;
import com.globozor.domain.repository.SubProductRepository;

@Service
public class UserServiceImpl implements UserService{
	
	private static final Logger log = LoggerFactory.getLogger(UserServiceImpl.class);

	@Autowired
	MasterTableRepository masterTableRepository;
	
	@Autowired
	SubCategoryRepository subCategoryRepository;
	
	@Autowired
	ProductRepository productRepository;
	
	@Autowired
	SubProductRepository subProductRepository;
	
	@Autowired
	SellerProductRepository sellerProductRepository;
	
	@Autowired
	EnquiryRepository enquiryRepository;
	
	@Override
	public MasterTable login(MasterTable masterTable) throws MasterTableException{
		MasterTable masterTable2 = new MasterTable();
		System.out.println("mas is "+masterTable);
		//masterTable2 = masterTableRepository.findByUserName(masterTable.getUserName());
		if(masterTable.getMobileNumber() != null){
			System.out.println("1st");
			masterTable2 = masterTableRepository.findByMobileNumber(masterTable.getMobileNumber());
		}else if(masterTable.getUserName() != null){
			System.out.println("2nd");
			masterTable2 = masterTableRepository.findByUserName(masterTable.getUserName());
		}else if(masterTable.getEmailId() != null){
			System.out.println("3rd");
			masterTable2 = masterTableRepository.findByEmailId(masterTable.getEmailId());
		}
		System.out.println("maste is "+masterTable2);
		if(masterTable2 != null && masterTable.getPassword().equals(masterTable2.getPassword())){
			return masterTable2;
		}else{
			throw new MasterTableException("Username or password is incorrect");
		}
	}

	@Override
	public MasterTable signup(MasterTable masterTable)
			throws MasterTableException {
		try {
			masterTable = masterTableRepository.save(masterTable);
		} catch (Exception e) {
			throw new MasterTableException("Unable to save user");
		}
		return masterTable;
	}
	
	@Override
	public Object searchProduct(String searchProduct) {
		SubCategory subCategory = subCategoryRepository.findBySubCategoryName(searchProduct);
		if(!(subCategory==null)){
			return subCategory;
		}
		Product product = productRepository.findByProductName(searchProduct);
		if(!(product==null)){
			return product;
		}
		
		SubProduct subProduct = subProductRepository.findBySubProductName(searchProduct);
		if(!(subProduct==null)){
			return subProduct;
		}
		return null;
	}

	@Override
	public Set<MasterTable> searchSellers(Object object) {
		Set<MasterTable> sellerList = new HashSet<MasterTable>();
		SubProduct subProduct = new SubProduct();
		List<SellerProduct> sellerProductList=new ArrayList<SellerProduct>();
		if(object instanceof SubProduct){
			subProduct = (SubProduct) object;
			sellerProductList = 
					sellerProductRepository.findBySubProductId(subProduct.getSubProductId());
		}else if(object instanceof Product){
			Product product = (Product) object;
			List<SubProduct> subProductList = product.getSubProduct();
			System.out.println("sellerproductlist is "+sellerProductList);
			for (SubProduct subProduct2 : subProductList) {
				List<SellerProduct> sellerProductList1 = 
						sellerProductRepository.findBySubProductId(subProduct2.getSubProductId());
				System.out.println("sellerproductlist is "+sellerProductList);
				sellerProductList.addAll(sellerProductList1);
			}
		}else if(object instanceof SubCategory){
			SubCategory subCategory = (SubCategory) object;
			List<Product> productList = subCategory.getProduct();
			for (Product product : productList) {
				List<SubProduct> subProductList = product.getSubProduct();
				for (SubProduct subProduct2 : subProductList) {
					List<SellerProduct> sellerProductList1 = 
							sellerProductRepository.findBySubProductId(subProduct2.getSubProductId());
					System.out.println("sellerproductlist is "+sellerProductList);
					sellerProductList.addAll(sellerProductList1);
				}
			}
		}
		for (SellerProduct sellerProduct : sellerProductList) {
			MasterTable seller = 
					masterTableRepository.findByMasterTableId(sellerProduct.getMasterTable().getMasterTableId());
			sellerList.add(seller);
		}
		
		return sellerList;
	}
	
	@Override
	public List<MasterTable> enquiryProduct(Enquiry enquiry) {
		enquiry = enquiryRepository.save(enquiry);
		List<SellerProduct> sellerProductList=new ArrayList<SellerProduct>();
		List<MasterTable> sellerList = new ArrayList<MasterTable>();
		sellerProductList = 
				sellerProductRepository.findBySubProductId(enquiry.getSubProductId());
		for (SellerProduct sellerProduct : sellerProductList) {
			MasterTable seller = 
					masterTableRepository.findByMasterTableId(sellerProduct.getMasterTable().getMasterTableId());
			sellerList.add(seller);
		}
		return sellerList;
	}

	@Override
	public Set<MasterTable> getSelectedSuppliers() {
		Set<MasterTable> masterTables = new HashSet<MasterTable>();
			int count=1;
			masterTables = masterTableRepository.getSelectedSuppliers(count);
			if(masterTables==null){
				log.info("in a ");
				masterTables = new HashSet<MasterTable>();
			}
			while((masterTables.size()<=4 && count <=3)){
				log.info("in count "+count);
				masterTables.addAll(masterTableRepository.getSelectedSuppliers(count+1));
				count++;
			}
			/*while((masterTables == null)&&count<=3){
				masterTables=masterTableRepository.getSelectedSuppliers(count+1);
				count++;
			}*/
			return masterTables;
			/*if((!(null == masterTables)) && masterTables.size()>=5){
				return masterTables;
			}else if((!(null == masterTables)) && masterTables.size()<5){
				
			}
		}
		return null;*/
	}

	@Override
	public Set<MasterTable> getUserByRegion(String region , int roleId) {
		if(roleId == 2){
			return masterTableRepository.findByState(region);
		}else if(roleId == 3){
			return masterTableRepository.findByCountry(region);	
		}
		//return masterTableRepository.findUserByRegion(region , roleId);
		return null;
	}

	@Override
	public List<String> getResultList() {
		List<String> searchList = new ArrayList<String>();
		
		List<String> subCategories = subCategoryRepository.findSubCategoryNames();
		searchList.addAll(subCategories);
		List<String> products = productRepository.findProductNames();
		searchList.addAll(products);
		List<String> subProducts = subProductRepository.findSubProductNames();
		searchList.addAll(subProducts);
		List<String> sellerProducts = sellerProductRepository.findSellerProductNames();
		searchList.addAll(sellerProducts);
		
		return searchList;
	}

}
