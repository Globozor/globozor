package com.globozor.domain.services;

import java.util.List;

import com.globozor.domain.entity.Notification;
import com.globozor.domain.entity.SellerEnquiryResponse;
import com.globozor.domain.entity.SellerProduct;

public interface SellerService {

	public SellerEnquiryResponse responseEnquiry(
			SellerEnquiryResponse sellerEnquiryResponse);

	public List<Notification> getNotifications();

	public SellerProduct addSellerProduct(SellerProduct sellerProduct);

}
