package com.globozor.domain.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.globozor.domain.entity.CountryLookup;
import com.globozor.domain.repository.CountryRepository;

@Service
public class CountryServiceImpl implements CountryService{
	
	@Autowired
	CountryRepository countryRepository;

	@Override
	public List<CountryLookup> getCountry() {
		return countryRepository.findAll();
	}

}
