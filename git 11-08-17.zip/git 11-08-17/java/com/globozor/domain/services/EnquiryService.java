package com.globozor.domain.services;

import com.globozor.domain.entity.Enquiry;

public interface EnquiryService {

	public Enquiry getEnquiry(long enquiryId);

}
