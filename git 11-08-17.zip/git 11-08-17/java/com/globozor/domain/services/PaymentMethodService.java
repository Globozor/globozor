package com.globozor.domain.services;

import java.util.List;

import com.globozor.domain.entity.PaymentMethod;

public interface PaymentMethodService {

	public List<PaymentMethod> getPayments();

	
}
