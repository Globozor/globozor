package com.globozor.domain.services;

import java.util.Date;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.globozor.domain.entity.Notification;
import com.globozor.domain.entity.SellerEnquiry;
import com.globozor.domain.entity.SellerEnquiryResponse;
import com.globozor.domain.entity.SellerProduct;
import com.globozor.domain.exceptions.SellerException;
import com.globozor.domain.repository.NotificationRepository;
import com.globozor.domain.repository.SellerEnquiryRepository;
import com.globozor.domain.repository.SellerEnquiryResponseRepository;
import com.globozor.domain.repository.SellerProductRepository;

@Service
public class SellerServiceImpl implements SellerService{

	@Autowired
	SellerEnquiryResponseRepository sellerEnquiryResponseRepository;
	
	@Autowired
	NotificationRepository notificationRepository;
	
	@Autowired
	SellerProductRepository sellerProductRepository;
	
	@Autowired
	SellerEnquiryRepository sellerEnquiryRepository;
	
	public SellerEnquiryResponse responseEnquiry(
			SellerEnquiryResponse sellerEnquiryResponse) {
		sellerEnquiryResponse = sellerEnquiryResponseRepository.save(sellerEnquiryResponse);
		Set<Notification> notifications = sellerEnquiryResponse.getEnquiry().getBuyer().getNotifications();
		Notification notification = new Notification();
		notification.setMasterTable(sellerEnquiryResponse.getEnquiry().getBuyer());
		notification.setNotificationDesc("New response for your enquiry with id "+sellerEnquiryResponse.getEnquiry().getEnquiryId()+" from "+sellerEnquiryResponse.getSeller().getUserName());
		notification.setNotificationType("RFQ response");
		notification.setActive(true);
		notification.setCreatedTime(new Date());
		notification = notificationRepository.save(notification);
		notifications.add(notification);
		sellerEnquiryResponse.getEnquiry().getBuyer().setNotifications(notifications);
		return sellerEnquiryResponse;
	}

	public List<Notification> getNotifications() {
		return notificationRepository.findAllNotifications();
	}

	public SellerProduct addSellerProduct(SellerProduct sellerProduct) {
		sellerProduct.setStatus("pending_approval");
		return sellerProductRepository.save(sellerProduct);
	}

	@Override
	public String removeSellerProduct(long sellerProductId) throws SellerException{
		SellerProduct sellerProduct = sellerProductRepository.findBySellerProductId(sellerProductId);
		sellerProduct.setActive(false);
		String message = "";
		try {
			sellerProductRepository.save(sellerProduct);
			message = "Product successfully removed";
		} catch (Exception e) {
			message = "Unable to delete object";
			throw new SellerException("Unable to delete product");
		}
		return message;
	}

	@Override
	public List<SellerProduct> getSellerProduct(String status) {
		return sellerProductRepository.findByStatus(status);
	}

	@Override
	public List<SellerEnquiry> getSellerEnquiry() {
		return sellerEnquiryRepository.findByIsActive(true);
	}
	
}
