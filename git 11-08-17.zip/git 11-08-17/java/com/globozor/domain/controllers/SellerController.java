package com.globozor.domain.controllers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.globozor.domain.dtos.ResponseDto;
import com.globozor.domain.dtos.SellerEnquiryDto;
import com.globozor.domain.dtos.SellerProductDto;
import com.globozor.domain.entity.Notification;
import com.globozor.domain.entity.SellerEnquiry;
import com.globozor.domain.entity.SellerEnquiryResponse;
import com.globozor.domain.entity.SellerProduct;
import com.globozor.domain.exceptions.SellerException;
import com.globozor.domain.services.EntityDtoMapper;
import com.globozor.domain.services.SellerService;

@RestController
@RequestMapping("/seller")
public class SellerController {

	@Autowired
	SellerService sellerService;
	
	@Autowired
	EntityDtoMapper mapper;
	
	@RequestMapping(value="/responseEnquiry",method=RequestMethod.POST)
	public SellerEnquiryResponse responseEnquiry(@RequestBody SellerEnquiryResponse sellerEnquiryResponse){
		return sellerService.responseEnquiry(sellerEnquiryResponse);
	}
	
	@RequestMapping(value="/getNotifications",method=RequestMethod.GET)
	public List<Notification> getNotifications() {
		return sellerService.getNotifications();
	}
	
	@RequestMapping(value = "/addSellerProduct",method=RequestMethod.POST)
	public SellerProduct addSellerProduct(@RequestBody SellerProduct sellerProduct){
		return sellerService.addSellerProduct(sellerProduct);
	}
	
	@RequestMapping("/removeSellerProduct")
	public ResponseDto removeSellerProduct(@RequestParam long sellerProductId){
		String message = "";
		try {
			message = sellerService.removeSellerProduct(sellerProductId);
		} catch (SellerException e) {
			return new ResponseDto(e.getMessage());
		}
		return new ResponseDto(message);
	}
	
	@RequestMapping("/getSellerProduct")
	public List<SellerProductDto> getSellerProduct(@RequestParam String status){
		List<SellerProductDto> sellerProductDtos = new ArrayList<SellerProductDto>();
		List<SellerProduct> sellerProducts = sellerService.getSellerProduct(status);
		for (SellerProduct sellerProduct : sellerProducts) {
			SellerProductDto sellerProductDto = mapper.sellerProductToDto(sellerProduct);
			sellerProductDtos.add(sellerProductDto);
		}
		return sellerProductDtos;
	}
	
	@RequestMapping("/getSellerEnquiry")
	public List<SellerEnquiryDto> getSellerEnquiry(){
		List<SellerEnquiryDto> sellerEnquiryDtos = new ArrayList<SellerEnquiryDto>();
		List<SellerEnquiry> sellerEnquiries =  sellerService.getSellerEnquiry();
		for (SellerEnquiry sellerEnquiry : sellerEnquiries) {
			SellerEnquiryDto sellerEnquiryDto = mapper.sellerEnquiryToDto(sellerEnquiry);
			sellerEnquiryDtos.add(sellerEnquiryDto);
		}
		return sellerEnquiryDtos;
	}
}
