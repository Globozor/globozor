package com.globozor.domain.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.globozor.domain.entity.DashboardLink;
import com.globozor.domain.services.DashboardService;

@RestController
@RequestMapping("/dashboard")
public class DashboardLinkController {

	@Autowired
	DashboardService dashboardService;
	
	@RequestMapping("/getLinks")
	public List<DashboardLink> getLinks(@RequestParam String role){
		return dashboardService.getLinks(role);
	}
}
