package com.globozor.domain.dtos;

import java.util.List;

public class ResponseDto {

	public List<Object> object;
	public String exception;
	public String message;

	public ResponseDto() {

	}
	
	public ResponseDto(List<Object> object) {
		this.object = object;
	}

	public ResponseDto(String exception) {
		this.exception = exception;
	}

	public ResponseDto(List<Object> object, String message) {
		super();
		this.object = object;
		this.message = message;
	}

	public List<Object> getObject() {
		return object;
	}

	public void setObject(List<Object> object) {
		this.object = object;
	}

	public String getException() {
		return exception;
	}

	public void setException(String exception) {
		this.exception = exception;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

}
