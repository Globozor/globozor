package com.globozor.domain.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.globozor.domain.entity.SellerEnquiryResponse;

public interface SellerEnquiryResponseRepository extends JpaRepository<SellerEnquiryResponse, Long>{

}
