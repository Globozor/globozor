package com.globozor.domain.repository;

import java.util.List;

import com.globozor.domain.entity.SellerProduct;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface SellerProductRepository extends JpaRepository<SellerProduct, Long>{

	public SellerProduct findBySellerProductId(long sellerProductId);
	@Query("select s from SellerProduct s where s.subProduct.subProductId=?1")
	public List<SellerProduct> findBySubProductId(long subProductId);
	@Query("select s.sellerProductName from SellerProduct s")
	public List<String> findSellerProductNames();
	@Query("select s from SellerProduct s where s.status=?1")
	public List<SellerProduct> findByStatus(String status);
}
