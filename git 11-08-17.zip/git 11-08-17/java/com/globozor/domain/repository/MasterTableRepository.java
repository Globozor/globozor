package com.globozor.domain.repository;

import java.util.List;
import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.globozor.domain.entity.MasterTable;
public interface MasterTableRepository extends JpaRepository<MasterTable, Long>{

	public MasterTable findByMobileNumber(String mobileNumber);
	@Query("select m from MasterTable m where m.userName=?1")
	public MasterTable findByUserName(String userName);
	public MasterTable findByEmailId(String emailId);
	public MasterTable findByMasterTableId(long masterTableId);
	@Query("select m from MasterTable m where m.sellerDescription.membershipType.membershipTypeId=?1")
	public Set<MasterTable> getSelectedSuppliers(long membershipTypeId);
	@Query(nativeQuery=true)
	public Set<MasterTable> findByState(@Param("region") String region);
	@Query(nativeQuery=true)
	public Set<MasterTable> findByCountry(@Param("region") String region);
	
}
