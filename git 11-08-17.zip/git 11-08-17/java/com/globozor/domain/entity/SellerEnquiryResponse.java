package com.globozor.domain.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

@Entity
@Table
@JsonIdentityInfo(
		generator= ObjectIdGenerators.PropertyGenerator.class,
		property="sellerEnquiryResponseId")
public class SellerEnquiryResponse {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column
	private long sellerEnquiryResponseId;
	
	@OneToOne
	@JoinColumn(name="enquiryId")
	@JsonManagedReference
	private Enquiry enquiry;
	
	@OneToOne
	@JoinColumn(name="buyerId")
	@JsonManagedReference
	private MasterTable buyer;
	
	@OneToOne
	@JoinColumn(name="sellerId")
	@JsonManagedReference
	private MasterTable seller;
	
	@OneToOne
	@JoinColumn(name="subproductId")
	private SubProduct subProduct;
	
	@Column
	private long quantity;
	
	@Column
	private String unit;
	
	@Column
	private String enquiryDescription;
	
	@Column
	private String status;

	public long getSellerEnquiryResponseId() {
		return sellerEnquiryResponseId;
	}

	public void setSellerEnquiryResponseId(long sellerEnquiryResponseId) {
		this.sellerEnquiryResponseId = sellerEnquiryResponseId;
	}

	public Enquiry getEnquiry() {
		return enquiry;
	}

	public void setEnquiry(Enquiry enquiry) {
		this.enquiry = enquiry;
	}

	public MasterTable getBuyer() {
		return buyer;
	}

	public void setBuyer(MasterTable buyer) {
		this.buyer = buyer;
	}

	public MasterTable getSeller() {
		return seller;
	}

	public void setSeller(MasterTable seller) {
		this.seller = seller;
	}

	public SubProduct getSubProduct() {
		return subProduct;
	}

	public void setSubProduct(SubProduct subProduct) {
		this.subProduct = subProduct;
	}

	public long getQuantity() {
		return quantity;
	}

	public void setQuantity(long quantity) {
		this.quantity = quantity;
	}

	public String getUnit() {
		return unit;
	}

	public void setUnit(String unit) {
		this.unit = unit;
	}

	public String getEnquiryDescription() {
		return enquiryDescription;
	}

	public void setEnquiryDescription(String enquiryDescription) {
		this.enquiryDescription = enquiryDescription;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
}
