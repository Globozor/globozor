package com.globozor.domain.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;


@Table(name="subproductImage")
@Entity(name="subproductImage")
public class SubProductImage {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="subproductImageId")
	private long subProductImageId;
	
	@ManyToOne
	@JsonIgnore
	@JoinColumn(name="subproductId")
	private SubProduct subProduct;
	
	@Column(name="filepath")
	private String filePath;
	
	public SubProductImage() {
		// TODO Auto-generated constructor stub
	}

	public SubProductImage(long subProductImageId, SubProduct subProduct,
			String filePath) {
		super();
		this.subProductImageId = subProductImageId;
		this.subProduct = subProduct;
		this.filePath = filePath;
	}

	public long getSubProductImagesId() {
		return subProductImageId;
	}

	public void setSubProductImagesId(long subProductImageId) {
		this.subProductImageId = subProductImageId;
	}

	public SubProduct getSubProduct() {
		return subProduct;
	}

	public void setSubProduct(SubProduct subProduct) {
		this.subProduct = subProduct;
	}

	public String getFilePath() {
		return filePath;
	}

	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}
}
