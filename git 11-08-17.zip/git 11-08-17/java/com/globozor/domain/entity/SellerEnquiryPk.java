package com.globozor.domain.entity;

import java.io.Serializable;

import javax.persistence.Embeddable;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Embeddable
public class SellerEnquiryPk implements Serializable{

	@ManyToOne
	@JsonIgnore
	@JoinColumn(name="sellerId")
	private MasterTable seller;
	
	@ManyToOne
	@JoinColumn(name="enquiryId")
	private Enquiry enquiry;

	public MasterTable getSeller() {
		return seller;
	}

	public void setSeller(MasterTable seller) {
		this.seller = seller;
	}

	public Enquiry getEnquiry() {
		return enquiry;
	}

	public void setEnquiry(Enquiry enquiry) {
		this.enquiry = enquiry;
	}
	
}
