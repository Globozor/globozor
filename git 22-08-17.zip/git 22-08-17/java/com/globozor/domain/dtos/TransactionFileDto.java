package com.globozor.domain.dtos;

public class TransactionFileDto {

	private long transactionFileId;;
	private TransactionDto transactionDto;
	private String buyerFilepath;
	private String sellerFilepath;
	private String fileType;
	public long getTransactionFileId() {
		return transactionFileId;
	}
	public void setTransactionFileId(long transactionFileId) {
		this.transactionFileId = transactionFileId;
	}
	public TransactionDto getTransactionDto() {
		return transactionDto;
	}
	public void setTransactionDto(TransactionDto transactionDto) {
		this.transactionDto = transactionDto;
	}
	public String getBuyerFilepath() {
		return buyerFilepath;
	}
	public void setBuyerFilepath(String buyerFilepath) {
		this.buyerFilepath = buyerFilepath;
	}
	public String getSellerFilepath() {
		return sellerFilepath;
	}
	public void setSellerFilepath(String sellerFilepath) {
		this.sellerFilepath = sellerFilepath;
	}
	public String getFileType() {
		return fileType;
	}
	public void setFileType(String fileType) {
		this.fileType = fileType;
	}
	
}