package com.globozor.domain.dtos;

import java.util.Date;

public class TradeShowDto {

	private long tradeShowId;
	private String tradeShowName;
	private Date tradeShowDate;
	private String tradeShowHost;
	private String tradeShowDescription;
	private String[] tradeShowFilepath;
	public long getTradeShowId() {
		return tradeShowId;
	}
	public void setTradeShowId(long tradeShowId) {
		this.tradeShowId = tradeShowId;
	}
	public String getTradeShowName() {
		return tradeShowName;
	}
	public void setTradeShowName(String tradeShowName) {
		this.tradeShowName = tradeShowName;
	}
	public Date getTradeShowDate() {
		return tradeShowDate;
	}
	public void setTradeShowDate(Date tradeShowDate) {
		this.tradeShowDate = tradeShowDate;
	}
	public String getTradeShowHost() {
		return tradeShowHost;
	}
	public void setTradeShowHost(String tradeShowHost) {
		this.tradeShowHost = tradeShowHost;
	}
	public String getTradeShowDescription() {
		return tradeShowDescription;
	}
	public void setTradeShowDescription(String tradeShowDescription) {
		this.tradeShowDescription = tradeShowDescription;
	}
	public String[] getTradeShowFilepath() {
		return tradeShowFilepath;
	}
	public void setTradeShowFilepath(String[] tradeShowFilepath) {
		this.tradeShowFilepath = tradeShowFilepath;
	}
	
}
