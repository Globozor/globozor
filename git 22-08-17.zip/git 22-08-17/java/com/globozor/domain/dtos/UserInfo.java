package com.globozor.domain.dtos;

public class UserInfo {

	private String logo;
	private String descriptionAboutCompany;
	private int establishment;
	private String maximumCapacity;
	private String port;
	private String turnover;
	private long numberOfEmployees;
	private String addressLine1;
	private String addressLine2;
	private long pincode;
	private String city;
	private long countryLookupId;
	private long stateLookupId;
	private String addressType;
	private long[] currencyId;
	private long[] languageId;
	private long[] paymentMethodIds;
	private long membershipTypeId;
	
	public String getLogo() {
		return logo;
	}
	public void setLogo(String logo) {
		this.logo = logo;
	}
	public String getDescriptionAboutCompany() {
		return descriptionAboutCompany;
	}
	public void setDescriptionAboutCompany(String descriptionAboutCompany) {
		this.descriptionAboutCompany = descriptionAboutCompany;
	}
	public int getEstablishment() {
		return establishment;
	}
	public void setEstablishment(int establishment) {
		this.establishment = establishment;
	}
	public String getMaximumCapacity() {
		return maximumCapacity;
	}
	public void setMaximumCapacity(String maximumCapacity) {
		this.maximumCapacity = maximumCapacity;
	}
	public String getPort() {
		return port;
	}
	public void setPort(String port) {
		this.port = port;
	}
	public String getTurnover() {
		return turnover;
	}
	public void setTurnover(String turnover) {
		this.turnover = turnover;
	}
	public long getNumberOfEmployees() {
		return numberOfEmployees;
	}
	public void setNumberOfEmployees(long numberOfEmployees) {
		this.numberOfEmployees = numberOfEmployees;
	}
	public String getAddressLine1() {
		return addressLine1;
	}
	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}
	public String getAddressLine2() {
		return addressLine2;
	}
	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}
	public long getPincode() {
		return pincode;
	}
	public void setPincode(long pincode) {
		this.pincode = pincode;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public long getCountryLookupId() {
		return countryLookupId;
	}
	public void setCountryLookupId(long countryLookupId) {
		this.countryLookupId = countryLookupId;
	}
	public long getStateLookupId() {
		return stateLookupId;
	}
	public void setStateLookupId(long stateLookupId) {
		this.stateLookupId = stateLookupId;
	}
	public String getAddressType() {
		return addressType;
	}
	public void setAddressType(String addressType) {
		this.addressType = addressType;
	}
	public long[] getCurrencyId() {
		return currencyId;
	}
	public void setCurrencyId(long[] currencyId) {
		this.currencyId = currencyId;
	}
	public long[] getLanguageId() {
		return languageId;
	}
	public void setLanguageId(long[] languageId) {
		this.languageId = languageId;
	}
	public long[] getPaymentMethodIds() {
		return paymentMethodIds;
	}
	public void setPaymentMethodIds(long[] paymentMethodIds) {
		this.paymentMethodIds = paymentMethodIds;
	}
	public long getMembershipTypeId() {
		return membershipTypeId;
	}
	public void setMembershipTypeId(long membershipTypeId) {
		this.membershipTypeId = membershipTypeId;
	}
}
