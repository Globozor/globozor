package com.globozor.domain.dtos;

public class EnquiryDto {

	private long enquiryId;
	private String sellerProductName;
	private String subProductName;
	private long quantity;
	private String unit;
	private String enqiryDescription;
	
	public long getEnquiryId() {
		return enquiryId;
	}
	public void setEnquiryId(long enquiryId) {
		this.enquiryId = enquiryId;
	}
	public String getSellerProductName() {
		return sellerProductName;
	}
	public void setSellerProductName(String sellerProductName) {
		this.sellerProductName = sellerProductName;
	}
	public String getSubProductName() {
		return subProductName;
	}
	public void setSubProductName(String subProductName) {
		this.subProductName = subProductName;
	}
	public long getQuantity() {
		return quantity;
	}
	public void setQuantity(long quantity) {
		this.quantity = quantity;
	}
	public String getUnit() {
		return unit;
	}
	public void setUnit(String unit) {
		this.unit = unit;
	}
	public String getEnqiryDescription() {
		return enqiryDescription;
	}
	public void setEnqiryDescription(String enqiryDescription) {
		this.enqiryDescription = enqiryDescription;
	}
	
}
