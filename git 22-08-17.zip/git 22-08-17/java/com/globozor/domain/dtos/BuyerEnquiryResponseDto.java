package com.globozor.domain.dtos;

public class BuyerEnquiryResponseDto {

	private long buyerEnquiryResponseId;
	private long enquiryId;
	private long buyerId;
	private long sellerProductId;
	private String buyerName;
	private String sellerProductName;
	private String quantity;
	private String unit;
	private String unitPrice;
	private String enquiryDescription;
	private String status;
	public long getBuyerEnquiryResponseId() {
		return buyerEnquiryResponseId;
	}
	public void setBuyerEnquiryResponseId(long buyerEnquiryResponseId) {
		this.buyerEnquiryResponseId = buyerEnquiryResponseId;
	}
	public long getEnquiryId() {
		return enquiryId;
	}
	public void setEnquiryId(long enquiryId) {
		this.enquiryId = enquiryId;
	}
	public long getBuyerId() {
		return buyerId;
	}
	public void setBuyerId(long buyerId) {
		this.buyerId = buyerId;
	}
	public long getSellerProductId() {
		return sellerProductId;
	}
	public void setSellerProductId(long sellerProductId) {
		this.sellerProductId = sellerProductId;
	}
	public String getBuyerName() {
		return buyerName;
	}
	public void setBuyerName(String buyerName) {
		this.buyerName = buyerName;
	}
	public String getSellerProductName() {
		return sellerProductName;
	}
	public void setSellerProductName(String sellerProductName) {
		this.sellerProductName = sellerProductName;
	}
	public String getQuantity() {
		return quantity;
	}
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}
	public String getUnit() {
		return unit;
	}
	public void setUnit(String unit) {
		this.unit = unit;
	}
	public String getUnitPrice() {
		return unitPrice;
	}
	public void setUnitPrice(String unitPrice) {
		this.unitPrice = unitPrice;
	}
	public String getEnquiryDescription() {
		return enquiryDescription;
	}
	public void setEnquiryDescription(String enquiryDescription) {
		this.enquiryDescription = enquiryDescription;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
}
