package com.globozor.domain.dtos;

public class BuyerRatingDto {

	private long buyerRatingId;
	private long transactionId;
	private String buyerName;
	private String sellerName;
	private String rating;
	private String description;
	private String status;
	
	public long getBuyerRatingId() {
		return buyerRatingId;
	}
	public void setBuyerRatingId(long buyerRatingId) {
		this.buyerRatingId = buyerRatingId;
	}
	public long getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(long transactionId) {
		this.transactionId = transactionId;
	}
	public String getBuyerName() {
		return buyerName;
	}
	public void setBuyerName(String buyerName) {
		this.buyerName = buyerName;
	}
	public String getSellerName() {
		return sellerName;
	}
	public void setSellerName(String sellerName) {
		this.sellerName = sellerName;
	}
	public String getRating() {
		return rating;
	}
	public void setRating(String rating) {
		this.rating = rating;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
}
