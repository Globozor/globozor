package com.globozor.domain.dtos;

import java.util.Set;

public class SellerProductDto {

	private long sellerProductId;
	private String sellerProductName;
	private String subProductName;
	private String sellerProductDesc;
	private long minimumQuantity;
	private long unitPrice;
	private int priority;
	private String productMaturity;
	private String productCertification;
	private String productWeight;
	private String productSize;
	private String productPlaceOfOrigin;
	private String productShape;
	private String productCultivationType;
	private Set<String> sellerProductImage;
	
	public String getSellerProductName() {
		return sellerProductName;
	}
	public void setSellerProductName(String sellerProductName) {
		this.sellerProductName = sellerProductName;
	}
	public String getSubProductName() {
		return subProductName;
	}
	public void setSubProductName(String subProductName) {
		this.subProductName = subProductName;
	}
	public String getSellerProductDesc() {
		return sellerProductDesc;
	}
	public void setSellerProductDesc(String sellerProductDesc) {
		this.sellerProductDesc = sellerProductDesc;
	}
	public long getMinimumQuantity() {
		return minimumQuantity;
	}
	public void setMinimumQuantity(long minimumQuantity) {
		this.minimumQuantity = minimumQuantity;
	}
	public long getUnitPrice() {
		return unitPrice;
	}
	public void setUnitPrice(long unitPrice) {
		this.unitPrice = unitPrice;
	}
	public int getPriority() {
		return priority;
	}
	public void setPriority(int priority) {
		this.priority = priority;
	}
	public Set<String> getSellerProductImage() {
		return sellerProductImage;
	}
	public void setSellerProductImage(Set<String> sellerProductImage) {
		this.sellerProductImage = sellerProductImage;
	}
	public long getSellerProductId() {
		return sellerProductId;
	}
	public void setSellerProductId(long sellerProductId) {
		this.sellerProductId = sellerProductId;
	}
	public String getProductMaturity() {
		return productMaturity;
	}
	public void setProductMaturity(String productMaturity) {
		this.productMaturity = productMaturity;
	}
	public String getProductCertification() {
		return productCertification;
	}
	public void setProductCertification(String productCertification) {
		this.productCertification = productCertification;
	}
	public String getProductWeight() {
		return productWeight;
	}
	public void setProductWeight(String productWeight) {
		this.productWeight = productWeight;
	}
	public String getProductSize() {
		return productSize;
	}
	public void setProductSize(String productSize) {
		this.productSize = productSize;
	}
	public String getProductPlaceOfOrigin() {
		return productPlaceOfOrigin;
	}
	public void setProductPlaceOfOrigin(String productPlaceOfOrigin) {
		this.productPlaceOfOrigin = productPlaceOfOrigin;
	}
	public String getProductShape() {
		return productShape;
	}
	public void setProductShape(String productShape) {
		this.productShape = productShape;
	}
	public String getProductCultivationType() {
		return productCultivationType;
	}
	public void setProductCultivationType(String productCultivationType) {
		this.productCultivationType = productCultivationType;
	}
}
