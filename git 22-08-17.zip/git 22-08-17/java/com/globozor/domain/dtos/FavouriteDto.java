package com.globozor.domain.dtos;

public class FavouriteDto {

	private long favouriteId;
	private SellerProductDto sellerProductDto;
	public long getFavouriteId() {
		return favouriteId;
	}
	public void setFavouriteId(long favouriteId) {
		this.favouriteId = favouriteId;
	}
	public SellerProductDto getSellerProductDto() {
		return sellerProductDto;
	}
	public void setSellerProductDto(SellerProductDto sellerProductDto) {
		this.sellerProductDto = sellerProductDto;
	}
}
