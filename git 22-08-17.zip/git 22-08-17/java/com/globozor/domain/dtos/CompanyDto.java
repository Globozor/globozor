package com.globozor.domain.dtos;

import java.util.List;

import com.globozor.domain.entity.CompanyProfile;
import com.globozor.domain.entity.CustomerDetail;
import com.globozor.domain.entity.TradeShow;

public class CompanyDto {

	private CompanyProfile companyProfile;
	private List<TradeShow> tradeShows;
	private List<CustomerDetail> customerDetails;
	public CompanyProfile getCompanyProfile() {
		return companyProfile;
	}
	public void setCompanyProfile(CompanyProfile companyProfile) {
		this.companyProfile = companyProfile;
	}
	public List<TradeShow> getTradeShows() {
		return tradeShows;
	}
	public void setTradeShows(List<TradeShow> tradeShows) {
		this.tradeShows = tradeShows;
	}
	public List<CustomerDetail> getCustomerDetails() {
		return customerDetails;
	}
	public void setCustomerDetails(List<CustomerDetail> customerDetails) {
		this.customerDetails = customerDetails;
	}
	@Override
	public String toString() {
		return "CompanyDto [companyProfile=" + companyProfile + ", tradeShows="
				+ tradeShows + ", customerDetails=" + customerDetails + "]";
	}
}
