package com.globozor.domain.dtos;

import javax.persistence.Column;

public class TransactionTrackerDto {

	private long transactionId;
	private boolean contractGenerated;
	private boolean uploadSignedContractBuyer;
	private boolean uploadSignedContractSeller;
	private boolean downloadSignedContractBuyer;
	private boolean downloadSignedContractSeller;
	private boolean uploadPaymentCertificate ;
	private boolean downloadPaymentCertificate;
	private boolean uploadShipment;
	private boolean downloadShipment;
	public long getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(long transactionId) {
		this.transactionId = transactionId;
	}
	public boolean isContractGenerated() {
		return contractGenerated;
	}
	public void setContractGenerated(boolean contractGenerated) {
		this.contractGenerated = contractGenerated;
	}
	public boolean isUploadSignedContractBuyer() {
		return uploadSignedContractBuyer;
	}
	public void setUploadSignedContractBuyer(boolean uploadSignedContractBuyer) {
		this.uploadSignedContractBuyer = uploadSignedContractBuyer;
	}
	public boolean isUploadSignedContractSeller() {
		return uploadSignedContractSeller;
	}
	public void setUploadSignedContractSeller(boolean uploadSignedContractSeller) {
		this.uploadSignedContractSeller = uploadSignedContractSeller;
	}
	public boolean isDownloadSignedContractBuyer() {
		return downloadSignedContractBuyer;
	}
	public void setDownloadSignedContractBuyer(boolean downloadSignedContractBuyer) {
		this.downloadSignedContractBuyer = downloadSignedContractBuyer;
	}
	public boolean isDownloadSignedContractSeller() {
		return downloadSignedContractSeller;
	}
	public void setDownloadSignedContractSeller(boolean downloadSignedContractSeller) {
		this.downloadSignedContractSeller = downloadSignedContractSeller;
	}
	public boolean isUploadPaymentCertificate() {
		return uploadPaymentCertificate;
	}
	public void setUploadPaymentCertificate(boolean uploadPaymentCertificate) {
		this.uploadPaymentCertificate = uploadPaymentCertificate;
	}
	public boolean isDownloadPaymentCertificate() {
		return downloadPaymentCertificate;
	}
	public void setDownloadPaymentCertificate(boolean downloadPaymentCertificate) {
		this.downloadPaymentCertificate = downloadPaymentCertificate;
	}
	public boolean isUploadShipment() {
		return uploadShipment;
	}
	public void setUploadShipment(boolean uploadShipment) {
		this.uploadShipment = uploadShipment;
	}
	public boolean isDownloadShipment() {
		return downloadShipment;
	}
	public void setDownloadShipment(boolean downloadShipment) {
		this.downloadShipment = downloadShipment;
	}

}
