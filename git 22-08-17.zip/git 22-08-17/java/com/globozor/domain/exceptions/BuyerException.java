package com.globozor.domain.exceptions;

public class BuyerException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public BuyerException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BuyerException(String arg0, Throwable arg1, boolean arg2,
			boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public BuyerException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public BuyerException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public BuyerException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
