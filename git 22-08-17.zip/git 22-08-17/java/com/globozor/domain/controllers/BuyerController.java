package com.globozor.domain.controllers;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.globozor.domain.dtos.BuyerRatingDto;
import com.globozor.domain.dtos.DisputeDto;
import com.globozor.domain.dtos.EnquiryDto;
import com.globozor.domain.dtos.FavouriteDto;
import com.globozor.domain.dtos.ResponseDto;
import com.globozor.domain.dtos.SampleRequestDto;
import com.globozor.domain.dtos.SellerEnquiryResponseDto;
import com.globozor.domain.dtos.SellerRatingDto;
import com.globozor.domain.dtos.TransactionDto;
import com.globozor.domain.entity.BuyerEnquiryResponse;
import com.globozor.domain.entity.BuyerRating;
import com.globozor.domain.entity.CompanyProfile;
import com.globozor.domain.entity.Dispute;
import com.globozor.domain.entity.Enquiry;
import com.globozor.domain.entity.Favourite;
import com.globozor.domain.entity.MasterTable;
import com.globozor.domain.entity.PaymentMethod;
import com.globozor.domain.entity.SampleRequest;
import com.globozor.domain.entity.SellerEnquiryResponse;
import com.globozor.domain.entity.SellerRating;
import com.globozor.domain.entity.Transaction;
import com.globozor.domain.exceptions.BuyerException;
import com.globozor.domain.exceptions.SellerException;
import com.globozor.domain.services.BuyerService;
import com.globozor.domain.services.EmailSender;
import com.globozor.domain.services.EntityDtoMapper;
import com.globozor.domain.services.TransactionService;

@RestController
@RequestMapping("/buyer")
public class BuyerController {

	@Autowired
	BuyerService buyerService;
	
	@Autowired
	TransactionService transactionService;
	
	@Autowired
	EmailSender emailSender;
	
	@Autowired
	EntityDtoMapper mapper;
	
	@RequestMapping(value="/getBuyerAllOrders")
	public ResponseDto getAllOrders(HttpServletRequest request){
		HttpSession session = request.getSession(false);
		ResponseDto responseDto = new ResponseDto();
		//if(session!=null){
			//Object object = session.getAttribute("mastertable");
			//MasterTable masterTable = (MasterTable) object;
			MasterTable masterTable = new MasterTable();
			masterTable.setMasterTableId(2);
			List<TransactionDto> transactionDtos = new ArrayList<TransactionDto>();
			List<Transaction> transactions = buyerService.getAllOrders(masterTable);
			for (Transaction transaction : transactions) {
				TransactionDto transactionDto = mapper.transactionEntityToDto(transaction);
				transactionDtos.add(transactionDto);
			}
			List<Object> objects = new ArrayList<Object>();
			objects.add(transactionDtos);
			responseDto = new ResponseDto(objects);
			return responseDto;
		//}
	//	return responseDto;
	}
	
	@RequestMapping("/rateSeller")
	public ResponseDto rateSeller(@RequestBody SellerRating sellerRating){
		ResponseDto responseDto = new ResponseDto();
		MasterTable masterTable = new MasterTable();
		masterTable.setMasterTableId(2);
		SellerRatingDto sellerRatingDto = null;
		try {
			sellerRating=buyerService.rateSeller(sellerRating,masterTable);
			sellerRatingDto=mapper.sellerRatingToDto(sellerRating);
		} catch (BuyerException e) {
			return new ResponseDto(e.getMessage());
		}
		List<Object> objects = new ArrayList<Object>();
		objects.add(sellerRatingDto);
		responseDto = new ResponseDto(objects);
		return responseDto;
	}
	
	/*@RequestMapping("/getBuyerAllRatings")
	public ResponseDto getAllBuyerRating(HttpServletRequest request){
		HttpSession session = request.getSession(false);
		ResponseDto responseDto = new ResponseDto();
		if(session!=null){
			Object object = session.getAttribute("mastertable");
			MasterTable masterTable = (MasterTable) object;
			List<BuyerRating> buyerRatings= buyerService.getAllBuyerRating(masterTable);
			return buyerRatings;
		}
		return null;
	}*/
	
	@RequestMapping("/getBuyerAllRatings")
	public ResponseDto getAllBuyerRating(){
		ResponseDto responseDto = new ResponseDto();
			MasterTable masterTable = new MasterTable(2);
			List<BuyerRating> buyerRatings= buyerService.getAllBuyerRating(masterTable);
			List<BuyerRatingDto> buyerRatingDtos = new ArrayList<BuyerRatingDto>();
			for (BuyerRating buyerRating : buyerRatings) {
				BuyerRatingDto buyerRatingDto = new BuyerRatingDto();
				buyerRatingDto = mapper.buyerRatingToDto(buyerRating);
				buyerRatingDtos.add(buyerRatingDto);
			}
			List<Object> objects = new ArrayList<Object>();
			objects.add(buyerRatingDtos);
			responseDto = new ResponseDto(objects);
			return responseDto;
	}
	
	@RequestMapping("/createDispute")
	public ResponseDto createDispute(@RequestBody Dispute dispute){
		ResponseDto responseDto = new ResponseDto();
		MasterTable masterTable = new MasterTable(2);
		try {
			Transaction transaction = dispute.getTransaction();
			transaction.setApprovedTradeDates(false);
			dispute.setTransaction(transaction);
			dispute=buyerService.createDispute(dispute,masterTable);
			System.out.println("dis is "+dispute);
		} catch (BuyerException e) {
			return new ResponseDto(e.getMessage());
		}
		DisputeDto disputeDto = mapper.disputeEntityToDto(dispute,false);
		List<Object> objects = new ArrayList<Object>();
		objects.add(disputeDto);
		responseDto = new ResponseDto(objects);
		return responseDto;
	}
	
	/*@RequestMapping("/getBuyerAllDisputes")
	public List<Dispute> getAllDisputes(@RequestParam String type){
		ResponseDto responseDto = new ResponseDto();
			MasterTable masterTable = new MasterTable(2);
			try {
				return buyerService.getAllDisputes(masterTable,type);
			} catch (BuyerException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}*/
	
	@RequestMapping("/getBuyerAllDisputes")
	public ResponseDto getAllDisputes(@RequestParam String type){
		ResponseDto responseDto = new ResponseDto();
			MasterTable masterTable = new MasterTable(2);
			List<DisputeDto> disputeDtos = new ArrayList<DisputeDto>();
			try {
				List<Dispute> disputes = buyerService.getAllDisputes(masterTable,type);
				for (Dispute dispute : disputes) {
					DisputeDto DisputeDto = mapper.disputeEntityToDto(dispute,false);
					disputeDtos.add(DisputeDto);
				}
			} catch (BuyerException e) {
				return new ResponseDto(e.getMessage());
			}
			List<Object> objects = new ArrayList<Object>();
			objects.add(disputeDtos);
			responseDto = new ResponseDto(objects);
			return responseDto;
	}
	
	/*@RequestMapping("/getBuyerAllSampleRequest")
	public List<SampleRequest> getAllSampleRequest(@RequestParam String status , HttpServletRequest request){
		HttpSession session = request.getSession(false);
		ResponseDto responseDto = new ResponseDto();
		if(session!=null){
			Object object = session.getAttribute("mastertable");
			MasterTable masterTable = (MasterTable) object;
			return buyerService.getAllSampleRequest(masterTable,status);
		}
		return null;
	}*/
	
	@RequestMapping("/getBuyerAllSampleRequest")
	public ResponseDto getAllSampleRequest(@RequestParam String status){
		ResponseDto responseDto = new ResponseDto();
			MasterTable masterTable = new MasterTable(2);
			List<SampleRequest> sampleRequests = buyerService.getAllSampleRequest(masterTable,status);
			List<SampleRequestDto> sampleRequestDtos = new ArrayList<SampleRequestDto>();
			for (SampleRequest sampleRequest : sampleRequests) {
				SampleRequestDto sampleRequestDto = mapper.sampleRequestToDto(sampleRequest);
				sampleRequestDtos.add(sampleRequestDto);
			}
			List<Object> objects = new ArrayList<Object>();
			objects.add(sampleRequestDtos);
			responseDto = new ResponseDto(objects);
			return responseDto;
	}
	
	/*@RequestMapping("/getBuyerAllEnquiries")
	public List<Enquiry> getBuyerAllEnquiries(HttpServletRequest request){
		HttpSession session = request.getSession(false);
		ResponseDto responseDto = new ResponseDto();
		if(session!=null){
			Object object = session.getAttribute("mastertable");
			MasterTable masterTable = (MasterTable) object;
			return buyerService.getBuyerAllEnquiries(masterTable);
		}
		return null;
	}*/
	
	@RequestMapping("/getBuyerAllEnquiries")
	public ResponseDto getBuyerAllEnquiries(){
		ResponseDto responseDto = new ResponseDto();
			MasterTable masterTable = new MasterTable(2);
			List<Enquiry> enquiries = buyerService.getBuyerAllEnquiries(masterTable);
			List<EnquiryDto> enquiryDtos = new ArrayList<EnquiryDto>();
			for (Enquiry enquiry : enquiries) {
				EnquiryDto enquiryDto = mapper.enquiryEntityToDto(enquiry);
				enquiryDtos.add(enquiryDto);
			}
			List<Object> objects = new ArrayList<Object>();
			objects.add(enquiryDtos);
			responseDto = new ResponseDto(objects);
			return responseDto;
	}
	
	/*@RequestMapping("/getSellerEnquiryResponse")
	//two types of response all responses plus negotiated responses
	public List<SellerEnquiryResponse> getSellerEnquiryResponse(@RequestParam String type , HttpServletRequest request){
		HttpSession session = request.getSession(false);
		ResponseDto responseDto = new ResponseDto();
		if(session!=null){
			Object object = session.getAttribute("mastertable");
			MasterTable masterTable = (MasterTable) object;
			return buyerService.getSellerEnquiryResponse(type,masterTable);
		}
		return null;
	}*/
	
	@RequestMapping("/getSellerEnquiryResponse")
	//two types of response all responses plus negotiated responses
	public ResponseDto getSellerEnquiryResponse(@RequestParam String type){
		ResponseDto responseDto = new ResponseDto();
			MasterTable masterTable = new MasterTable(2);
			List<SellerEnquiryResponse> sellerEnquiryResponses = buyerService.getSellerEnquiryResponse(type,masterTable);
			List<SellerEnquiryResponseDto> sellerEnquiryResponseDtos = new ArrayList<SellerEnquiryResponseDto>();
			for (SellerEnquiryResponse sellerEnquiryResponse : sellerEnquiryResponses) {
				SellerEnquiryResponseDto enquiryResponseDto = mapper.sellerEnqResponseToDto(sellerEnquiryResponse);
				sellerEnquiryResponseDtos.add(enquiryResponseDto);
			}
			List<Object> objects = new ArrayList<Object>();
			objects.add(sellerEnquiryResponseDtos);
			responseDto = new ResponseDto(objects);
			return responseDto;
	}
	
	@RequestMapping("/getPaymentMethods")
	public ResponseDto getPaymentMethods(@RequestBody MasterTable masterTable){
		ResponseDto responseDto = new ResponseDto();
		Set<PaymentMethod> paymentMethods=buyerService.getPaymentMethods(masterTable);
		List<Object> objects = new ArrayList<Object>();
		objects.add(paymentMethods);
		responseDto = new ResponseDto(objects);
		return responseDto;
	}
	
	@RequestMapping("/responseSellerEnquiryResponse")
	public ResponseDto responseSellerEnquiryResponse(@RequestBody BuyerEnquiryResponse buyerEnquiryResponse,@RequestParam String response, @RequestParam long paymentMethodId){
		ResponseDto responseDto = new ResponseDto();
		MasterTable masterTable = new MasterTable(2);
		buyerEnquiryResponse = buyerService.responseSellerEnquiryResponse(response,buyerEnquiryResponse);
		
		if(response.equalsIgnoreCase("accepted")){
			Transaction transaction = new Transaction();
			transaction.setSeller(buyerEnquiryResponse.getSellerEnquiryResponse().getSeller());
			transaction.setBuyer(masterTable);
			transaction.setSellerProduct(buyerEnquiryResponse.getEnquiry().getSellerProduct());
			PaymentMethod paymentMethod= new PaymentMethod();
			paymentMethod.setPaymentMethodId(paymentMethodId);
			transaction.setPaymentMethod(paymentMethod);
			transaction.setUnitPrice(BigDecimal.valueOf(Double.parseDouble(buyerEnquiryResponse.getUnitPrice())));
			transaction.setQuantity(BigDecimal.valueOf(buyerEnquiryResponse.getQuantity()));
			transaction.setTradeAmount(transaction.getUnitPrice().multiply(transaction.getQuantity()));
			transaction.setCommission(BigDecimal.valueOf(0));
			transaction = transactionService.saveTransaction(transaction);
		}
		
		List<Object> objects = new ArrayList<Object>();
		objects.add(buyerEnquiryResponse);
		responseDto = new ResponseDto(objects);
		return responseDto;
	}
	/*@RequestMapping("/saveBuyerCompanyProfile")
	public CompanyProfile saveCompanyProfile(@RequestBody CompanyProfile companyProfile , HttpServletRequest request){
		HttpSession session = request.getSession(false);
		ResponseDto responseDto = new ResponseDto();
		if(session!=null){
			Object object = session.getAttribute("mastertable");
			MasterTable masterTable = (MasterTable) object;
			companyProfile.setMasterTable(masterTable);
			return buyerService.saveCompanyProfile(companyProfile);
		}
		return null;
	}*/
	
	@RequestMapping("/saveBuyerCompanyProfile")
	public ResponseDto saveCompanyProfile(@RequestBody CompanyProfile companyProfile){
		ResponseDto responseDto = new ResponseDto();
			MasterTable masterTable = new MasterTable(2);
			companyProfile.setMasterTable(masterTable);
			companyProfile = buyerService.saveCompanyProfile(companyProfile);
			List<Object> objects = new ArrayList<Object>();
			objects.add(companyProfile);
			responseDto = new ResponseDto(objects);
			return responseDto;
	}
	
	@RequestMapping("/getSellerCompanyProfile")
	public ResponseDto getSellerCompanyProfile(@RequestBody MasterTable masterTable){
		ResponseDto responseDto = new ResponseDto();
		CompanyProfile companyProfile = buyerService.getSellerCompanyProfile(masterTable);
		List<Object> objects = new ArrayList<Object>();
		objects.add(companyProfile);
		responseDto = new ResponseDto(objects);
		return responseDto;
	}
	
	@SuppressWarnings("unchecked")
	@RequestMapping("/subscribeNow")
	public void subscribeNow(HttpServletRequest request){
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("to", "");
		jsonObject.put("from", "");
		jsonObject.put("subject", "");
		jsonObject.put("text", "");
		HttpSession session = request.getSession(false);
		ResponseDto responseDto = new ResponseDto();
		if(session!=null){
			Object object = session.getAttribute("mastertable");
			MasterTable masterTable = (MasterTable) object;
			emailSender.sendEmail(jsonObject, masterTable);
		}
	}
	
	/*@RequestMapping("/addFavourite")
	public Favourite addFavourite(@RequestParam long id , HttpServletRequest request){
		HttpSession session = request.getSession(false);
		ResponseDto responseDto = new ResponseDto();
		if(session!=null){
			Object object = session.getAttribute("mastertable");
			MasterTable masterTable = (MasterTable) object;
			return buyerService.addFavourite(masterTable,id);
		}
		return null;
	}*/
	
	@RequestMapping("/addFavourite")
	public ResponseDto addFavourite(@RequestParam long id){
		ResponseDto responseDto = new ResponseDto();
			MasterTable masterTable = new MasterTable();
			masterTable.setMasterTableId(2);
			Favourite favourite = buyerService.addFavourite(masterTable,id);
			FavouriteDto favouriteDto = mapper.favouriteEntityToDto(favourite);
			List<Object> objects = new ArrayList<Object>();
			objects.add(favouriteDto);
			responseDto = new ResponseDto(objects);
			return responseDto;
	}
	
	@RequestMapping("/getAllFavourites")
	public ResponseDto getAllFavourites(){
		//HttpSession session = request.getSession(false);
		ResponseDto responseDto = new ResponseDto();
		//if(session!=null){
			//Object object = session.getAttribute("mastertable");
			MasterTable masterTable = new MasterTable(2);
			List<Favourite> favourites = buyerService.getAllFavourites(masterTable);
			List<FavouriteDto> favouriteDtos = new ArrayList<FavouriteDto>();
			for (Favourite favourite : favourites) {
				FavouriteDto favouriteDto = mapper.favouriteEntityToDto(favourite);
				favouriteDtos.add(favouriteDto);
			}
			List<Object> objects = new ArrayList<Object>();
			objects.add(favouriteDtos);
			responseDto = new ResponseDto(objects);
		//}else{
			//responseDto = new ResponseDto("Session has expired");
		//}
		return responseDto;
	}
}
