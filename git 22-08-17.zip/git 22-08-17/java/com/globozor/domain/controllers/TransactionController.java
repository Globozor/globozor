package com.globozor.domain.controllers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.globozor.domain.dtos.ResponseDto;
import com.globozor.domain.dtos.TransactionDto;
import com.globozor.domain.dtos.TransactionFileDto;
import com.globozor.domain.dtos.TransactionTrackerDto;
import com.globozor.domain.entity.Transaction;
import com.globozor.domain.entity.TransactionFile;
import com.globozor.domain.entity.TransactionTracker;
import com.globozor.domain.services.EntityDtoMapper;
import com.globozor.domain.services.TransactionService;

@RestController
@RequestMapping("/transaction")
public class TransactionController {

	@Autowired
	TransactionService transactionService;
	
	@Autowired
	EntityDtoMapper mapper;
	
	@RequestMapping(value="/getTransactionDetail")
	public ResponseDto getTransactionDetail(@RequestBody Transaction transaction){
		ResponseDto responseDto = new ResponseDto();
		Transaction transaction2 = transactionService.getTransactionDetail(transaction.getTransactionId());
		TransactionDto transactionDto = mapper.transactionEntityToDto(transaction2);
		List<Object> objects = new ArrayList<Object>();
		objects.add(transactionDto);
		responseDto = new ResponseDto(objects);
		return responseDto;
	}
	
	@RequestMapping(value="/saveFile")
	public TransactionFile saveFile(@RequestBody TransactionFile transactionFile){
		transactionFile = transactionService.saveFile(transactionFile);
		return transactionFile;
	}
	
	@RequestMapping(value="/getFile")
	public ResponseDto getFile(@RequestBody TransactionFile transactionFile){
		ResponseDto responseDto = new ResponseDto();
		List<TransactionFile> transactionFiles = transactionService.getFile(transactionFile);
		List<TransactionFileDto> transactionFileDtos = new ArrayList<TransactionFileDto>();
		for (TransactionFile transactionFile2 : transactionFiles) {
			TransactionFileDto transactionFileDto = mapper.transactionFileToDto(transactionFile2);
			transactionFileDtos.add(transactionFileDto);
		}
		List<Object> objects = new ArrayList<Object>();
		objects.add(transactionFileDtos);
		responseDto = new ResponseDto(objects);
		return responseDto;
	}
	
	@RequestMapping("/updateTransactionTracker")
	public ResponseDto saveTransactionTracker(@RequestBody TransactionTracker transactionTracker){
		ResponseDto responseDto = new ResponseDto();
		transactionTracker = transactionService.saveTransactionTracker(transactionTracker);
		TransactionTrackerDto transactionTrackerDto = mapper.transactionTrackerToDto(transactionTracker);
		List<Object> objects = new ArrayList<Object>();
		objects.add(transactionTrackerDto);
		responseDto = new ResponseDto(objects);
		return responseDto;
	}

	@RequestMapping("/getTransactionTracker")
	public ResponseDto getTransactionTracker(@RequestBody Transaction transaction){
		ResponseDto responseDto = new ResponseDto();
		TransactionTracker transactionTracker = transactionService.getTransactionTracker(transaction.getTransactionId());
		TransactionTrackerDto transactionTrackerDto = mapper.transactionTrackerToDto(transactionTracker);
		List<Object> objects = new ArrayList<Object>();
		objects.add(transactionTrackerDto);
		responseDto = new ResponseDto(objects);
		return responseDto;
	}
}

