package com.globozor.domain.controllers;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.globozor.domain.dtos.BuyerEnquiryResponseDto;
import com.globozor.domain.dtos.BuyerRatingDto;
import com.globozor.domain.dtos.CompanyDto;
import com.globozor.domain.dtos.CompanyProfileDto;
import com.globozor.domain.dtos.CustomerDetailDto;
import com.globozor.domain.dtos.DisputeDto;
import com.globozor.domain.dtos.MasterTableDto;
import com.globozor.domain.dtos.ResponseDto;
import com.globozor.domain.dtos.SampleRequestDto;
import com.globozor.domain.dtos.SellerDescriptionDto;
import com.globozor.domain.dtos.SellerDto;
import com.globozor.domain.dtos.SellerEnquiryDto;
import com.globozor.domain.dtos.SellerEnquiryResponseDto;
import com.globozor.domain.dtos.SellerProductDto;
import com.globozor.domain.dtos.SellerRatingDto;
import com.globozor.domain.dtos.TradeShowDto;
import com.globozor.domain.dtos.TransactionDto;
import com.globozor.domain.dtos.UserInfo;
import com.globozor.domain.entity.BuyerEnquiryResponse;
import com.globozor.domain.entity.BuyerRating;
import com.globozor.domain.entity.CompanyProfile;
import com.globozor.domain.entity.CustomerDetail;
import com.globozor.domain.entity.Dispute;
import com.globozor.domain.entity.MasterTable;
import com.globozor.domain.entity.MembershipType;
import com.globozor.domain.entity.Notification;
import com.globozor.domain.entity.PaymentMethod;
import com.globozor.domain.entity.SampleRequest;
import com.globozor.domain.entity.SellerDescription;
import com.globozor.domain.entity.SellerEnquiry;
import com.globozor.domain.entity.SellerEnquiryResponse;
import com.globozor.domain.entity.SellerProduct;
import com.globozor.domain.entity.SellerRating;
import com.globozor.domain.entity.TradeShow;
import com.globozor.domain.entity.Transaction;
import com.globozor.domain.exceptions.SellerException;
import com.globozor.domain.services.EmailSender;
import com.globozor.domain.services.EntityDtoMapper;
import com.globozor.domain.services.SellerService;
import com.globozor.domain.services.TransactionService;
import com.globozor.domain.services.UserService;

@RestController
@RequestMapping("/seller")
public class SellerController {

	@Autowired
	SellerService sellerService;
	
	@Autowired
	EntityDtoMapper mapper;
	
	@Autowired
	EmailSender emailSender;
	
	@Autowired
	UserService userService;
	
	@Autowired
	TransactionService transactionService;
	
	/*@RequestMapping(value="/getSellerDescription")
	public ResponseDto getSellerDescription(HttpServletRequest request){
		HttpSession session = request.getSession(false);
		ResponseDto responseDto = new ResponseDto();
		if(session!=null){
			Object object = session.getAttribute("mastertable");
			MasterTable masterTable = (MasterTable) object;
			List<Object> objects = new ArrayList<Object>();
			SellerDescription sellerDescription = sellerService.getSellerDescription(masterTable);
			objects.add(sellerDescription);
			responseDto = new ResponseDto(objects);
		}else{
			responseDto = new ResponseDto("Session has expired");
		}
		return responseDto;
	}*/
	
	@RequestMapping(value="/getSellerDescription")
	public ResponseDto getSellerDescription(){
		ResponseDto responseDto = new ResponseDto();
			MasterTable masterTable = new MasterTable();
			masterTable.setMasterTableId(4);
			List<Object> objects = new ArrayList<Object>();
			SellerDescription sellerDescription = sellerService.getSellerDescription(masterTable);
			SellerDescriptionDto sellerDescriptionDto = mapper.sellerDescEntityToDto(sellerDescription);
			objects.add(sellerDescriptionDto);
			responseDto = new ResponseDto(objects);
		return responseDto;
	}
	
	@RequestMapping(value="/saveTradeShow")
	public ResponseDto saveTradeShow(@RequestBody TradeShow tradeShow){
		ResponseDto responseDto = new ResponseDto();
		tradeShow = sellerService.saveTradeShow(tradeShow);
		TradeShowDto tradeShowDto = mapper.tradeShowEntityToDto(tradeShow);
		List<Object> objects = new ArrayList<Object>();
		objects.add(tradeShowDto);
		responseDto = new ResponseDto(objects);
		return responseDto;
	}
	
	@RequestMapping(value="/saveCustomerDetail")
	public ResponseDto saveCustomerDetail(@RequestBody CustomerDetail customerDetail){
		ResponseDto responseDto = new ResponseDto();
		customerDetail = sellerService.saveCustomerDetail(customerDetail);
		CustomerDetailDto customerDetailDto = mapper.customerEntityToDto(customerDetail);
		List<Object> objects = new ArrayList<Object>();
		objects.add(customerDetailDto);
		responseDto = new ResponseDto(objects);
		return responseDto;
	}
	
	@RequestMapping(value="/responseEnquiry",method=RequestMethod.POST)
	public ResponseDto responseEnquiry(@RequestBody SellerEnquiryResponse sellerEnquiryResponse, @RequestParam String response){
		ResponseDto responseDto = new ResponseDto();
		MasterTable seller = new MasterTable();
		seller.setMasterTableId(4);
		sellerEnquiryResponse.setSeller(seller);
		sellerEnquiryResponse = sellerService.responseEnquiry(sellerEnquiryResponse,response);
		SellerEnquiryResponseDto sellerEnquiryResponseDto= mapper.sellerEnqResponseToDto(sellerEnquiryResponse);
		List<Object> objects = new ArrayList<Object>();
		objects.add(sellerEnquiryResponseDto);
		responseDto = new ResponseDto(objects);
		
		if(response.equalsIgnoreCase("accepted")){
			Transaction transaction = new Transaction();
			transaction.setSeller(sellerEnquiryResponse.getSeller());
			transaction.setBuyer(sellerEnquiryResponse.getBuyer());
			transaction.setSellerProduct(sellerEnquiryResponse.getEnquiry().getSellerProduct());
			PaymentMethod paymentMethod= new PaymentMethod();
			paymentMethod.setPaymentMethodId(1);
			transaction.setPaymentMethod(paymentMethod);
			transaction.setUnitPrice(BigDecimal.valueOf(Double.parseDouble(sellerEnquiryResponse.getUnitPrice())));
			transaction.setQuantity(BigDecimal.valueOf(sellerEnquiryResponse.getQuantity()));
			transaction.setTradeAmount(transaction.getUnitPrice().multiply(transaction.getQuantity()));
			transaction.setCommission(BigDecimal.valueOf(0));
			transaction = transactionService.saveTransaction(transaction);
		}
		return responseDto;
	}
	
	@RequestMapping(value="/getBuyerResponses")
	public ResponseDto getBuyerResponses(@RequestParam String type){
		ResponseDto responseDto = new ResponseDto();
		MasterTable seller = new MasterTable(4);
		List<BuyerEnquiryResponse> buyerEnquiryResponses = sellerService.getBuyerResponses(seller,type);
		List<BuyerEnquiryResponseDto> buyerEnquiryResponseDtos = new ArrayList<BuyerEnquiryResponseDto>();
		for (BuyerEnquiryResponse buyerEnquiryResponse : buyerEnquiryResponses) {
			BuyerEnquiryResponseDto buyerEnquiryResponseDto = mapper.buyerEnquiryResponseToDto(buyerEnquiryResponse);
			buyerEnquiryResponseDtos.add(buyerEnquiryResponseDto);
		}
		List<Object> objects = new ArrayList<Object>();
		objects.add(buyerEnquiryResponseDtos);
		responseDto = new ResponseDto(objects);
		return responseDto;
	}
	/*
	@RequestMapping(value="/responseBuyerResponse",method=RequestMethod.POST)
	public ResponseDto responseBuyerResponse(@RequestBody SellerEnquiryResponse sellerEnquiryResponse,@RequestParam String response){
		return null;
	}*/
	
	@RequestMapping(value="/getNotifications",method=RequestMethod.GET)
	public List<Notification> getNotifications() {
		MasterTable masterTable = new MasterTable();
		masterTable.setMasterTableId(4);
		return sellerService.getNotifications(masterTable);
	}
	
	@RequestMapping(value = "/addSellerProduct",method=RequestMethod.POST)
	public ResponseDto addSellerProduct(@RequestBody SellerProduct sellerProduct){
		ResponseDto responseDto = new ResponseDto();
		MasterTable masterTable = new MasterTable();
		masterTable.setMasterTableId(4);
		sellerProduct = sellerService.addSellerProduct(sellerProduct,masterTable);
		SellerProductDto sellerProductDto = mapper.sellerProductToDto(sellerProduct);
		List<Object> objects = new ArrayList<Object>();
		objects.add(sellerProductDto);
		responseDto = new ResponseDto(objects);
		return responseDto;
	}
	
	@RequestMapping(value="/removeSellerProduct")
	public ResponseDto removeSellerProduct(@RequestParam long sellerProductId){
		String message = "";
		MasterTable masterTable = new MasterTable();
		masterTable.setMasterTableId(4);
		try {
			message = sellerService.removeSellerProduct(sellerProductId,masterTable);
		} catch (SellerException e) {
			return new ResponseDto(e.getMessage());
		}
		return new ResponseDto(message);
	}
	
	/*@RequestMapping("/getAllSellerProduct")
	public List<SellerProductDto> getSellerProduct(@RequestParam String status , HttpServletRequest request){
		List<SellerProductDto> sellerProductDtos = new ArrayList<SellerProductDto>();
		HttpSession session = request.getSession(false);
		ResponseDto responseDto = new ResponseDto();
		if(session!=null){
			Object object = session.getAttribute("mastertable");
			MasterTable masterTable = (MasterTable) object;
			List<SellerProduct> sellerProducts = sellerService.getSellerProduct(masterTable,status);
			for (SellerProduct sellerProduct : sellerProducts) {
				SellerProductDto sellerProductDto = mapper.sellerProductToDto(sellerProduct);
				sellerProductDtos.add(sellerProductDto);
			}
		}
		return sellerProductDtos;
	}*/
	
	@RequestMapping("/getAllSellerProduct")
	public ResponseDto getSellerProduct(@RequestParam String status){
		List<SellerProductDto> sellerProductDtos = new ArrayList<SellerProductDto>();
		ResponseDto responseDto = new ResponseDto();
			MasterTable masterTable = new MasterTable();
			masterTable.setMasterTableId(4);
			List<SellerProduct> sellerProducts = sellerService.getSellerProduct(masterTable,status);
			for (SellerProduct sellerProduct : sellerProducts) {
				SellerProductDto sellerProductDto = mapper.sellerProductToDto(sellerProduct);
				sellerProductDtos.add(sellerProductDto);
			}
			List<Object> objects = new ArrayList<Object>();
			objects.add(sellerProductDtos);
			responseDto = new ResponseDto(objects);
			return responseDto;
	}
	
	/*@RequestMapping("/getSellerEnquiry")
	public List<SellerEnquiryDto> getSellerEnquiry(HttpServletRequest request){
		List<SellerEnquiryDto> sellerEnquiryDtos = new ArrayList<SellerEnquiryDto>();
		HttpSession session = request.getSession(false);
		ResponseDto responseDto = new ResponseDto();
		if(session!=null){
			Object object = session.getAttribute("mastertable");
			MasterTable masterTable = (MasterTable) object;
			List<SellerEnquiry> sellerEnquiries =  sellerService.getSellerEnquiry(masterTable);
			for (SellerEnquiry sellerEnquiry : sellerEnquiries) {
				SellerEnquiryDto sellerEnquiryDto = mapper.sellerEnquiryToDto(sellerEnquiry);
				sellerEnquiryDtos.add(sellerEnquiryDto);
			}
		}
		return sellerEnquiryDtos;
	}*/
	
	@RequestMapping("/getSellerEnquiry")
	public ResponseDto getSellerEnquiry(){
		List<SellerEnquiryDto> sellerEnquiryDtos = new ArrayList<SellerEnquiryDto>();
		ResponseDto responseDto = new ResponseDto();
			MasterTable masterTable = new MasterTable();
			masterTable.setMasterTableId(4);
			List<SellerEnquiry> sellerEnquiries =  sellerService.getSellerEnquiry(masterTable);
			for (SellerEnquiry sellerEnquiry : sellerEnquiries) {
				SellerEnquiryDto sellerEnquiryDto = mapper.sellerEnquiryToDto(sellerEnquiry);
				sellerEnquiryDtos.add(sellerEnquiryDto);
			}
			List<Object> objects = new ArrayList<Object>();
			objects.add(sellerEnquiryDtos);
			responseDto = new ResponseDto(objects);
			return responseDto;
	}
	
	@RequestMapping("/rejectEnquiry")
	public String rejectEnquiry(@RequestParam long enquiryId){
		SellerEnquiry sellerEnquiry = sellerService.rejectEnquiry(enquiryId);
		String status = null;
		if(sellerEnquiry != null){
			status = "removed";
		}
		return status;
	}
	
	/*@RequestMapping("/getSellerProductShowCase")
	public List<SellerProductDto> getSellerProductShowCase(HttpServletRequest request){
		HttpSession session = request.getSession(false);
		List<SellerProductDto> sellerProductDtos = new ArrayList<SellerProductDto>();
		ResponseDto responseDto = new ResponseDto();
		if(session!=null){
			Object object = session.getAttribute("mastertable");
			MasterTable masterTable = (MasterTable) object;
			List<SellerProduct> sellerProducts = sellerService.getSellerProductShowCase(masterTable);
			for (SellerProduct sellerProduct : sellerProducts) {
				SellerProductDto sellerProductDto = mapper.sellerProductToDto(sellerProduct);
				sellerProductDtos.add(sellerProductDto);
			}
		}
		return sellerProductDtos;
	}*/
	
	@RequestMapping("/getSellerProductShowCase")
	public ResponseDto getSellerProductShowCase(){
		List<SellerProductDto> sellerProductDtos = new ArrayList<SellerProductDto>();
		ResponseDto responseDto = new ResponseDto();
			MasterTable masterTable = new MasterTable();
			masterTable.setMasterTableId(4);
			SellerDescription sellerDescription = new SellerDescription();
			MembershipType membershipType= new MembershipType();
			membershipType.setMembershipTypeId(1);
			sellerDescription.setMembershipType(membershipType);
			masterTable.setSellerDescription(sellerDescription);
			List<SellerProduct> sellerProducts = sellerService.getSellerProductShowCase(masterTable);
			for (SellerProduct sellerProduct : sellerProducts) {
				SellerProductDto sellerProductDto = mapper.sellerProductToDto(sellerProduct);
				sellerProductDtos.add(sellerProductDto);
			}
		
			List<Object> objects = new ArrayList<Object>();
			objects.add(sellerProductDtos);
			responseDto = new ResponseDto(objects);
			return responseDto;
	}
	
	/*@RequestMapping("/setSellerProductPriority")
	public SellerProductDto setSellerProductPriority(@RequestParam long sellerProductId , @RequestParam int priority , HttpServletRequest request){
		HttpSession session = request.getSession(false);
		ResponseDto responseDto = new ResponseDto();
		if(session!=null){
			Object object = session.getAttribute("mastertable");
			MasterTable masterTable = (MasterTable) object;
			SellerProduct sellerProduct = sellerService.setSellerProductPriority(sellerProductId,priority,masterTable);
			SellerProductDto sellerProductDto = mapper.sellerProductToDto(sellerProduct);
			return sellerProductDto;
		}
		return null;
	}*/
	
	@RequestMapping("/setSellerProductPriority")
	public ResponseDto setSellerProductPriority(@RequestParam long sellerProductId , @RequestParam int priority){
		ResponseDto responseDto = new ResponseDto();
			MasterTable masterTable = new MasterTable();
			masterTable.setMasterTableId(4);
			SellerProduct sellerProduct;
			try {
				sellerProduct = sellerService.setSellerProductPriority(sellerProductId,priority,masterTable);
			} catch (SellerException e) {
				return new ResponseDto(e.getMessage());
			}
			SellerProductDto sellerProductDto = mapper.sellerProductToDto(sellerProduct);
			List<Object> objects = new ArrayList<Object>();
			objects.add(sellerProductDto);
			responseDto = new ResponseDto(objects);
			return responseDto;
	}
	
	
	/*@RequestBody("/getModifiedEnquiry")
	public */
	/*@RequestMapping("/saveCompanyProfile")
	public CompanyProfileDto saveCompanyProfile(@RequestBody String jsonArray){
		ObjectMapper mapper = new ObjectMapper();
		System.out.println("string is "+jsonArray);
		JsonNode node;
		try {
			node = mapper.readTree(jsonArray);
			System.out.println("node is "+node);
			CompanyProfile companyProfile = mapper.convertValue(node.get(0), CompanyProfile.class);
			System.out.println("company is "+companyProfile);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
		//return sellerService.saveCompanyProfile(jsonArray);
	}*/
	
	/*@RequestMapping("/saveCompanyProfile")
	public CompanyProfile saveCompanyProfile(@RequestBody CompanyProfile companyProfile , HttpServletRequest request){
		HttpSession session = request.getSession(false);
		ResponseDto responseDto = new ResponseDto();
		if(session!=null){
			Object object = session.getAttribute("mastertable");
			MasterTable masterTable = (MasterTable) object;
			companyProfile.setMasterTable(masterTable);
			return sellerService.saveCompanyProfile(companyProfile);
		}
		return null;
	}*/
	
	/*@RequestMapping("/saveCompanyProfile")
	public CompanyProfile saveCompanyProfile(@RequestBody CompanyProfile companyProfile){
		ResponseDto responseDto = new ResponseDto();
			MasterTable masterTable = new MasterTable();
			masterTable.setMasterTableId(4);
			companyProfile.setMasterTable(masterTable);
			return sellerService.saveCompanyProfile(companyProfile);
	}*/
	
	@RequestMapping("/saveCompanyProfile")
	public ResponseDto saveCompanyProfile(@RequestBody CompanyDto companyProfileDto){
		ResponseDto responseDto = new ResponseDto();
			MasterTable masterTable = new MasterTable();
			masterTable.setMasterTableId(4);
			CompanyProfile companyProfile = null;
			try {
				companyProfile = sellerService.saveCompanyProfil(companyProfileDto,masterTable);
			} catch (SellerException e) {
				responseDto = new ResponseDto(e.getMessage());
			}
			List<Object> objects = new ArrayList<Object>();
			objects.add(companyProfile);
			responseDto = new ResponseDto(objects);
			return responseDto;
	}
	
	@RequestMapping("/saveCompanyProfilepage2")
	public ResponseDto saveCompanyProfilePage2(@RequestBody UserInfo userInfo){
		ResponseDto responseDto = new ResponseDto();
			MasterTable masterTable = new MasterTable(4);
			MasterTable user = sellerService.saveCompanyProfilePage2(userInfo,masterTable);
			MasterTableDto userDto = mapper.masterTableEntityToDto(user);
			List<Object> objects = new ArrayList<Object>();
			objects.add(userDto);
			responseDto = new ResponseDto(objects);
			return responseDto;
	}
	
	@RequestMapping("/getBuyerResponse")
	public BuyerEnquiryResponse getBuyerEnquiryResponse(){
		//return sellerService.getBuyerEnquiryResponse();
		return null;
	}
	
	@RequestMapping("/createDispute")
	public ResponseDto createDispute(@RequestBody Dispute dispute){
		ResponseDto responseDto = new ResponseDto();
		MasterTable masterTable = new MasterTable();
		masterTable.setMasterTableId(4);
		try {
			Transaction transaction = dispute.getTransaction();
			transaction.setApprovedTradeDates(false);
			dispute.setTransaction(transaction);
			dispute = sellerService.createDispute(dispute,masterTable);
			System.out.println("dis is "+dispute);
		} catch (SellerException e) {
			return new ResponseDto(e.getMessage());
		}
		List<Object> objects = new ArrayList<Object>();
		DisputeDto disputeDto = mapper.disputeEntityToDto(dispute,true);
		objects.add(disputeDto);
		responseDto = new ResponseDto(objects);
		return responseDto;
	}
	
	/*@RequestMapping("/getSellerAllDisputes")
	public List<Dispute> getAllDisputes(HttpServletRequest request){
		HttpSession session = request.getSession(false);
		ResponseDto responseDto = new ResponseDto();
		if(session!=null){
			Object object = session.getAttribute("mastertable");
			MasterTable masterTable = (MasterTable) object;
			return sellerService.getAllDisputes(masterTable);
		}
		return null;
	}*/
	
	@RequestMapping("/getSellerAllDisputes")
	public ResponseDto getAllDisputes(@RequestParam String type){
		ResponseDto responseDto = new ResponseDto();
			MasterTable masterTable = new MasterTable();
			masterTable.setMasterTableId(4);
			List<DisputeDto> disputeDtos = new ArrayList<DisputeDto>();
			try {
				List<Dispute> disputes = sellerService.getAllDisputes(masterTable,type);
				for (Dispute dispute : disputes) {
					DisputeDto DisputeDto = mapper.disputeEntityToDto(dispute,true);
					disputeDtos.add(DisputeDto);
				}
			} catch (SellerException e) {
				return new ResponseDto(e.getMessage());
			}
			List<Object> objects = new ArrayList<Object>();
			objects.add(disputeDtos);
			responseDto = new ResponseDto(objects);
			return responseDto;
	}

	@RequestMapping("/rateBuyer")
	public ResponseDto rateBuyer(@RequestBody BuyerRating buyerRating){
		ResponseDto responseDto = new ResponseDto();
		MasterTable masterTable = new MasterTable();
		masterTable.setMasterTableId(4);
		BuyerRatingDto buyerRatingDto;
		try {
			buyerRating = sellerService.rateBuyer(buyerRating,masterTable);
			buyerRatingDto = mapper.buyerRatingToDto(buyerRating);
		} catch (SellerException e) {
			return new ResponseDto(e.getMessage());
		}
		List<Object> objects = new ArrayList<Object>();
		objects.add(buyerRatingDto);
		responseDto = new ResponseDto(objects);
		return responseDto;
	}
	
	/*@RequestMapping("/getSellerAllRatings")
	public List<SellerRating> getAllSellerRating(HttpServletRequest request){
		HttpSession session = request.getSession(false);
		ResponseDto responseDto = new ResponseDto();
		if(session!=null){
			Object object = session.getAttribute("mastertable");
			MasterTable masterTable = (MasterTable) object;
			return sellerService.getAllSellerRating(masterTable);
		}
		return null;
	}*/
	
	@RequestMapping("/getSellerAllRatings")
	public ResponseDto getAllSellerRating(){
		ResponseDto responseDto = new ResponseDto();
			MasterTable masterTable = new MasterTable();
			masterTable.setMasterTableId(4);
			List<SellerRatingDto> sellerRatingDtos = new ArrayList<SellerRatingDto>();
			List<SellerRating> sellerRatings= sellerService.getAllSellerRating(masterTable);
			for (SellerRating sellerRating : sellerRatings) {
				SellerRatingDto sellerRatingDto = mapper.sellerRatingToDto(sellerRating);
				sellerRatingDtos.add(sellerRatingDto);
			}
			List<Object> objects = new ArrayList<Object>();
			objects.add(sellerRatingDtos);
			responseDto = new ResponseDto(objects);
			return responseDto;
	}
	
	/*@RequestMapping(value="getSellerAllOrders")
	public List<Transaction> getAllSellerOrders(HttpServletRequest request){
		HttpSession session = request.getSession(false);
		ResponseDto responseDto = new ResponseDto();
		if(session!=null){
			Object object = session.getAttribute("mastertable");
			MasterTable masterTable = (MasterTable) object;
			return sellerService.getAllSellerOrders(masterTable);
		}
		return null;
	}*/
	
	@RequestMapping(value="getSellerAllOrders")
	public ResponseDto getAllSellerOrders(){
		ResponseDto responseDto = new ResponseDto();
			MasterTable masterTable = new MasterTable();
			masterTable.setMasterTableId(4);
			List<TransactionDto> transactionDtos = new ArrayList<TransactionDto>();
			List<Transaction> transactions = sellerService.getAllSellerOrders(masterTable);
			for (Transaction transaction : transactions) {
				TransactionDto TransactionDto = mapper.transactionEntityToDto(transaction);
				transactionDtos.add(TransactionDto);
			}
			List<Object> objects = new ArrayList<Object>();
			objects.add(transactionDtos);
			responseDto = new ResponseDto(objects);
			return responseDto;
	}
	
	/*@RequestMapping(value="/getSellerAllSampleRequests")
	public List<SampleRequest> getSellerAllSampleRequests(@RequestParam String status , HttpServletRequest request){
		HttpSession session = request.getSession(false);
		ResponseDto responseDto = new ResponseDto();
		if(session!=null){
			Object object = session.getAttribute("mastertable");
			MasterTable masterTable = (MasterTable) object;
			return sellerService.getAllSampleRequest(masterTable,status);
		}
		return null;
	}*/
	
	@RequestMapping(value="/getSellerAllSampleRequests")
	public ResponseDto getSellerAllSampleRequests(@RequestParam String status){
		ResponseDto responseDto = new ResponseDto();
			MasterTable masterTable = new MasterTable();
			masterTable.setMasterTableId(4);
			List<SampleRequestDto> sampleRequestDtos = new ArrayList<SampleRequestDto>();
			List<SampleRequest> sampleRequests = sellerService.getAllSampleRequest(masterTable,status);
			for (SampleRequest sampleRequest : sampleRequests) {
				SampleRequestDto sampleRequestDto = mapper.sampleRequestToDto(sampleRequest);
				sampleRequestDtos.add(sampleRequestDto);
			}
			List<Object> objects = new ArrayList<Object>();
			objects.add(sampleRequestDtos);
			responseDto = new ResponseDto(objects);
			return responseDto;
	}
	
	@RequestMapping(value="/setSampleRequestStatus")
	public ResponseDto setSampleRequestStatus(@RequestParam String status,long sampleRequestId){
		ResponseDto responseDto = new ResponseDto();
		MasterTable masterTable = new MasterTable();
		masterTable.setMasterTableId(4);
		SampleRequestDto sampleRequestDto = new SampleRequestDto();
		try {
			SampleRequest sampleRequest = sellerService.setSampleRequestStatus(status,sampleRequestId,masterTable);
			sampleRequestDto = mapper.sampleRequestToDto(sampleRequest);
		} catch (SellerException e) {
			return new ResponseDto(e.getMessage());
		}
		List<Object> objects = new ArrayList<Object>();
		objects.add(sampleRequestDto);
		responseDto = new ResponseDto(objects);
		return responseDto;
	}
	
	@RequestMapping(value="/sendEmailToAdmin")
	public void sendEmailToAdmin(@RequestBody JSONObject jsonObject , HttpServletRequest request){
		HttpSession session = request.getSession(false);
		ResponseDto responseDto = new ResponseDto();
		if(session!=null){
			Object object = session.getAttribute("mastertable");
			MasterTable masterTable = (MasterTable) object;
			emailSender.sendEmail(jsonObject,masterTable);
		}
	}
	
	/*@RequestMapping(value="/updateSeller")
	public SellerDto updateSeller(@RequestBody MasterTable seller , HttpServletRequest request){
		HttpSession session = request.getSession(false);
		ResponseDto responseDto = new ResponseDto();
		if(session!=null){
			Object object = session.getAttribute("mastertable");
			MasterTable masterTable = (MasterTable) object;
			seller.setMasterTableId(masterTable.getMasterTableId());
			seller = userService.updateUser(seller);
			System.out.println("seller is "+seller);
			return mapper.sellerEntityToDto(seller);
		}
		return null;
	}*/
	
	@RequestMapping(value="/updateSeller")
	public SellerDto updateSeller(@RequestBody MasterTable seller){
		ResponseDto responseDto = new ResponseDto();
			MasterTable masterTable = new MasterTable();
			masterTable.setMasterTableId(4);
			seller.setMasterTableId(masterTable.getMasterTableId());
			seller = userService.updateUser(seller);
			System.out.println("seller is "+seller);
			return mapper.sellerEntityToDto(seller);
	}
}
