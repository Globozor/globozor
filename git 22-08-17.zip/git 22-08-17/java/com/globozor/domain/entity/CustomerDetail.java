package com.globozor.domain.entity;

import java.util.Arrays;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

@Table
@Entity
@JsonIdentityInfo(
		  generator = ObjectIdGenerators.PropertyGenerator.class, 
		  property = "customerId")
public class CustomerDetail {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column
	private long customerId;

	@ManyToOne
	//@JsonBackReference(value="company-customer")
	//@JsonIgnore
	@JoinColumn(name="companyProfileId")
	private CompanyProfile companyProfile;
	
	@Column
	private String customerName;
	
	@Column
	private String customerCountry;
	
	@Column
	private String annualTurnover;
	
	@Column
	private String[] productSupply;
	
	@Column
	private String transactionDocument;

	public long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(long customerId) {
		this.customerId = customerId;
	}

	//@JsonIgnore
	public CompanyProfile getCompanyProfile() {
		return companyProfile;
	}

	//@JsonProperty
	public void setCompanyProfile(CompanyProfile companyProfile) {
		this.companyProfile = companyProfile;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustomerCountry() {
		return customerCountry;
	}

	public void setCustomerCountry(String customerCountry) {
		this.customerCountry = customerCountry;
	}

	public String getAnnualTurnover() {
		return annualTurnover;
	}

	public void setAnnualTurnover(String annualTurnover) {
		this.annualTurnover = annualTurnover;
	}

	public String[] getProductSupply() {
		return productSupply;
	}

	public void setProductSupply(String[] productSupply) {
		this.productSupply = productSupply;
	}

	public String getTransactionDocument() {
		return transactionDocument;
	}

	public void setTransactionDocument(String transactionDocument) {
		this.transactionDocument = transactionDocument;
	}
	
}
