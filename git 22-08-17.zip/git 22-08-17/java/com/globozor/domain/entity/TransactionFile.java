package com.globozor.domain.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table
public class TransactionFile {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column
	private long transactionFileId;
	
	@ManyToOne
	@JoinColumn(name="transactionId")
	private Transaction transaction;
	
	@Column
	private String buyerFilepath;
	
	@Column
	private String sellerFilepath;
	
	@Column
	private String fileType;

	public long getTransactionFileId() {
		return transactionFileId;
	}

	public void setTransactionFileId(long transactionFileId) {
		this.transactionFileId = transactionFileId;
	}

	public Transaction getTransaction() {
		return transaction;
	}

	public void setTransaction(Transaction transaction) {
		this.transaction = transaction;
	}

	public String getBuyerFilepath() {
		return buyerFilepath;
	}

	public void setBuyerFilepath(String buyerFilepath) {
		this.buyerFilepath = buyerFilepath;
	}

	public String getSellerFilepath() {
		return sellerFilepath;
	}

	public void setSellerFilepath(String sellerFilepath) {
		this.sellerFilepath = sellerFilepath;
	}

	public String getFileType() {
		return fileType;
	}

	public void setFileType(String fileType) {
		this.fileType = fileType;
	}
	
}
