package com.globozor.domain.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@Table
public class StateLookup {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column
	private long stateLookupId;
	
	@Column
	private String stateName;
	
	@ManyToOne
	@JoinColumn(name="countryLookupId")
	@JsonIgnore
	private CountryLookup countryLookup;

	@OneToMany(mappedBy="stateLookup")
	//@JsonManagedReference(value="address-state")
	//@JsonIgnore
	private List<AddressDetails> addressDetails;
	
	public long getStateLookupId() {
		return stateLookupId;
	}

	public List<AddressDetails> getAddressDetails() {
		return addressDetails;
	}

	public void setAddressDetails(List<AddressDetails> addressDetails) {
		this.addressDetails = addressDetails;
	}

	public void setStateLookupId(long stateLookupId) {
		this.stateLookupId = stateLookupId;
	}

	public String getStateName() {
		return stateName;
	}

	public void setStateName(String stateName) {
		this.stateName = stateName;
	}

	public CountryLookup getCountryLookup() {
		return countryLookup;
	}

	public void setCountryLookup(CountryLookup countryLookup) {
		this.countryLookup = countryLookup;
	}
}
