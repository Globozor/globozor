package com.globozor.domain.entity;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

@Table
@Entity
@JsonIdentityInfo(generator=ObjectIdGenerators.PropertyGenerator.class , property="transactionId")
public class Transaction {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column
	private long transactionId;
	
	@ManyToOne
	@JoinColumn(name="sellerId")
	private MasterTable seller;
	
	@ManyToOne
	@JoinColumn(name="sellerProductId")
	private SellerProduct sellerProduct;
	
	@ManyToOne
	@JoinColumn(name="buyerId")
	private MasterTable buyer;
	
	@ManyToOne
	@JoinColumn(name="paymentMethodId")
	private PaymentMethod paymentMethod;
	
	@Column
	private BigDecimal unitPrice;
	
	@Column
	private BigDecimal quantity;
	
	@Column
	private BigDecimal tradeAmount;
	
	@Column(nullable=true)
	private BigDecimal commission;
	
	@Column
	private String vesselName;
	
	@Column
	private Date expectedShippingDate;
	
	@Column
	private Date expectedArrivalDate;
	
	@Column
	private Date requestTradeDate;
	
	@Column
	private Date approvedTradeDate;
	
	@Column
	private Date closeTradeDate;
	
	@Column
	private boolean isApprovedTradeDate;
	
	@OneToMany(mappedBy="transaction")
	@JsonIgnore
	private List<TransactionFile> transactionFiles;
	
	@OneToMany(mappedBy="transaction")
	private List<Dispute> disputes;
	
	@OneToOne(mappedBy="transaction")
	//@JsonBackReference
	private TransactionTracker transactionTracker;
	
	@OneToMany(mappedBy="transaction")
	private List<BuyerRating> buyerRatings;
	
	@OneToMany(mappedBy="transaction")
	private List<SellerRating> sellerRatings;
	
	public long getTransactionId() {
		return transactionId;
	}


	public void setTransactionId(long transactionId) {
		this.transactionId = transactionId;
	}

	public SellerProduct getSellerProduct() {
		return sellerProduct;
	}


	public void setSellerProduct(SellerProduct sellerProduct) {
		this.sellerProduct = sellerProduct;
	}

	public PaymentMethod getPaymentMethod() {
		return paymentMethod;
	}

	public void setPaymentMethod(PaymentMethod paymentMethod) {
		this.paymentMethod = paymentMethod;
	}

	public BigDecimal getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(BigDecimal unitPrice) {
		this.unitPrice = unitPrice;
	}

	public BigDecimal getQuantity() {
		return quantity;
	}

	public void setQuantity(BigDecimal quantity) {
		this.quantity = quantity;
	}

	public BigDecimal getTradeAmount() {
		return tradeAmount;
	}

	public void setTradeAmount(BigDecimal tradeAmount) {
		this.tradeAmount = tradeAmount;
	}

	public BigDecimal getCommission() {
		return commission;
	}

	public void setCommission(BigDecimal commission) {
		this.commission = commission;
	}

	public String getVesselName() {
		return vesselName;
	}

	public void setVesselName(String vesselName) {
		this.vesselName = vesselName;
	}

	public Date getExpectedShippingDate() {
		return expectedShippingDate;
	}

	public void setExpectedShippingDate(Date expectedShippingDate) {
		this.expectedShippingDate = expectedShippingDate;
	}

	public Date getExpectedArrivalDate() {
		return expectedArrivalDate;
	}

	public void setExpectedArrivalDate(Date expectedArrivalDate) {
		this.expectedArrivalDate = expectedArrivalDate;
	}

	public Date getRequestTradeDate() {
		return requestTradeDate;
	}

	public void setRequestTradeDate(Date requestTradeDate) {
		this.requestTradeDate = requestTradeDate;
	}

	public Date getApprovedTradeDate() {
		return approvedTradeDate;
	}

	public void setApprovedTradeDate(Date approvedTradeDate) {
		this.approvedTradeDate = approvedTradeDate;
	}

	public Date getCloseTradeDate() {
		return closeTradeDate;
	}

	public void setCloseTradeDate(Date closeTradeDate) {
		this.closeTradeDate = closeTradeDate;
	}

	public MasterTable getSeller() {
		return seller;
	}


	public void setSeller(MasterTable seller) {
		this.seller = seller;
	}


	public MasterTable getBuyer() {
		return buyer;
	}


	public void setBuyer(MasterTable buyer) {
		this.buyer = buyer;
	}


	public boolean isApprovedTradeDate() {
		return isApprovedTradeDate;
	}

	public void setApprovedTradeDates(boolean isApprovedTradeDate) {
		this.isApprovedTradeDate = isApprovedTradeDate;
	}

	public List<TransactionFile> getTransactionFiles() {
		return transactionFiles;
	}


	public void setTransactionFiles(List<TransactionFile> transactionFiles) {
		this.transactionFiles = transactionFiles;
	}


	public List<Dispute> getDisputes() {
		return disputes;
	}

	public void setDisputes(List<Dispute> disputes) {
		this.disputes = disputes;
	}

	public TransactionTracker getTransactionTracker() {
		return transactionTracker;
	}


	public void setTransactionTracker(TransactionTracker transactionTracker) {
		this.transactionTracker = transactionTracker;
	}

	public List<BuyerRating> getBuyerRatings() {
		return buyerRatings;
	}

	public void setBuyerRatings(List<BuyerRating> buyerRatings) {
		this.buyerRatings = buyerRatings;
	}

	public List<SellerRating> getSellerRatings() {
		return sellerRatings;
	}


	public void setSellerRatings(List<SellerRating> sellerRatings) {
		this.sellerRatings = sellerRatings;
	}


	@Override
	public String toString() {
		return "Transaction [transactionId=" + transactionId + ", seller="
				+ seller + ", buyer=" + buyer + "]";
	}
	
}
