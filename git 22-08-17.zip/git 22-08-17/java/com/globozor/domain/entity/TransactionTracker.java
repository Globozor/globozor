package com.globozor.domain.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@Table
public class TransactionTracker {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column
	private long transactionTrackerId;
	
	@OneToOne
	@JoinColumn(name="transactionId")
	//@JsonManagedReference
	private Transaction transaction;
	
	@Column
	private boolean contractGenerated;
	
	@Column
	private boolean uploadSignedContractBuyer;
	
	@Column
	private boolean uploadSignedContractSeller;
	
	@Column
	private boolean downloadSignedContractBuyer;
	
	@Column
	private boolean downloadSignedContractSeller;
	
	@Column
	private boolean uploadPaymentCertificate ;
	
	@Column
	private boolean downloadPaymentCertificate;
	
	@Column
	private boolean uploadShipment;
	
	@Column
	private boolean downloadShipment;

	public TransactionTracker() {
		// TODO Auto-generated constructor stub
	}
	
	public TransactionTracker(Transaction transaction,
			boolean contractGenerated, boolean uploadSignedContractBuyer,
			boolean uploadSignedContractSeller,
			boolean downloadSignedContractBuyer,
			boolean downloadSignedContractSeller,
			boolean uploadPaymentCertificate,
			boolean downloadPaymentCertificate, boolean uploadShipment,
			boolean downloadShipment) {
		this.transaction = transaction;
		this.contractGenerated = contractGenerated;
		this.uploadSignedContractBuyer = uploadSignedContractBuyer;
		this.uploadSignedContractSeller = uploadSignedContractSeller;
		this.downloadSignedContractBuyer = downloadSignedContractBuyer;
		this.downloadSignedContractSeller = downloadSignedContractSeller;
		this.uploadPaymentCertificate = uploadPaymentCertificate;
		this.downloadPaymentCertificate = downloadPaymentCertificate;
		this.uploadShipment = uploadShipment;
		this.downloadShipment = downloadShipment;
	}

	public long getTransactionTrackerId() {
		return transactionTrackerId;
	}

	public void setTransactionTrackerId(long transactionTrackerId) {
		this.transactionTrackerId = transactionTrackerId;
	}

	public Transaction getTransaction() {
		return transaction;
	}

	public void setTransaction(Transaction transaction) {
		this.transaction = transaction;
	}

	public boolean isContractGenerated() {
		return contractGenerated;
	}

	public void setContractGenerated(boolean contractGenerated) {
		this.contractGenerated = contractGenerated;
	}

	public boolean isUploadSignedContractBuyer() {
		return uploadSignedContractBuyer;
	}

	public void setUploadSignedContractBuyer(boolean uploadSignedContractBuyer) {
		this.uploadSignedContractBuyer = uploadSignedContractBuyer;
	}

	public boolean isUploadSignedContractSeller() {
		return uploadSignedContractSeller;
	}

	public void setUploadSignedContractSeller(boolean uploadSignedContractSeller) {
		this.uploadSignedContractSeller = uploadSignedContractSeller;
	}

	public boolean isDownloadSignedContractBuyer() {
		return downloadSignedContractBuyer;
	}

	public void setDownloadSignedContractBuyer(boolean downloadSignedContractBuyer) {
		this.downloadSignedContractBuyer = downloadSignedContractBuyer;
	}

	public boolean isDownloadSignedContractSeller() {
		return downloadSignedContractSeller;
	}

	public void setDownloadSignedContractSeller(boolean downloadSignedContractSeller) {
		this.downloadSignedContractSeller = downloadSignedContractSeller;
	}

	public boolean isUploadPaymentCertificate() {
		return uploadPaymentCertificate;
	}

	public void setUploadPaymentCertificate(boolean uploadPaymentCertificate) {
		this.uploadPaymentCertificate = uploadPaymentCertificate;
	}

	public boolean isDownloadPaymentCertificate() {
		return downloadPaymentCertificate;
	}

	public void setDownloadPaymentCertificate(boolean downloadPaymentCertificate) {
		this.downloadPaymentCertificate = downloadPaymentCertificate;
	}

	public boolean isUploadShipment() {
		return uploadShipment;
	}

	public void setUploadShipment(boolean uploadShipment) {
		this.uploadShipment = uploadShipment;
	}

	public boolean isDownloadShipment() {
		return downloadShipment;
	}

	public void setDownloadShipment(boolean downloadShipment) {
		this.downloadShipment = downloadShipment;
	}
	
}
