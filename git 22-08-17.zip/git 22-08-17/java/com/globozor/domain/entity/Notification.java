package com.globozor.domain.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table
public class Notification {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column
	private long notificationId;
	
	@ManyToOne
	@JoinColumn(name="masterTableId")
	//@JsonIgnore
	private MasterTable masterTable;
	
	@Column
	private String notificationType;
	
	@Column
	private String notificationDesc;

	@Column
	private boolean isActive;
	
	@Column
	private Date createdTime;
	
	public long getNotificationId() {
		return notificationId;
	}

	public void setNotificationId(long notificationId) {
		this.notificationId = notificationId;
	}

	public MasterTable getMasterTable() {
		return masterTable;
	}

	public void setMasterTable(MasterTable masterTable) {
		this.masterTable = masterTable;
	}

	public String getNotificationType() {
		return notificationType;
	}

	public void setNotificationType(String notificationType) {
		this.notificationType = notificationType;
	}

	public String getNotificationDesc() {
		return notificationDesc;
	}

	public void setNotificationDesc(String notificationDesc) {
		this.notificationDesc = notificationDesc;
	}

	public boolean isActive() {
		return isActive;
	}

	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}

	public Date getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}
	
}
