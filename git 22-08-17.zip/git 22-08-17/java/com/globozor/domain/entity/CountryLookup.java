package com.globozor.domain.entity;

import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@Table
public class CountryLookup {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column
	private long countryLookupId;
	
	@Column
	private String countryName;
	
	@Column
	private String icoField;
	
	@Column
	private String extension;
	
	@OneToMany(mappedBy="countryLookup")
	private Set<StateLookup> stateLookupList;

	@OneToMany(mappedBy="countryLookup")
	//@JsonManagedReference(value="address-country")
	//@JsonIgnore
	private List<AddressDetails> addressDetails;
	
	public List<AddressDetails> getAddressDetails() {
		return addressDetails;
	}

	public void setAddressDetails(List<AddressDetails> addressDetails) {
		this.addressDetails = addressDetails;
	}

	public String getExtension() {
		return extension;
	}

	public void setExtension(String extension) {
		this.extension = extension;
	}

	public long getCountryLookupId() {
		return countryLookupId;
	}

	public void setCountryLookupId(long countryLookupId) {
		this.countryLookupId = countryLookupId;
	}

	public String getCountryName() {
		return countryName;
	}

	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}

	public String getIcoField() {
		return icoField;
	}

	public void setIcoField(String icoField) {
		this.icoField = icoField;
	}

	public Set<StateLookup> getStateLookupList() {
		return stateLookupList;
	}

	public void setStateLookupList(Set<StateLookup> stateLookupList) {
		this.stateLookupList = stateLookupList;
	}

}
