package com.globozor.domain.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@Table
public class Favourite {

	@Id
	@GeneratedValue
	@Column
	private long favouriteId;
	
	@Column
	private boolean isFavourite;
	
	@ManyToOne
	@JoinColumn(name="sellerProductId")
	//@JsonBackReference(value="favourite-product")
	private SellerProduct sellerProduct;
	
	@ManyToOne
	@JoinColumn(name="buyerId")
	//@JsonBackReference(value="favourite-buyer")
	private MasterTable buyer;

	public long getFavouriteId() {
		return favouriteId;
	}

	public void setFavouriteId(long favouriteId) {
		this.favouriteId = favouriteId;
	}

	public boolean isFavourite() {
		return isFavourite;
	}

	public void setFavourite(boolean isFavourite) {
		this.isFavourite = isFavourite;
	}

	public SellerProduct getSellerProduct() {
		return sellerProduct;
	}

	public void setSellerProduct(SellerProduct sellerProduct) {
		this.sellerProduct = sellerProduct;
	}

	public MasterTable getBuyer() {
		return buyer;
	}

	public void setBuyer(MasterTable buyer) {
		this.buyer = buyer;
	}
	
}
