package com.globozor.domain.entity;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

@Entity
@Table
@JsonIdentityInfo(
		generator= ObjectIdGenerators.PropertyGenerator.class,
		property="sellerEnquiryResponseId")
public class SellerEnquiryResponse {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column
	private long sellerEnquiryResponseId;
	
	@ManyToOne
	@JoinColumn(name="enquiryId")
	//@JsonManagedReference(value="enquiry-response")
	private Enquiry enquiry;
	
	@ManyToOne
	@JoinColumn(name="buyerId")
	//@JsonManagedReference(value="response-buyer")
	private MasterTable buyer;
	
	@ManyToOne
	@JoinColumn(name="sellerId")
	//@JsonManagedReference(value="response-seller")
	private MasterTable seller;
	
	@ManyToOne
	@JoinColumn(name="sellerProductId")
	private SellerProduct sellerProduct;
	
	@OneToMany(mappedBy="sellerEnquiryResponse")
	//@JsonIgnore
	private List<BuyerEnquiryResponse> buyerEnquiryResponse;
	
	@OneToMany(mappedBy="sellerEnquiryResponse")
	private List<SampleRequest> sampleRequests;
	
	@Column
	private long quantity;
	
	@Column
	private String unit;
	
	@Column
	private String enquiryDescription;
	
	@Column
	private String status;
	
	@Column
	private String unitPrice;

	public long getSellerEnquiryResponseId() {
		return sellerEnquiryResponseId;
	}

	public void setSellerEnquiryResponseId(long sellerEnquiryResponseId) {
		this.sellerEnquiryResponseId = sellerEnquiryResponseId;
	}

	public Enquiry getEnquiry() {
		return enquiry;
	}

	public void setEnquiry(Enquiry enquiry) {
		this.enquiry = enquiry;
	}

	public MasterTable getBuyer() {
		return buyer;
	}

	public void setBuyer(MasterTable buyer) {
		this.buyer = buyer;
	}

	public MasterTable getSeller() {
		return seller;
	}

	public void setSeller(MasterTable seller) {
		this.seller = seller;
	}

	public SellerProduct getSellerProduct() {
		return sellerProduct;
	}

	public void setSellerProduct(SellerProduct sellerProduct) {
		this.sellerProduct = sellerProduct;
	}

	public long getQuantity() {
		return quantity;
	}

	public void setQuantity(long quantity) {
		this.quantity = quantity;
	}

	public String getUnit() {
		return unit;
	}

	public void setUnit(String unit) {
		this.unit = unit;
	}

	public String getEnquiryDescription() {
		return enquiryDescription;
	}

	public void setEnquiryDescription(String enquiryDescription) {
		this.enquiryDescription = enquiryDescription;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(String unitPrice) {
		this.unitPrice = unitPrice;
	}

	public List<BuyerEnquiryResponse> getBuyerEnquiryResponse() {
		return buyerEnquiryResponse;
	}

	public void setBuyerEnquiryResponse(
			List<BuyerEnquiryResponse> buyerEnquiryResponse) {
		this.buyerEnquiryResponse = buyerEnquiryResponse;
	}

	public List<SampleRequest> getSampleRequests() {
		return sampleRequests;
	}

	public void setSampleRequests(List<SampleRequest> sampleRequests) {
		this.sampleRequests = sampleRequests;
	}
	
}
