package com.globozor.domain.entity;

import java.util.Arrays;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

@Table
@Entity
@JsonIdentityInfo(
		  generator = ObjectIdGenerators.PropertyGenerator.class, 
		  property = "tradeShowId")
public class TradeShow {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column
	private long tradeShowId;
	
	@ManyToOne
	@JoinColumn(name="companyProfileId")
	//@JsonBackReference(value="company-tradeshow")
	//@JsonIgnore
	private CompanyProfile companyProfile;
	
	@Column
	private String tradeShowName;
	
	@Column
	private Date tradeShowDate;
	
	@Column
	private String tradeShowHost;

	@Column
	private String tradeShowDescription;

	@Column
	private String[] tradeShowFilepath;

	public long getTradeShowId() {
		return tradeShowId;
	}

	public void setTradeShowId(long tradeShowId) {
		this.tradeShowId = tradeShowId;
	}

	//@JsonIgnore
	public CompanyProfile getCompanyProfile() {
		return companyProfile;
	}
	
	//@JsonProperty
	public void setCompanyProfile(CompanyProfile companyProfile) {
		this.companyProfile = companyProfile;
	}

	public String getTradeShowName() {
		return tradeShowName;
	}

	public void setTradeShowName(String tradeShowName) {
		this.tradeShowName = tradeShowName;
	}

	public Date getTradeShowDate() {
		return tradeShowDate;
	}

	public void setTradeShowDate(Date tradeShowDate) {
		this.tradeShowDate = tradeShowDate;
	}

	public String getTradeShowHost() {
		return tradeShowHost;
	}

	public void setTradeShowHost(String tradeShowHost) {
		this.tradeShowHost = tradeShowHost;
	}

	public String getTradeShowDescription() {
		return tradeShowDescription;
	}

	public void setTradeShowDescription(String tradeShowDescription) {
		this.tradeShowDescription = tradeShowDescription;
	}

	public String[] getTradeShowFilepath() {
		return tradeShowFilepath;
	}

	public void setTradeShowFilepath(String[] tradeShowFilepath) {
		this.tradeShowFilepath = tradeShowFilepath;
	}
}
