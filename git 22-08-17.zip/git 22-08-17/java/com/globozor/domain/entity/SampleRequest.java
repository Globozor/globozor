package com.globozor.domain.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@Table
public class SampleRequest {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column
	private long sampleRequestId;
	
	@ManyToOne
	@JoinColumn(name="sellerEnquiryResponseId")
	//@JsonManagedReference
	private SellerEnquiryResponse sellerEnquiryResponse;
	
	@Column
	private String quantity;
	
	@Column
	private String unitPrice;
	
	@Column
	private String commission;
	
	@Column
	private String totalAmount;
	
	@Column
	private Date sampleRequestDate;
	
	@Column
	private String status;

	public long getSampleRequestId() {
		return sampleRequestId;
	}

	public void setSampleRequestId(long sampleRequestId) {
		this.sampleRequestId = sampleRequestId;
	}

	public SellerEnquiryResponse getSellerEnquiryResponse() {
		return sellerEnquiryResponse;
	}

	public void setSellerEnquiryResponse(SellerEnquiryResponse sellerEnquiryResponse) {
		this.sellerEnquiryResponse = sellerEnquiryResponse;
	}

	public String getQuantity() {
		return quantity;
	}

	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

	public String getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(String unitPrice) {
		this.unitPrice = unitPrice;
	}

	public String getCommission() {
		return commission;
	}

	public void setCommission(String commission) {
		this.commission = commission;
	}

	public String getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(String totalAmount) {
		this.totalAmount = totalAmount;
	}

	public Date getSampleRequestDate() {
		return sampleRequestDate;
	}

	public void setSampleRequestDate(Date sampleRequestDate) {
		this.sampleRequestDate = sampleRequestDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
}
