package com.globozor.domain.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@Table
public class SellerRating {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long sellerRatingId;
	
	@ManyToOne
	@JoinColumn(name="transactionId")
	//@JsonManagedReference
	private Transaction transaction;

	@Column
	private double rating;
	
	@Column
	private String description;

	public long getSellerRatingId() {
		return sellerRatingId;
	}

	public void setSellerRatingId(long sellerRatingId) {
		this.sellerRatingId = sellerRatingId;
	}

	public Transaction getTransaction() {
		return transaction;
	}

	public void setTransaction(Transaction transaction) {
		this.transaction = transaction;
	}

	public double getRating() {
		return rating;
	}

	public void setRating(double rating) {
		this.rating = rating;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

}
