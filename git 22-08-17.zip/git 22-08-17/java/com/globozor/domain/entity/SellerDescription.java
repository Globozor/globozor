package com.globozor.domain.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

@Table(name="sellerDescription")
@Entity(name="SellerDescription")
@JsonIdentityInfo(
		  generator = ObjectIdGenerators.PropertyGenerator.class, 
		  property = "sellerDescriptionId")
public class SellerDescription {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long sellerDescriptionId;
	
	@Column
	private String descriptionAboutCompany;

	@Column
	private int establishment;
	
	@Column
	private String maximumCapacity;

	@Column
	private String turnover;

	@Column
	private String port;

	@Column
	private long numberOfEmployees;
	
	@Column
	private Date membershipStartDate;

	@ManyToOne
	@JoinColumn(name="membershipTypeId")
	private MembershipType membershipType;
	
	@OneToOne
	@JoinColumn(name="masterTableId")
	@JsonBackReference(value="seller-description")
	private MasterTable masterTable;

	public long getSellerDescriptionId() {
		return sellerDescriptionId;
	}

	public void setSellerDescriptionId(long sellerDescriptionId) {
		this.sellerDescriptionId = sellerDescriptionId;
	}

	public String getDescriptionAboutCompany() {
		return descriptionAboutCompany;
	}

	public void setDescriptionAboutCompany(String descriptionAboutCompany) {
		this.descriptionAboutCompany = descriptionAboutCompany;
	}

	public int getEstablishment() {
		return establishment;
	}

	public void setEstablishment(int establishment) {
		this.establishment = establishment;
	}

	public String getMaximumCapacity() {
		return maximumCapacity;
	}

	public void setMaximumCapacity(String maximumCapacity) {
		this.maximumCapacity = maximumCapacity;
	}

	public String getTurnover() {
		return turnover;
	}

	public void setTurnover(String turnover) {
		this.turnover = turnover;
	}

	public String getPort() {
		return port;
	}

	public void setPort(String port) {
		this.port = port;
	}

	public long getNumberOfEmployees() {
		return numberOfEmployees;
	}

	public void setNumberOfEmployees(long numberOfEmployees) {
		this.numberOfEmployees = numberOfEmployees;
	}

	public MembershipType getMembershipType() {
		return membershipType;
	}

	public void setMembershipType(MembershipType membershipType) {
		this.membershipType = membershipType;
	}

	public MasterTable getMasterTable() {
		return masterTable;
	}

	public void setMasterTable(MasterTable masterTable) {
		this.masterTable = masterTable;
	}

	public Date getMembershipStartDate() {
		return membershipStartDate;
	}

	public void setMembershipStartDate(Date membershipStartDate) {
		this.membershipStartDate = membershipStartDate;
	}
}