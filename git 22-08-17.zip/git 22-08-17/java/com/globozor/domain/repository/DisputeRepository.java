package com.globozor.domain.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.globozor.domain.entity.Dispute;

public interface DisputeRepository extends JpaRepository<Dispute, Long>{

	@Query("select d from Dispute d where d.transaction.seller.masterTableId=?1")
	public List<Dispute> findAllSellerById(long masterTableId);

	@Query("select d from Dispute d where d.transaction.buyer.masterTableId=?1")
	public List<Dispute> findAllBuyerById(long masterTableId);

	@Query("select d from Dispute d where d.raisedBy.masterTableId=?1")
	public List<Dispute> findAllRaisedBy(long masterTableId);
	
	/*@Query("select d from Dispute d")
	public List<Dispute> findAllRaisedBy();*/
	
	@Query("select d from Dispute d where d.raisedFor.masterTableId=?1")
	public List<Dispute> findAllRecievedBy(long masterTableId);
}
