package com.globozor.domain.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.globozor.domain.entity.BuyerDescription;

public interface BuyerDescriptionRepository extends JpaRepository<BuyerDescription, Long>{

}
