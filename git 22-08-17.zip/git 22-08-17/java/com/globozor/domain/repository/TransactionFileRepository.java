package com.globozor.domain.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.globozor.domain.entity.TransactionFile;

public interface TransactionFileRepository extends JpaRepository<TransactionFile, Long>{

	public TransactionFile findByFileType(String fileType);

	@Query("select t from TransactionFile t where t.transaction.transactionId=?1 and t.fileType=?2")
	public List<TransactionFile> findByFileTypeAndTransactionId(long transactionId , String fileType);

}
