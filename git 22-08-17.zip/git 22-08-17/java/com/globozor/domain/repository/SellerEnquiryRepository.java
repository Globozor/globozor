package com.globozor.domain.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.globozor.domain.entity.SellerEnquiry;
import com.globozor.domain.entity.SellerEnquiryPk;

public interface SellerEnquiryRepository extends JpaRepository<SellerEnquiry, SellerEnquiryPk>{

	@Query("select s from SellerEnquiry s where s.isActive=?1 and s.id.seller.masterTableId=?2")
	public List<SellerEnquiry> findByIsActive(boolean b, long masterTableId);

	@Query("select s from SellerEnquiry s where s.id.enquiry.enquiryId=?1")
	public SellerEnquiry findByEnquiry(long enquiryId);
	
}
