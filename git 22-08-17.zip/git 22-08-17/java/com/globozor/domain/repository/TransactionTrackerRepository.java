package com.globozor.domain.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.globozor.domain.entity.TransactionTracker;

public interface TransactionTrackerRepository extends JpaRepository<TransactionTracker, Long>{

	@Query("select t from TransactionTracker t where t.transaction.transactionId=?1")
	public TransactionTracker findByTransaction(long transactionId);

}
