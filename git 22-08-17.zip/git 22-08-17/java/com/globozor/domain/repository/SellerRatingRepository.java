package com.globozor.domain.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.globozor.domain.entity.SellerRating;

public interface SellerRatingRepository extends JpaRepository<SellerRating, Long>{

	@Query("select s from SellerRating s where s.transaction.seller.masterTableId=?1")
	public List<SellerRating> findAllById(long masterTableId);

}
