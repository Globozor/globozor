package com.globozor.domain.repository;

import java.util.List;
import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.globozor.domain.entity.Image;

public interface ImageRepository extends JpaRepository<Image, Long>{

	@Query("select i from Image i where i.masterTable.masterTableId=?1")
	public Set<Image> findImagesByMasterTableId(long masterTableId);
}
