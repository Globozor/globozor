package com.globozor.domain.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.globozor.domain.entity.BuyerEnquiryResponse;
import com.globozor.domain.entity.MasterTable;

public interface BuyerEnquiryResponseRepository extends JpaRepository<BuyerEnquiryResponse, Long>{

	@Query("select b from BuyerEnquiryResponse b where b.sellerEnquiryResponse.seller.masterTableId=?2 and b.status=?1")
	public List<BuyerEnquiryResponse> findByTypeResponse(String type,
			long masterTableId);

}
