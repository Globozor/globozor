package com.globozor.domain.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.globozor.domain.entity.SellerDescription;

public interface SellerDescriptionRepository extends JpaRepository<SellerDescription, Long> {

	@Query("select s from SellerDescription s where s.masterTable.masterTableId=?1")
	public SellerDescription findBySellerId(long masterTableId);

}
