package com.globozor.domain.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.globozor.domain.entity.AddressDetails;

public interface AddressDetailsRepository extends JpaRepository<AddressDetails, Long>{

	@Query("select a from AddressDetails a where a.masterTable.masterTableId=?1")
	public List<AddressDetails> findByUserId(long masterTableId);

}
