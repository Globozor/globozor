package com.globozor.domain.services;

import com.globozor.domain.dtos.BuyerEnquiryResponseDto;
import com.globozor.domain.dtos.BuyerRatingDto;
import com.globozor.domain.dtos.CompanyProfileDto;
import com.globozor.domain.dtos.CustomerDetailDto;
import com.globozor.domain.dtos.DisputeDto;
import com.globozor.domain.dtos.EnquiryDto;
import com.globozor.domain.dtos.FavouriteDto;
import com.globozor.domain.dtos.MasterTableDto;
import com.globozor.domain.dtos.SampleRequestDto;
import com.globozor.domain.dtos.SellerDescriptionDto;
import com.globozor.domain.dtos.SellerDto;
import com.globozor.domain.dtos.SellerEnquiryDto;
import com.globozor.domain.dtos.SellerEnquiryResponseDto;
import com.globozor.domain.dtos.SellerProductDto;
import com.globozor.domain.dtos.SellerRatingDto;
import com.globozor.domain.dtos.TradeShowDto;
import com.globozor.domain.dtos.TransactionDto;
import com.globozor.domain.dtos.TransactionFileDto;
import com.globozor.domain.dtos.TransactionTrackerDto;
import com.globozor.domain.entity.BuyerEnquiryResponse;
import com.globozor.domain.entity.BuyerRating;
import com.globozor.domain.entity.CompanyProfile;
import com.globozor.domain.entity.CustomerDetail;
import com.globozor.domain.entity.Dispute;
import com.globozor.domain.entity.Enquiry;
import com.globozor.domain.entity.Favourite;
import com.globozor.domain.entity.MasterTable;
import com.globozor.domain.entity.SampleRequest;
import com.globozor.domain.entity.SellerDescription;
import com.globozor.domain.entity.SellerEnquiry;
import com.globozor.domain.entity.SellerEnquiryResponse;
import com.globozor.domain.entity.SellerProduct;
import com.globozor.domain.entity.SellerRating;
import com.globozor.domain.entity.TradeShow;
import com.globozor.domain.entity.Transaction;
import com.globozor.domain.entity.TransactionFile;
import com.globozor.domain.entity.TransactionTracker;

public interface EntityDtoMapper {

	public SellerDto sellerEntityToDto(MasterTable masterTable);
	//public MasterTable masterTableDtoToEntity(MasterTableDto masterTableDto);
	public MasterTableDto masterTableEntityToDto(MasterTable masterTable);
	public SellerProductDto sellerProductToDto(SellerProduct sellerProduct);
	public SellerEnquiryDto sellerEnquiryToDto(SellerEnquiry sellerEnquiry);
	public CompanyProfileDto companyProfileToDto(CompanyProfile companyProfile);
	public SellerDescriptionDto sellerDescEntityToDto(
			SellerDescription sellerDescription);
	public TradeShowDto tradeShowEntityToDto(TradeShow tradeShow);
	public CustomerDetailDto customerEntityToDto(CustomerDetail customerDetail);
	public SellerEnquiryResponseDto sellerEnqResponseToDto(
			SellerEnquiryResponse sellerEnquiryResponse);
	public DisputeDto disputeEntityToDto(Dispute dispute,boolean isSeller);
	public BuyerRatingDto buyerRatingToDto(BuyerRating buyerRating);
	public SellerRatingDto sellerRatingToDto(SellerRating sellerRating);
	public TransactionDto transactionEntityToDto(
			Transaction transaction);
	public SampleRequestDto sampleRequestToDto(SampleRequest sampleRequest);
	public FavouriteDto favouriteEntityToDto(Favourite favourite);
	public TransactionTrackerDto transactionTrackerToDto(
			TransactionTracker transactionTracker);
	public EnquiryDto enquiryEntityToDto(Enquiry enquiry);
	public BuyerEnquiryResponseDto buyerEnquiryResponseToDto(
			BuyerEnquiryResponse buyerEnquiryResponse);
	public TransactionFileDto transactionFileToDto(
			TransactionFile transactionFile2);
}
