package com.globozor.domain.services;

import java.util.List;

import org.json.simple.JSONArray;

import com.globozor.domain.dtos.CompanyDto;
import com.globozor.domain.dtos.CompanyProfileDto;
import com.globozor.domain.dtos.UserInfo;
import com.globozor.domain.entity.BuyerEnquiryResponse;
import com.globozor.domain.entity.BuyerRating;
import com.globozor.domain.entity.CompanyProfile;
import com.globozor.domain.entity.CustomerDetail;
import com.globozor.domain.entity.Dispute;
import com.globozor.domain.entity.Feedback;
import com.globozor.domain.entity.MasterTable;
import com.globozor.domain.entity.Notification;
import com.globozor.domain.entity.SampleRequest;
import com.globozor.domain.entity.SellerDescription;
import com.globozor.domain.entity.SellerEnquiry;
import com.globozor.domain.entity.SellerEnquiryResponse;
import com.globozor.domain.entity.SellerProduct;
import com.globozor.domain.entity.SellerRating;
import com.globozor.domain.entity.TradeShow;
import com.globozor.domain.entity.Transaction;
import com.globozor.domain.exceptions.SellerException;

public interface SellerService {

	public SellerEnquiryResponse responseEnquiry(
			SellerEnquiryResponse sellerEnquiryResponse, String response);

	public List<Notification> getNotifications(MasterTable masterTable);

	public SellerProduct addSellerProduct(SellerProduct sellerProduct, MasterTable masterTable);

	public String removeSellerProduct(long sellerProductId, MasterTable masterTable) throws SellerException;

	public List<SellerProduct> getSellerProduct(MasterTable masterTable, String status);

	public List<SellerEnquiry> getSellerEnquiry(MasterTable masterTable);

	public List<SellerProduct> getSellerProductShowCase(MasterTable masterTable);

	public SellerProduct setSellerProductPriority(long sellerProductId, int priority, MasterTable masterTable) throws SellerException;

	public SellerEnquiry rejectEnquiry(long enquiryId);

	public CompanyProfile saveCompanyProfile(CompanyProfile companyProfile);

	public SellerDescription getSellerDescription(MasterTable masterTable);

	public TradeShow saveTradeShow(TradeShow tradeShow);

	public CustomerDetail saveCustomerDetail(CustomerDetail customerDetail);

	public Dispute createDispute(Dispute dispute, MasterTable masterTable) throws SellerException;

	public List<Dispute> getAllDisputes(MasterTable masterTable, String type) throws SellerException;

	//public Feedback createFeedback(Feedback feedback);

	//public List<Feedback> getAllFeedbacks(MasterTable masterTable);

	public BuyerRating rateBuyer(BuyerRating buyerRating, MasterTable masterTable) throws SellerException;

	public List<SellerRating> getAllSellerRating(MasterTable masterTable);

	public List<Transaction> getAllSellerOrders(MasterTable masterTable);

	public List<SampleRequest> getAllSampleRequest(MasterTable masterTable,
			String status);

	public SampleRequest setSampleRequestStatus(String status,
			long sampleRequestId, MasterTable masterTable) throws SellerException;

	public CompanyProfile saveCompanyProfil(CompanyDto companyProfileDto, MasterTable masterTable) throws SellerException;

	public List<BuyerEnquiryResponse> getBuyerResponses(MasterTable seller,String type);

	public MasterTable saveCompanyProfilePage2(UserInfo userInfo,
			MasterTable masterTable);

}
