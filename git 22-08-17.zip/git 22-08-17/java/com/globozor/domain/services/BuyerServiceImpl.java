package com.globozor.domain.services;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.globozor.domain.dtos.ResponseDto;
import com.globozor.domain.entity.BuyerEnquiryResponse;
import com.globozor.domain.entity.BuyerRating;
import com.globozor.domain.entity.CompanyProfile;
import com.globozor.domain.entity.CustomerDetail;
import com.globozor.domain.entity.Dispute;
import com.globozor.domain.entity.Enquiry;
import com.globozor.domain.entity.Favourite;
import com.globozor.domain.entity.MasterTable;
import com.globozor.domain.entity.Notification;
import com.globozor.domain.entity.PaymentMethod;
import com.globozor.domain.entity.SampleRequest;
import com.globozor.domain.entity.SellerEnquiryResponse;
import com.globozor.domain.entity.SellerProduct;
import com.globozor.domain.entity.SellerRating;
import com.globozor.domain.entity.TradeShow;
import com.globozor.domain.entity.Transaction;
import com.globozor.domain.exceptions.BuyerException;
import com.globozor.domain.exceptions.SellerException;
import com.globozor.domain.repository.BuyerEnquiryResponseRepository;
import com.globozor.domain.repository.BuyerRatingRepository;
import com.globozor.domain.repository.CompanyProfileRespository;
import com.globozor.domain.repository.CustomerDetailRepository;
import com.globozor.domain.repository.DisputeRepository;
import com.globozor.domain.repository.EnquiryRepository;
import com.globozor.domain.repository.MasterTableRepository;
import com.globozor.domain.repository.NotificationRepository;
import com.globozor.domain.repository.SampleRequestRepository;
import com.globozor.domain.repository.SellerEnquiryResponseRepository;
import com.globozor.domain.repository.SellerRatingRepository;
import com.globozor.domain.repository.TradeShowRepository;
import com.globozor.domain.repository.TransactionRepository;

@Service
@Transactional
public class BuyerServiceImpl implements BuyerService {

	@Autowired
	MasterTableRepository masterTableRepository;
	
	@Autowired
	TransactionRepository transactionRepository;
	
	@Autowired
	SellerRatingRepository sellerRatingRepository;
	
	@Autowired
	BuyerRatingRepository buyerRatingRepository;
	
	@Autowired
	DisputeRepository disputeRepository;
	
	@Autowired
	SampleRequestRepository sampleRequestRepository;
	
	@Autowired
	EnquiryRepository enquiryRepository;
	
	@Autowired
	SellerEnquiryResponseRepository sellerEnquiryResponseRepository;
	
	@Autowired
	CompanyProfileRespository companyProfileRespository;
	
	@Autowired
	TradeShowRepository tradeShowRepository;
	
	@Autowired
	CustomerDetailRepository customerDetailRepository;
	
	@Autowired
	FavouriteRepository favouriteRepository;
	
	@Autowired
	BuyerEnquiryResponseRepository buyerEnquiryResponseRepository;
	
	@Autowired
	NotificationRepository notificationRepository;
	
	private static final Logger logger = LoggerFactory.getLogger(BuyerServiceImpl.class);
	
	@Override
	public List<Transaction> getAllOrders(MasterTable masterTable) {
		return transactionRepository.getAllBuyerOrder(masterTable.getMasterTableId());
	}

	@Override
	public SellerRating rateSeller(SellerRating sellerRating,MasterTable masterTable) throws BuyerException {
		Transaction transaction = transactionRepository.findOne(sellerRating.getTransaction().getTransactionId());
		if(transaction!=null&&transaction.getBuyer().getMasterTableId()==masterTable.getMasterTableId()){
			return sellerRatingRepository.save(sellerRating);
		}else if(transaction==null){
			throw new BuyerException("You have not transacted with this Buyer");
		}else{
			throw new BuyerException("You have not transacted with this Buyer");
		}
	}

	@Override
	public List<BuyerRating> getAllBuyerRating(MasterTable masterTable) {
		return buyerRatingRepository.findAllById(masterTable.getMasterTableId());
	}

	@Override
	public Dispute createDispute(Dispute dispute,MasterTable masterTable) throws BuyerException {
		Transaction transaction = transactionRepository.findOne(dispute.getTransaction().getTransactionId());
		System.out.println(transaction==null);
		if(transaction!=null&&transaction.getBuyer().getMasterTableId()==masterTable.getMasterTableId()){
			dispute.setRaisedBy(transaction.getBuyer());
			dispute.setRaisedFor(transaction.getSeller());
			System.out.println("transaction "+transaction);
			dispute= disputeRepository.save(dispute);
			return dispute;
		}
		else if(transaction==null){
			throw new BuyerException("You can not raise a dispute for this transaction");
		}
		else{
			throw new BuyerException("You can not raise a dispute for this transaction");
		}
	}

	@Override
	public List<Dispute> getAllDisputes(MasterTable masterTable,String type) throws BuyerException {
		if(type.equals("raised")){
			return disputeRepository.findAllRaisedBy(masterTable.getMasterTableId());
		}else if(type.equals("received")){
			return disputeRepository.findAllRecievedBy(masterTable.getMasterTableId());
		}else{
			throw new BuyerException("No dispute found");
		}
	}

	@Override
	public List<SampleRequest> getAllSampleRequest(MasterTable masterTable,
			String status) {
		return sampleRequestRepository.findSampleByStatusBuyer(masterTable.getMasterTableId(),status);
	}

	@Override
	public List<Enquiry> getBuyerAllEnquiries(MasterTable masterTable) {
		return enquiryRepository.findAllByBuyerId(masterTable.getMasterTableId());
	}

	@Override
	public List<SellerEnquiryResponse> getSellerEnquiryResponse(String type,
			MasterTable masterTable) {
		if(type.equals("all")){
			return sellerEnquiryResponseRepository.findAllResponse(masterTable.getMasterTableId());
		}else if(type.equals("negotiated")){
			return sellerEnquiryResponseRepository.findAllResponseWithStatus(type,masterTable.getMasterTableId());
		}else{
			return null;
		}
	}

	@Override
	public CompanyProfile saveCompanyProfile(CompanyProfile companyProfile) {
		try {
			CompanyProfile companyProfile2 = 
					companyProfileRespository.findUnique(companyProfile.getMasterTable().getMasterTableId());
			if(companyProfile2 == null){
				List<TradeShow> tradeShows = companyProfile.getTradeShow();
				List<CustomerDetail> customerDetails = companyProfile.getCustomerDetails();
				List<TradeShow> tradeShows2 = new ArrayList<TradeShow>();
				List<CustomerDetail> customerDetails2 = new ArrayList<CustomerDetail>();
				companyProfile.setTradeShow(null);
				companyProfile.setCustomerDetails(null);
				companyProfile = companyProfileRespository.save(companyProfile);
				if(tradeShows!=null){
					for (TradeShow tradeShow : tradeShows) {
						tradeShow.setCompanyProfile(companyProfile);
						tradeShow = tradeShowRepository.save(tradeShow);
						tradeShows2.add(tradeShow);
					}
				}
				if(customerDetails!=null){
					for (CustomerDetail customerDetail : customerDetails) {
						customerDetail.setCompanyProfile(companyProfile);
						customerDetail = customerDetailRepository.save(customerDetail);
						customerDetails2.add(customerDetail);
					}
				}
				companyProfile.setTradeShow(tradeShows2);
				companyProfile.setCustomerDetails(customerDetails2);
				return companyProfile;
			}else{
				companyProfile.setCompanyProfileId(companyProfile2.getCompanyProfileId());
				return companyProfileRespository.save(companyProfile);
			}
		} catch (Exception e) {
			logger.debug(e.getMessage());
		}
		return null;
	}

	@Override
	public Favourite addFavourite(MasterTable masterTable, long id) {
		Favourite favourite = new Favourite();
		SellerProduct sellerProduct = new SellerProduct();
		sellerProduct.setSellerProductId(id);
		favourite.setSellerProduct(sellerProduct);
		favourite.setBuyer(masterTable);
		return favouriteRepository.save(favourite);
	}

	@Override
	public List<Favourite> getAllFavourites(MasterTable masterTable) {
		return favouriteRepository.getAllFavourites(masterTable.getMasterTableId());
	}

	@Override
	public BuyerEnquiryResponse responseSellerEnquiryResponse(String response,
			BuyerEnquiryResponse buyerEnquiryResponse) {
		buyerEnquiryResponse.setStatus(response);
		buyerEnquiryResponse = buyerEnquiryResponseRepository.save(buyerEnquiryResponse);
		
		Set<Notification> notifications = new HashSet<Notification>();
		if(buyerEnquiryResponse.getSellerEnquiryResponse()!=null){
			if(buyerEnquiryResponse.getSellerEnquiryResponse().getSeller()!=null){
				if(buyerEnquiryResponse.getSellerEnquiryResponse().getSeller().getNotifications()!=null){
					notifications = buyerEnquiryResponse.getSellerEnquiryResponse().getSeller().getNotifications();
				}
			}
		}
		Notification notification = new Notification();
		notification.setMasterTable(buyerEnquiryResponse.getSellerEnquiryResponse().getSeller());
		//notification.setNotificationDesc("New response for your enquiry with id "+buyerEnquiryResponse.getSellerEnquiryResponse().getSellerEnquiryResponseId()+" from "+buyerEnquiryResponse.getEnquiry().getBuyer().getUserName()+" as "+response);
		notification.setNotificationType("Enquiry response");
		notification.setActive(true);
		notification.setCreatedTime(new Date());
		notification = notificationRepository.save(notification);
		//notifications.add(notification);
		//buyerEnquiryResponse.getSellerEnquiryResponse().getBuyer().setNotifications(notifications);
		return buyerEnquiryResponse;
	}

	@Override
	public Set<PaymentMethod> getPaymentMethods(MasterTable masterTable) {
		masterTable=masterTableRepository.findOne(masterTable.getMasterTableId());
		if(masterTable.getPaymentMethod()!=null){
			Set<PaymentMethod> paymentMethods = masterTable.getPaymentMethod();
			return paymentMethods;
		}
		return new HashSet<PaymentMethod>();
	}

	@Override
	public CompanyProfile getSellerCompanyProfile(MasterTable masterTable) {
		return companyProfileRespository.findUnique(masterTable.getMasterTableId());
	}
}
