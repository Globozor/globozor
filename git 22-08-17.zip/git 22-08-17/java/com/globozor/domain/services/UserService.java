package com.globozor.domain.services;

import java.util.List;
import java.util.Set;

import com.globozor.domain.entity.Currency;
import com.globozor.domain.entity.Enquiry;
import com.globozor.domain.entity.Favourite;
import com.globozor.domain.entity.Language;
import com.globozor.domain.entity.MasterTable;
import com.globozor.domain.entity.PaymentMethod;
import com.globozor.domain.exceptions.MasterTableException;

public interface UserService {

	public MasterTable login(MasterTable masterTable) throws MasterTableException;
	public MasterTable signup(MasterTable masterTable) throws MasterTableException;
	public Object searchProduct(String searchProduct);
	public Set<MasterTable> searchSellers(Object object);
	public List<MasterTable> enquiryProduct(Enquiry enquiry, MasterTable masterTable);
	public Set<MasterTable> getSelectedSuppliers();
	public Set<MasterTable> getUserByRegion(String region , int roleId);
	public List<String> getResultList();
	public MasterTable updateUser(MasterTable masterTable);
	public List<Favourite> getFavourites(MasterTable masterTable);
	public List<Currency> getCurrency();
	public List<Language> getLanguages();
	public List<PaymentMethod> getPaymentMethods();
}
