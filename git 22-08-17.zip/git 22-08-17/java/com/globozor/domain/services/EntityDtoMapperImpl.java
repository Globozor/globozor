package com.globozor.domain.services;

import java.io.ObjectInputStream.GetField;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.globozor.domain.dtos.BuyerEnquiryResponseDto;
import com.globozor.domain.dtos.BuyerRatingDto;
import com.globozor.domain.dtos.CompanyProfileDto;
import com.globozor.domain.dtos.CustomerDetailDto;
import com.globozor.domain.dtos.DisputeDto;
import com.globozor.domain.dtos.EnquiryDto;
import com.globozor.domain.dtos.FavouriteDto;
import com.globozor.domain.dtos.MasterTableDto;
import com.globozor.domain.dtos.SampleRequestDto;
import com.globozor.domain.dtos.SellerDescriptionDto;
import com.globozor.domain.dtos.SellerDto;
import com.globozor.domain.dtos.SellerEnquiryDto;
import com.globozor.domain.dtos.SellerEnquiryResponseDto;
import com.globozor.domain.dtos.SellerProductDto;
import com.globozor.domain.dtos.SellerRatingDto;
import com.globozor.domain.dtos.TradeShowDto;
import com.globozor.domain.dtos.TransactionDto;
import com.globozor.domain.dtos.TransactionFileDto;
import com.globozor.domain.dtos.TransactionTrackerDto;
import com.globozor.domain.entity.AddressDetails;
import com.globozor.domain.entity.BuyerEnquiryResponse;
import com.globozor.domain.entity.BuyerRating;
import com.globozor.domain.entity.CompanyProfile;
import com.globozor.domain.entity.CustomerDetail;
import com.globozor.domain.entity.Dispute;
import com.globozor.domain.entity.Enquiry;
import com.globozor.domain.entity.Favourite;
import com.globozor.domain.entity.Image;
import com.globozor.domain.entity.MasterTable;
import com.globozor.domain.entity.PaymentMethod;
import com.globozor.domain.entity.Role;
import com.globozor.domain.entity.SampleRequest;
import com.globozor.domain.entity.SellerDescription;
import com.globozor.domain.entity.SellerEnquiry;
import com.globozor.domain.entity.SellerEnquiryResponse;
import com.globozor.domain.entity.SellerProduct;
import com.globozor.domain.entity.SellerProductImage;
import com.globozor.domain.entity.SellerRating;
import com.globozor.domain.entity.TradeShow;
import com.globozor.domain.entity.Transaction;
import com.globozor.domain.entity.TransactionFile;
import com.globozor.domain.entity.TransactionTracker;

@Service
@Transactional
public class EntityDtoMapperImpl implements EntityDtoMapper{

	DateFormat formatter = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");

	@Override
	public SellerDto sellerEntityToDto(MasterTable masterTable) {
		SellerDto sellerDto = new SellerDto();
		SellerProduct sellerProduct2 = new SellerProduct();
		List<String> sellerProductImages= new ArrayList<String>();
		String sellerProductImage = "";
		Set<SellerProduct> sellerProducts = masterTable.getSellerProducts();
		int priority=0;
		int count=0;
		if(sellerProducts!=null){
			for (SellerProduct sellerProduct : sellerProducts) {
				if(count==0){
					priority=sellerProduct.getPriority();
					sellerProduct2 = sellerProduct;
					count++;
				}else{
					if(sellerProduct.getPriority()<priority){
						priority=sellerProduct.getPriority();
						sellerProduct2 = sellerProduct;
					}
				}
			}
		}
		if(sellerProduct2.getSellerProductImage()!=null){
			Set<SellerProductImage> productImages = sellerProduct2.getSellerProductImage();
			System.out.println("se is "+productImages);
			if(productImages!=null){
				for (SellerProductImage sellerProductImage2 : productImages) {
					sellerProductImage = sellerProductImage2.getFilePath();
					sellerProductImages.add(sellerProductImage);
				}
				sellerDto.setSellerProductImage(sellerProductImages);
			}
		}
		if(sellerProduct2.getUnitPrice()!=0){
			sellerDto.setUnitPrice(sellerProduct2.getUnitPrice());
		}
		if(sellerProduct2.getMinimumQuantity()!=0){
			sellerDto.setMinimumQuantity(sellerProduct2.getMinimumQuantity());
		}
		if(sellerProduct2.getProductMaturity()!=null){
			sellerDto.setProductMaturity(sellerProduct2.getProductMaturity());
		}
		if(sellerProduct2.getProductCertification()!=null){
			sellerDto.setProductCertification(sellerProduct2.getProductCertification());
		}
		if(sellerProduct2.getProductWeight()!=null){
			sellerDto.setProductWeight(sellerProduct2.getProductWeight());
		}
		if(sellerProduct2.getProductSize()!=null){
			sellerDto.setProductSize(sellerProduct2.getProductSize());
		}
		if(sellerProduct2.getProductPlaceOfOrigin()!=null){
			sellerDto.setProductPlaceOfOrigin(sellerProduct2.getProductPlaceOfOrigin());
		}
		if(sellerProduct2.getProductShape()!=null){
			sellerDto.setProductShape(sellerProduct2.getProductShape());
		}
		if(sellerProduct2.getProductCultivationType()!=null){
			sellerDto.setProductCultivationType(sellerProduct2.getProductCultivationType());
		}
		if(sellerProduct2.getSellerProductDescription()!=null){
			sellerDto.setSellerProductDescription(sellerProduct2.getSellerProductDescription());
		}
		if(sellerProduct2.getSellerProductName()!=null){
			sellerDto.setSellerProductName(sellerProduct2.getSellerProductName());
		}
		sellerDto.setSellerName(masterTable.getFirstName()+" "+masterTable.getMiddleName()+" "+masterTable.getLastName());
		List<AddressDetails> addressDetails = masterTable.getAddressDetails();
		if(addressDetails!=null){
			int count2 = 0;
			for (AddressDetails addressDetails2 : addressDetails) {
				if(count2==0){
					sellerDto.setSellerCountry(addressDetails2.getCountryLookup().getCountryName());
					count2++;
				}
			}
		}
		if(masterTable.getSellerDescription()!=null){
			if (masterTable.getSellerDescription().getMembershipType()!=null) {
				if(masterTable.getSellerDescription().getMembershipType().getMembershipTypeName()!=null){
					sellerDto.setSellerMembershipType(masterTable.getSellerDescription().getMembershipType().getMembershipTypeName());
				}
			}
		}
		sellerDto.setVerified(masterTable.isVerified());
		if(masterTable.getCompanyName()!=null){
			sellerDto.setSellerCompanyName(masterTable.getCompanyName());
		}
		if(masterTable.getSellerDescription()!=null){
			if(masterTable.getSellerDescription().getTurnover()!=null){
				sellerDto.setSellerTurnover(masterTable.getSellerDescription().getTurnover());
			}
		}
		return sellerDto;
	}

	@Override
	public MasterTableDto masterTableEntityToDto(MasterTable masterTable) {
		MasterTableDto masterTableDto = new MasterTableDto();
		masterTableDto.setMasterTableId(masterTable.getMasterTableId());
		masterTableDto.setEmailId(masterTable.getEmailId());
		masterTableDto.setUserName(masterTable.getUserName());
		masterTableDto.setMobileNumber(masterTable.getMobileNumber());
		if(masterTable.getFirstName()!=null){
			masterTableDto.setFirstName(masterTable.getFirstName());
		}
		if(masterTable.getLastName()!=null){
			masterTableDto.setMiddleName(masterTable.getMiddleName());
		}
		if(masterTable.getLastName()!=null){
			masterTableDto.setLastName(masterTable.getLastName());
		}
		if(masterTable.getCompanyName()!=null){
			masterTableDto.setCompanyName(masterTable.getCompanyName());
		}
		if(masterTable.getWebsiteUrl()!=null){
			masterTableDto.setWebsiteUrl(masterTable.getWebsiteUrl());
		}
		if(masterTable.getPanNumber()!=null){
			masterTableDto.setPanNumber(masterTable.getPanNumber());
		}
		if(masterTable.getIecCodeNumber()!=null){
			masterTableDto.setIecCodeNumber(masterTable.getIecCodeNumber());
		}
		if(masterTable.getGstNumber()!=null){
			masterTableDto.setGstNumber(masterTable.getGstNumber());
		}
		masterTableDto.setVerified(masterTable.isVerified());
		if(masterTable.getRole()!=null&&masterTable.getRole().getRoleId()!=0){
			masterTableDto.setRoleId(masterTable.getRole().getRoleId());
		}
		if(masterTable.getRole()!=null){
			if(masterTable.getRole().getRoleDescription()!=null){
				masterTableDto.setRole(masterTable.getRole().getRoleDescription());
			}
		}
		if(masterTable.getSellerDescription()!=null){
			masterTableDto.setSellerDescriptionId(masterTable.getSellerDescription().getSellerDescriptionId());
			if(masterTable.getSellerDescription().getMembershipType()!=null){
				masterTableDto.setMembershipTypeId(masterTable.getSellerDescription().getMembershipType().getMembershipTypeId());
				if(masterTable.getSellerDescription().getMembershipType().getMembershipTypeName()!=null){
					masterTableDto.setMembershipType(masterTable.getSellerDescription().getMembershipType().getMembershipTypeName());
				}
			}
		}else if (masterTable.getBuyerDescription()!=null) {
			masterTableDto.setBuyerDescriptionId(masterTable.getBuyerDescription().getBuyerDescriptionId());
			if(masterTable.getBuyerDescription().getMembershipType()!=null){
				masterTableDto.setMembershipTypeId(masterTable.getBuyerDescription().getMembershipType().getMembershipTypeId());
				if(masterTable.getBuyerDescription().getMembershipType().getMembershipTypeName()!=null){
					masterTableDto.setMembershipType(masterTable.getBuyerDescription().getMembershipType().getMembershipTypeName());
				}
			}
		}
		return masterTableDto;
	}

	/*@Override
	public MasterTable masterTableDtoToEntity(MasterTableDto masterTableDto) {
		MasterTable masterTable = new MasterTable();
		System.out.println("dto is "+masterTableDto);
		System.out.println("mas ids "+masterTable);
		masterTable.setMasterTableId(masterTableDto.getMasterTableId());
		masterTable.setUserName(masterTableDto.getUserName());
		masterTable.setEmailId(masterTableDto.getEmailId());
		masterTable.setMobileNumber(masterTableDto.getMobileNumber());
		masterTable.setPassword(masterTableDto.getPassword());
		masterTable.setFirstName(masterTableDto.getFirstName());
		masterTable.setMiddleName(masterTableDto.getMiddleName());
		masterTable.setLastName(masterTableDto.getLastName());
		masterTable.setCompanyName(masterTableDto.getCompanyName());
		masterTable.setWebsiteUrl(masterTableDto.getWebsiteUrl());		
		masterTable.setPanNumber(masterTableDto.getPanNumber());
		masterTable.setIecCodeNumber(masterTableDto.getIecCodeNumber());
		masterTable.setGstNumber(masterTableDto.getGstNumber());
		masterTable.setVerified(masterTableDto.isVerified());
		if(masterTableDto.getRoleId()!=0){
			Role role = new Role();
			role.setRoleId(masterTableDto.getRoleId());
			masterTable.setRole(role);
		}
		if(masterTableDto.getSellerDescriptionId() != 0){
			SellerDescription sellerDescription = new SellerDescription();
			sellerDescription.setSellerDescriptionId(masterTableDto.getSellerDescriptionId());
			masterTable.setSellerDescription(sellerDescription);
		}
		System.out.println("m is "+masterTable);
		Set<PaymentMethod> paymentMethods = new HashSet<PaymentMethod>();
		if(masterTableDto.getPaymentMethodIds() != null){
			for(int i = 0 ; i<masterTableDto.getPaymentMethodIds().length ; i++){
				PaymentMethod paymentMethod = new PaymentMethod();
				paymentMethod.setPaymentMethodId(masterTableDto.getPaymentMethodIds()[i]);
				paymentMethods.add(paymentMethod);
			}
			masterTable.setPaymentMethod(paymentMethods);
		}
		Set<Image> images = new HashSet<Image>();
		if(masterTableDto.getImagesId() != null){
			for(int i = 0 ; i<masterTableDto.getImagesId().length ; i++){
				Image image = new Image();
				image.setImageId(masterTableDto.getImagesId()[i]);
				images.add(image);
			}
			masterTable.setProfileImages(images);
		}
		Set<AddressDetails> addressDetailSet = new HashSet<AddressDetails>();
		if(masterTableDto.getAddressDetailIds() != null){
			for(int i = 0 ; i<masterTableDto.getAddressDetailIds().length ; i++){
				AddressDetails addressDetails = new AddressDetails();
				addressDetails.setAddressDetailsId(masterTableDto.getAddressDetailIds()[i]);
				addressDetailSet.add(addressDetails);
			}
			masterTable.setAddressDetails(addressDetailSet);
		}
		Set<SellerProduct> sellerProducts = new HashSet<SellerProduct>();
		if(masterTableDto.getSellerProductIds() != null){
			for (int i = 0; i < masterTableDto.getSellerProductIds().length; i++) {
				SellerProduct sellerProduct = new SellerProduct();
				sellerProduct.setSellerProductId(masterTableDto.getSellerProductIds()[i]);
				sellerProducts.add(sellerProduct);
			}
			masterTable.setSellerProducts(sellerProducts);
		}
		return masterTable;
	}*/

	@Override
	public SellerProductDto sellerProductToDto(SellerProduct sellerProduct) {
		SellerProductDto sellerProductDto = new SellerProductDto();
		if(sellerProduct.getSellerProductName()!=null){
			sellerProductDto.setSellerProductName(sellerProduct.getSellerProductName());
		}
		if(sellerProduct.getSubProduct()!=null){
			if(sellerProduct.getSubProduct().getSubProductName()!=null){
				sellerProductDto.setSubProductName(sellerProduct.getSubProduct().getSubProductName());
			}
		}
		if(sellerProduct.getSellerProductDescription()!=null){
			sellerProductDto.setSellerProductDesc(sellerProduct.getSellerProductDescription());
		}
		if(sellerProduct.getMinimumQuantity()!=0){
			sellerProductDto.setMinimumQuantity(sellerProduct.getMinimumQuantity());
		}
		if(sellerProduct.getUnitPrice()!=0){
			sellerProductDto.setUnitPrice(sellerProduct.getUnitPrice());
		}
		if(sellerProduct.getPriority()!=0){
			sellerProductDto.setPriority(sellerProduct.getPriority());
		}
		if(sellerProduct.getSellerProductId()!=0){
			sellerProductDto.setSellerProductId(sellerProduct.getSellerProductId());
		}
		if(sellerProduct.getProductMaturity()!=null){
			sellerProductDto.setProductMaturity(sellerProduct.getProductMaturity());
		}
		if(sellerProduct.getProductCertification()!=null){
			sellerProductDto.setProductCertification(sellerProduct.getProductCertification());
		}
		if(sellerProduct.getProductWeight()!=null){
			sellerProductDto.setProductWeight(sellerProduct.getProductWeight());
		}
		if(sellerProduct.getProductSize()!=null){
			sellerProductDto.setProductSize(sellerProduct.getProductSize());
		}
		if(sellerProduct.getProductPlaceOfOrigin()!=null){
			sellerProductDto.setProductPlaceOfOrigin(sellerProduct.getProductPlaceOfOrigin());
		}
		if(sellerProduct.getProductShape()!=null){
			sellerProductDto.setProductShape(sellerProduct.getProductShape());
		}
		if(sellerProduct.getProductCultivationType()!=null){
			sellerProductDto.setProductCultivationType(sellerProduct.getProductCultivationType());
		}
		Set<SellerProductImage> sellerProductImages = sellerProduct.getSellerProductImage();
		if(sellerProductImages != null){
			Set<String> filepaths = new HashSet<String>();
			for (SellerProductImage sellerProductImage : sellerProductImages) {
				String filePath;
				if(sellerProductImage.getFilePath()!=null){
					filePath = sellerProductImage.getFilePath();
					filepaths.add(filePath);
				}
			}
			sellerProductDto.setSellerProductImage(filepaths);	
		}
		return sellerProductDto;
	}

	@Override
	public SellerEnquiryDto sellerEnquiryToDto(SellerEnquiry sellerEnquiry) {
		SellerEnquiryDto sellerEnquiryDto = new SellerEnquiryDto();
		if(sellerEnquiry.getId().getEnquiry()!=null){
			if(sellerEnquiry.getId().getEnquiry().getBuyer()!=null){
				sellerEnquiryDto.setBuyerId(sellerEnquiry.getId().getEnquiry().getBuyer().getMasterTableId());
				if(sellerEnquiry.getId().getEnquiry().getBuyer().getCompanyName()!=null){
					sellerEnquiryDto.setBuyerCompanyName(sellerEnquiry.getId().getEnquiry().getBuyer().getCompanyName());
				}
				sellerEnquiryDto.setEnquiryId(sellerEnquiry.getId().getEnquiry().getEnquiryId());
				sellerEnquiryDto.setSellerId(sellerEnquiry.getId().getSeller().getMasterTableId());
			}
			if(sellerEnquiry.getId().getEnquiry().getSubProduct()!=null){
				if(sellerEnquiry.getId().getEnquiry().getSubProduct().getSubProductName()!=null){
					sellerEnquiryDto.setSubProductName(sellerEnquiry.getId().getEnquiry().getSubProduct().getSubProductName());
				}
			}
			if(sellerEnquiry.getId().getEnquiry().getEnqiryDescription()!=null){
				sellerEnquiryDto.setDescription(sellerEnquiry.getId().getEnquiry().getEnqiryDescription());
			}
			if(sellerEnquiry.getId().getEnquiry().getQuantity()!=0){
				sellerEnquiryDto.setQuantity(sellerEnquiry.getId().getEnquiry().getQuantity());
			}
			if(sellerEnquiry.getId().getEnquiry().getUnit()!=null){
				sellerEnquiryDto.setUnit(sellerEnquiry.getId().getEnquiry().getUnit());
			}
			if(sellerEnquiry.getId().getEnquiry().getFilepathAttachments()!=null){
				sellerEnquiryDto.setAttachments(sellerEnquiry.getId().getEnquiry().getFilepathAttachments());
			}
			if(sellerEnquiry.getId().getEnquiry().getSellerProduct()!=null){
				if(sellerEnquiry.getId().getEnquiry().getSellerProduct().getSellerProductName()!=null){
					sellerEnquiryDto.setSellerProductName(sellerEnquiry.getId().getEnquiry().getSellerProduct().getSellerProductName());
				}
			}
		}
		return sellerEnquiryDto;
	}

	@Override
	public CompanyProfileDto companyProfileToDto(CompanyProfile companyProfile) {
		CompanyProfileDto companyProfileDto = new CompanyProfileDto();
		Set<Image> images = companyProfile.getMasterTable().getProfileImages();
		if(images != null){
			for (Image image : images) {
				if(image.getAttachmentTypeOfImage().getAttachmentTypeOfImageId()==2){
					companyProfileDto.setLogo(image.getImageFilepath());
				}
			}
		}
		if(companyProfile.getBusinessType()!=null){
			companyProfileDto.setBusinessType(companyProfile.getBusinessType());
		}
		if(companyProfile.getExportPercentage()!=null){
			companyProfileDto.setExportPercentage(companyProfile.getExportPercentage());
		}
		if(companyProfile.getSourceAcrossMultipleIndustries()!=null){
			companyProfileDto.setSourceAcrossMultipleIndustries(companyProfile.getSourceAcrossMultipleIndustries());
		}
		if(companyProfile.getAverageLeadTime()!=null){
			companyProfileDto.setAverageLeadTime(companyProfile.getAverageLeadTime());
		}
		if(companyProfile.getOverseasOffice()!=null){
			companyProfileDto.setOverseasOffice(companyProfile.getOverseasOffice());
		}
		if(companyProfile.getMasterTable()!=null){
			if(companyProfile.getMasterTable().getSellerDescription()!=null){
				companyProfileDto.setDescriptioAboutCompany(companyProfile.getMasterTable().getSellerDescription().getDescriptionAboutCompany());
				companyProfileDto.setEstablishment(companyProfile.getMasterTable().getSellerDescription().getEstablishment());
				companyProfileDto.setMaximumCapacity(companyProfile.getMasterTable().getSellerDescription().getMaximumCapacity());
				companyProfileDto.setTurnOver(companyProfile.getMasterTable().getSellerDescription().getTurnover());
				companyProfileDto.setPort(companyProfile.getMasterTable().getSellerDescription().getPort());
				companyProfileDto.setNumberOfEmployees(companyProfile.getMasterTable().getSellerDescription().getNumberOfEmployees());
			}
			List<AddressDetails> addressDetails = companyProfile.getMasterTable().getAddressDetails();
			int count = 0;
			if(addressDetails!=null){
				for (AddressDetails addressDetails2 : addressDetails) {
					if(count==0){
						companyProfileDto.setAddressLine1(addressDetails2.getAddressLine1());
						companyProfileDto.setAddressLine2(addressDetails2.getAddressLine2());
						companyProfileDto.setPincode(addressDetails2.getPincode());
						companyProfileDto.setCity(addressDetails2.getCity());
						companyProfileDto.setAddressType(addressDetails2.getAddressType());
						companyProfileDto.setCountry(addressDetails2.getCountryLookup().getCountryName());
						companyProfileDto.setState(addressDetails2.getStateLookup().getStateName());
						count++;
					}
				}
			}
		}
		return companyProfileDto;
	}

	@Override
	public SellerDescriptionDto sellerDescEntityToDto(
			SellerDescription sellerDescription) {
		SellerDescriptionDto sellerDescriptionDto = new SellerDescriptionDto();
		if(sellerDescription!=null){
			sellerDescriptionDto.setSellerDescriptionId(sellerDescription.getSellerDescriptionId());
			if(sellerDescription.getDescriptionAboutCompany()!=null){
			sellerDescriptionDto.setDescriptionAboutCompany(sellerDescription.getDescriptionAboutCompany());
			}
			if(sellerDescription.getEstablishment()!=0){
			sellerDescriptionDto.setEstablishment(sellerDescription.getEstablishment());
			}
			if(sellerDescription.getMaximumCapacity()!=null){
			sellerDescriptionDto.setMaximumCapacity(sellerDescription.getMaximumCapacity());
			}
			if(sellerDescription.getTurnover()!=null){
			sellerDescriptionDto.setTurnover(sellerDescription.getTurnover());
			}
			if(sellerDescription.getPort()!=null){
			sellerDescriptionDto.setPort(sellerDescription.getPort());
			}
			if(sellerDescription.getNumberOfEmployees()!=0){
			sellerDescriptionDto.setNumberOfEmployees(sellerDescription.getNumberOfEmployees());
			}
			if(sellerDescription.getMembershipType()!=null){
				sellerDescriptionDto.setMembershipType(sellerDescription.getMembershipType().getMembershipTypeName());
			}
		}
		return sellerDescriptionDto;
	}

	@Override
	public TradeShowDto tradeShowEntityToDto(TradeShow tradeShow) {
		TradeShowDto tradeShowDto = new TradeShowDto();
		if(tradeShow!=null){
		tradeShowDto.setTradeShowId(tradeShow.getTradeShowId());
		tradeShowDto.setTradeShowName(tradeShow.getTradeShowName());
		tradeShowDto.setTradeShowDate(tradeShow.getTradeShowDate());
		tradeShowDto.setTradeShowHost(tradeShow.getTradeShowHost());
		tradeShowDto.setTradeShowDescription(tradeShow.getTradeShowDescription());
		if(tradeShow.getTradeShowFilepath()!=null){
			tradeShowDto.setTradeShowFilepath(tradeShow.getTradeShowFilepath());
		}
		}
		return tradeShowDto;
	}

	@Override
	public CustomerDetailDto customerEntityToDto(CustomerDetail customerDetail) {
		CustomerDetailDto customerDetailDto = new CustomerDetailDto();
		if(customerDetail!=null){
		customerDetailDto.setCustomerId(customerDetail.getCustomerId());
		customerDetailDto.setCustomerName(customerDetail.getCustomerName());
		customerDetailDto.setCustomerCountry(customerDetail.getCustomerCountry());
		customerDetailDto.setAnnualTurnover(customerDetail.getAnnualTurnover());
		customerDetailDto.setTransactionDocument(customerDetail.getTransactionDocument());
		if(customerDetail.getProductSupply()!=null){
			customerDetailDto.setProductSupply(customerDetail.getProductSupply());
		}
		}
		return customerDetailDto;
	}

	@Override
	public SellerEnquiryResponseDto sellerEnqResponseToDto(
			SellerEnquiryResponse sellerEnquiryResponse) {
		SellerEnquiryResponseDto sellerEnquiryResponseDto =  new SellerEnquiryResponseDto();
		sellerEnquiryResponseDto.setSellerEnquiryResponseId(sellerEnquiryResponse.getSellerEnquiryResponseId());
		if(sellerEnquiryResponse.getSeller()!=null){
		sellerEnquiryResponseDto.setSellerCompanyName(sellerEnquiryResponse.getSeller().getCompanyName());
		}
		if(sellerEnquiryResponse.getQuantity()!=0){
		sellerEnquiryResponseDto.setQuantity(String.valueOf(sellerEnquiryResponse.getQuantity()));
		}
		sellerEnquiryResponseDto.setUnit(sellerEnquiryResponse.getUnit());
		sellerEnquiryResponseDto.setUnitPrice(sellerEnquiryResponse.getUnitPrice());
		sellerEnquiryResponseDto.setEnquiryDescription(sellerEnquiryResponse.getEnquiryDescription());
		sellerEnquiryResponseDto.setStatus(sellerEnquiryResponse.getStatus());
		if(sellerEnquiryResponse.getEnquiry()!=null){
			sellerEnquiryResponseDto.setEnquiryId(sellerEnquiryResponse.getEnquiry().getEnquiryId());
			if(sellerEnquiryResponse.getEnquiry().getSellerProduct()!=null){
				sellerEnquiryResponseDto.setSellerProductName(sellerEnquiryResponse.getEnquiry().getSellerProduct().getSellerProductName());
			}
		}
		return sellerEnquiryResponseDto;
	}

	@Override
	public DisputeDto disputeEntityToDto(Dispute dispute,boolean isSeller) {
		DisputeDto disputeDto = new DisputeDto();
		disputeDto.setDisputeId(dispute.getDisputeId());
		if(dispute.getTransaction()!=null){
			disputeDto.setTransactionId(dispute.getTransaction().getTransactionId());
		}
		/*if(dispute.getTransaction()!=null){
			if(dispute.getTransaction().getBuyer()!=null){
				if(dispute.getTransaction().getBuyer().getFirstName()!=null&&dispute.getTransaction().getBuyer().getLastName()!=null){
					disputeDto.setBuyerName(dispute.getTransaction().getBuyer().getFirstName()+dispute.getTransaction().getBuyer().getLastName());
				}
			}
		}
		if(dispute.getTransaction()!=null){
			if(dispute.getTransaction().getSeller()!=null){
				if(dispute.getTransaction().getSeller().getFirstName()!=null&&dispute.getTransaction().getSeller().getLastName()!=null){
					disputeDto.setSellerName(dispute.getTransaction().getSeller().getFirstName()+dispute.getTransaction().getSeller().getLastName());
				}
			}
		}*/

		if(dispute.getRaisedBy()!=null){
			if(dispute.getRaisedBy().getFirstName()!=null&&dispute.getRaisedBy().getLastName()!=null){
				if(!isSeller){
					disputeDto.setBuyerName(dispute.getRaisedBy().getFirstName()+dispute.getRaisedBy().getLastName());
					disputeDto.setSellerName(dispute.getRaisedFor().getFirstName()+dispute.getRaisedFor().getLastName());
				}else{
					disputeDto.setBuyerName(dispute.getRaisedFor().getFirstName()+dispute.getRaisedFor().getLastName());
					disputeDto.setSellerName(dispute.getRaisedBy().getFirstName()+dispute.getRaisedBy().getLastName());
				}
			}
		}

		disputeDto.setDescription(dispute.getDescription());
		disputeDto.setDisputeName(dispute.getDisputeName());
		return disputeDto;
	}

	@Override
	public BuyerRatingDto buyerRatingToDto(BuyerRating buyerRating) {
		BuyerRatingDto buyerRatingDto = new BuyerRatingDto();
		buyerRatingDto.setBuyerRatingId(buyerRating.getBuyerRatingId());
		if(buyerRating.getTransaction()!=null){
		buyerRatingDto.setTransactionId(buyerRating.getTransaction().getTransactionId());
		if(buyerRating.getTransaction().getBuyer()!=null){
		buyerRatingDto.setBuyerName(buyerRating.getTransaction().getBuyer().getFirstName()+buyerRating.getTransaction().getBuyer().getLastName());
		}
		if(buyerRating.getTransaction().getSeller()!=null){
		buyerRatingDto.setSellerName(buyerRating.getTransaction().getSeller().getFirstName()+buyerRating.getTransaction().getSeller().getLastName());
		}
		}
		buyerRatingDto.setDescription(buyerRating.getDescription());
		buyerRatingDto.setRating(String.valueOf(buyerRating.getRating()));
		return buyerRatingDto;
	}

	@Override
	public SellerRatingDto sellerRatingToDto(SellerRating sellerRating) {
		SellerRatingDto sellerRatingDto = new SellerRatingDto();
		sellerRatingDto.setSellerRatingId(sellerRating.getSellerRatingId());
		if(sellerRating.getTransaction()!=null){
		sellerRatingDto.setTransactionId(sellerRating.getTransaction().getTransactionId());
		if(sellerRating.getTransaction().getBuyer()!=null){
			sellerRatingDto.setBuyerName(sellerRating.getTransaction().getBuyer().getFirstName()+sellerRating.getTransaction().getBuyer().getLastName());
		}
		if(sellerRating.getTransaction().getSeller()!=null){
			sellerRatingDto.setSellerName(sellerRating.getTransaction().getSeller().getFirstName()+sellerRating.getTransaction().getSeller().getLastName());
		}
		}
		sellerRatingDto.setDescription(sellerRating.getDescription());
		sellerRatingDto.setRating(String.valueOf(sellerRating.getRating()));
		return sellerRatingDto;
	}

	@Override
	public TransactionDto transactionEntityToDto(Transaction transaction) {
		TransactionDto transactionDto = new TransactionDto();
		transactionDto.setTransactionId(transaction.getTransactionId());
		if(transaction.getSeller()!=null){
			transactionDto.setSellerCompanyName(transaction.getSeller().getCompanyName());
			transactionDto.setSellerName((transaction.getSeller().getFirstName()+transaction.getSeller().getLastName()));
		}
		if(transaction.getBuyer()!=null){
		transactionDto.setBuyerName(transaction.getBuyer().getFirstName()+transaction.getBuyer().getLastName());
		}
		if(transaction.getSellerProduct()!=null){
		transactionDto.setSellerProductName(transaction.getSellerProduct().getSellerProductName());
		}
		if(transaction.getUnitPrice()!=null){
		transactionDto.setUnitPrice(String.valueOf(transaction.getUnitPrice()));
		}
		if(transaction.getQuantity()!=null){
		transactionDto.setQuantity(String.valueOf(transaction.getQuantity()));
		}
		if(transaction.getTradeAmount()!=null){
		transactionDto.setTotalAmount(String.valueOf(transaction.getTradeAmount()));
		}
		if(transaction.getCommission()!=null){
		transactionDto.setCommission(String.valueOf(transaction.getCommission()));
		}
		if(transaction.getCloseTradeDate()!=null){
		transactionDto.setCloseTradeDate(formatter.format(transaction.getCloseTradeDate()));
		}
		return transactionDto;
	}

	@Override
	public SampleRequestDto sampleRequestToDto(SampleRequest sampleRequest) {
		SampleRequestDto sampleRequestDto = new SampleRequestDto();
		sampleRequestDto.setSampleRequestId(sampleRequest.getSampleRequestId());
		if(sampleRequest.getSellerEnquiryResponse()!=null){
			sampleRequestDto.setSellerEnquiryResponseId(sampleRequest.getSellerEnquiryResponse().getSellerEnquiryResponseId());
		}
		sampleRequestDto.setQuantity(sampleRequest.getQuantity());
		sampleRequestDto.setUnitPrice(sampleRequest.getUnitPrice());
		sampleRequestDto.setCommission(sampleRequest.getCommission());
		sampleRequestDto.setTotalAmount();
		if(sampleRequest.getSampleRequestDate()!=null){
		sampleRequestDto.setSampleRequestDate(formatter.format(sampleRequest.getSampleRequestDate()));
		}
		sampleRequestDto.setStatus(sampleRequest.getStatus());
		return sampleRequestDto;
	}

	@Override
	public FavouriteDto favouriteEntityToDto(Favourite favourite) {
		FavouriteDto favouriteDto = new FavouriteDto();
		favouriteDto.setFavouriteId(favourite.getFavouriteId());
		SellerProduct sellerProduct = favourite.getSellerProduct();
		SellerProductDto sellerProductDto = sellerProductToDto(sellerProduct);
		favouriteDto.setSellerProductDto(sellerProductDto);
		return favouriteDto;
	}

	@Override
	public TransactionTrackerDto transactionTrackerToDto(
			TransactionTracker transactionTracker) {
		TransactionTrackerDto transactionTrackerDto = new TransactionTrackerDto();
		transactionTrackerDto.setTransactionId(transactionTracker.getTransaction().getTransactionId());
		transactionTrackerDto.setContractGenerated(transactionTracker.isContractGenerated());
		transactionTrackerDto.setUploadSignedContractBuyer(transactionTracker.isUploadSignedContractBuyer());
		transactionTrackerDto.setUploadSignedContractSeller(transactionTracker.isUploadSignedContractSeller());
		transactionTrackerDto.setDownloadSignedContractBuyer(transactionTracker.isDownloadSignedContractBuyer());
		transactionTrackerDto.setDownloadSignedContractSeller(transactionTracker.isDownloadSignedContractSeller());
		transactionTrackerDto.setUploadPaymentCertificate(transactionTracker.isUploadPaymentCertificate());
		transactionTrackerDto.setDownloadPaymentCertificate(transactionTracker.isDownloadPaymentCertificate());
		transactionTrackerDto.setUploadShipment(transactionTracker.isUploadShipment());
		transactionTrackerDto.setDownloadShipment(transactionTracker.isDownloadShipment());
		return transactionTrackerDto;
	}

	@Override
	public EnquiryDto enquiryEntityToDto(Enquiry enquiry) {
		EnquiryDto enquiryDto = new EnquiryDto();
		enquiryDto.setEnquiryId(enquiry.getEnquiryId());
		if(enquiry.getSellerProduct()!=null){
			enquiryDto.setSellerProductName(enquiry.getSellerProduct().getSellerProductName());
		}
		if(enquiry.getSubProduct()!=null){
			enquiryDto.setSubProductName(enquiry.getSubProduct().getSubProductName());
		}
		enquiryDto.setQuantity(enquiry.getQuantity());
		enquiryDto.setUnit(enquiry.getUnit());
		enquiryDto.setEnqiryDescription(enquiry.getEnqiryDescription());
		return enquiryDto;
	}

	@Override
	public BuyerEnquiryResponseDto buyerEnquiryResponseToDto(
			BuyerEnquiryResponse buyerEnquiryResponse) {

		BuyerEnquiryResponseDto buyerEnquiryResponseDto= new BuyerEnquiryResponseDto();
		buyerEnquiryResponseDto.setBuyerEnquiryResponseId(buyerEnquiryResponse.getBuyerEnquiryResponseId());
		if(buyerEnquiryResponse.getEnquiry()!=null){
			buyerEnquiryResponseDto.setEnquiryId(buyerEnquiryResponse.getEnquiry().getEnquiryId());
		}
		if(buyerEnquiryResponse.getSellerEnquiryResponse()!=null){
			if(buyerEnquiryResponse.getSellerEnquiryResponse().getBuyer()!=null){
				buyerEnquiryResponseDto.setBuyerId(buyerEnquiryResponse.getSellerEnquiryResponse().getBuyer().getMasterTableId());
				buyerEnquiryResponseDto.setBuyerName(buyerEnquiryResponse.getSellerEnquiryResponse().getBuyer().getFirstName()+" "+buyerEnquiryResponse.getSellerEnquiryResponse().getBuyer().getLastName());
			}
			if(buyerEnquiryResponse.getSellerEnquiryResponse().getSellerProduct()!=null){
				buyerEnquiryResponseDto.setSellerProductId(buyerEnquiryResponse.getSellerEnquiryResponse().getSellerProduct().getSellerProductId());
				buyerEnquiryResponseDto.setSellerProductName(buyerEnquiryResponse.getSellerEnquiryResponse().getSellerProduct().getSellerProductName());
			}
		}
		buyerEnquiryResponseDto.setQuantity(String.valueOf(buyerEnquiryResponse.getQuantity()));
		buyerEnquiryResponseDto.setUnit(buyerEnquiryResponse.getUnit());
		buyerEnquiryResponseDto.setUnitPrice(buyerEnquiryResponse.getUnitPrice());
		buyerEnquiryResponseDto.setEnquiryDescription(buyerEnquiryResponse.getEnquiryDescription());
		buyerEnquiryResponseDto.setStatus(buyerEnquiryResponse.getStatus());

		return buyerEnquiryResponseDto;
	}

	@Override
	public TransactionFileDto transactionFileToDto(
			TransactionFile transactionFile) {
		TransactionFileDto transactionFileDto = new TransactionFileDto();
		transactionFileDto.setTransactionFileId(transactionFile.getTransactionFileId());
		transactionFileDto.setTransactionDto(transactionEntityToDto(transactionFile.getTransaction()));
		transactionFileDto.setBuyerFilepath(transactionFile.getBuyerFilepath());
		transactionFileDto.setSellerFilepath(transactionFile.getSellerFilepath());
		transactionFileDto.setFileType(transactionFile.getFileType());
		return transactionFileDto;
	}

}
