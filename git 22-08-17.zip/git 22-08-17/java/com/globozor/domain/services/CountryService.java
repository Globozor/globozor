package com.globozor.domain.services;

import java.util.List;

import com.globozor.domain.entity.CountryLookup;

public interface CountryService {

	public List<CountryLookup> getCountry();

}
