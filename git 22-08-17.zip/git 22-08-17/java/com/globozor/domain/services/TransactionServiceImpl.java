package com.globozor.domain.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.globozor.domain.entity.Transaction;
import com.globozor.domain.entity.TransactionFile;
import com.globozor.domain.entity.TransactionTracker;
import com.globozor.domain.repository.TransactionFileRepository;
import com.globozor.domain.repository.TransactionRepository;
import com.globozor.domain.repository.TransactionTrackerRepository;

@Service
public class TransactionServiceImpl implements TransactionService{

	@Autowired
	TransactionRepository transactionRepository; 
	
	@Autowired
	TransactionFileRepository transactionFileRepository;
	
	@Autowired
	TransactionTrackerRepository transactionTrackerRepository;
	
	@Override
	public Transaction getTransactionDetail(long transactionId) {
		return transactionRepository.findOne(transactionId);
	}

	@Override
	public TransactionFile saveFile(TransactionFile transactionFile) {
		return transactionFileRepository.save(transactionFile);
	}

	@Override
	public List<TransactionFile> getFile(TransactionFile transactionFile) {
		return transactionFileRepository.findByFileTypeAndTransactionId(transactionFile.getTransaction().getTransactionId(),transactionFile.getFileType());
	}

	@Override
	public Transaction saveTransaction(Transaction transaction) {
		transaction= transactionRepository.save(transaction);
		TransactionTracker transactionTracker = transactionTrackerRepository.findByTransaction(transaction.getTransactionId());
		if(transactionTracker==null){
			transactionTracker = new TransactionTracker(transaction,false,false,false,false,false,false,false,false,false);
			transactionTracker = transactionTrackerRepository.save(transactionTracker);
			transaction.setTransactionTracker(transactionTracker);
		}
		return transaction;
	}

	@Override
	public TransactionTracker saveTransactionTracker(
			TransactionTracker transactionTracker) {
		TransactionTracker transactionTracker2=transactionTrackerRepository.findByTransaction(transactionTracker.getTransaction().getTransactionId());
		if(transactionTracker2!=null){
			if(transactionTracker.isContractGenerated()){
				transactionTracker2.setContractGenerated(transactionTracker.isContractGenerated());
			}
			if(transactionTracker.isDownloadPaymentCertificate()){
				transactionTracker2.setDownloadPaymentCertificate(true);
			}
			if(transactionTracker.isDownloadShipment()){
				transactionTracker2.setDownloadShipment(true);
			}
			if(transactionTracker.isDownloadSignedContractBuyer()){
				transactionTracker2.setDownloadSignedContractBuyer(true);
			}
			if(transactionTracker.isDownloadSignedContractSeller()){
				transactionTracker2.setDownloadSignedContractSeller(true);
			}
			if(transactionTracker.isUploadPaymentCertificate()){
				transactionTracker2.setUploadPaymentCertificate(true);
			}
			if(transactionTracker.isUploadShipment()){
				transactionTracker2.setUploadShipment(true);
			}
			if(transactionTracker.isUploadSignedContractBuyer()){
				transactionTracker2.setUploadSignedContractBuyer(true);
			}
			if(transactionTracker.isUploadSignedContractSeller()){
				transactionTracker2.setUploadSignedContractSeller(true);
			}
			transactionTracker=transactionTrackerRepository.save(transactionTracker2);
			return transactionTracker;
		}
		return null;
	}

	@Override
	public TransactionTracker getTransactionTracker(long transactionId) {
		TransactionTracker transactionTracker=transactionTrackerRepository.findByTransaction(transactionId);
		return transactionTracker;
	}
	
}
