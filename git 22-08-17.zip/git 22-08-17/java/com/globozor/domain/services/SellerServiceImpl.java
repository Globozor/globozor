package com.globozor.domain.services;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.json.simple.JSONArray;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.globozor.domain.dtos.CompanyDto;
import com.globozor.domain.dtos.CompanyProfileDto;
import com.globozor.domain.dtos.UserInfo;
import com.globozor.domain.entity.AddressDetails;
import com.globozor.domain.entity.BuyerEnquiryResponse;
import com.globozor.domain.entity.BuyerRating;
import com.globozor.domain.entity.CompanyProfile;
import com.globozor.domain.entity.CountryLookup;
import com.globozor.domain.entity.Currency;
import com.globozor.domain.entity.CustomerDetail;
import com.globozor.domain.entity.Dispute;
import com.globozor.domain.entity.Enquiry;
import com.globozor.domain.entity.Feedback;
import com.globozor.domain.entity.Language;
import com.globozor.domain.entity.MasterTable;
import com.globozor.domain.entity.Notification;
import com.globozor.domain.entity.PaymentMethod;
import com.globozor.domain.entity.SampleRequest;
import com.globozor.domain.entity.SellerDescription;
import com.globozor.domain.entity.SellerEnquiry;
import com.globozor.domain.entity.SellerEnquiryResponse;
import com.globozor.domain.entity.SellerProduct;
import com.globozor.domain.entity.SellerProductImage;
import com.globozor.domain.entity.SellerRating;
import com.globozor.domain.entity.StateLookup;
import com.globozor.domain.entity.TradeShow;
import com.globozor.domain.entity.Transaction;
import com.globozor.domain.exceptions.SellerException;
import com.globozor.domain.repository.AddressDetailsRepository;
import com.globozor.domain.repository.BuyerEnquiryResponseRepository;
import com.globozor.domain.repository.BuyerRatingRepository;
import com.globozor.domain.repository.CompanyProfileRespository;
import com.globozor.domain.repository.CurrencyRepository;
import com.globozor.domain.repository.CustomerDetailRepository;
import com.globozor.domain.repository.DisputeRepository;
import com.globozor.domain.repository.EnquiryRepository;
import com.globozor.domain.repository.LanguageRepository;
import com.globozor.domain.repository.MasterTableRepository;
import com.globozor.domain.repository.NotificationRepository;
import com.globozor.domain.repository.PaymentMethodRepository;
import com.globozor.domain.repository.SampleRequestRepository;
import com.globozor.domain.repository.SellerDescriptionRepository;
import com.globozor.domain.repository.SellerEnquiryRepository;
import com.globozor.domain.repository.SellerEnquiryResponseRepository;
import com.globozor.domain.repository.SellerProductImageRepository;
import com.globozor.domain.repository.SellerProductRepository;
import com.globozor.domain.repository.SellerRatingRepository;
import com.globozor.domain.repository.TradeShowRepository;
import com.globozor.domain.repository.TransactionRepository;

@Service
public class SellerServiceImpl implements SellerService{

	@Autowired
	SellerEnquiryResponseRepository sellerEnquiryResponseRepository;
	
	@Autowired
	NotificationRepository notificationRepository;
	
	@Autowired
	SellerProductRepository sellerProductRepository;
	
	@Autowired
	SellerEnquiryRepository sellerEnquiryRepository;
	
	@Autowired
	SellerDescriptionRepository sellerDescriptionRepository;
	
	@Autowired
	CompanyProfileRespository companyProfileRespository;
	
	@Autowired
	TradeShowRepository tradeShowRepository;
	
	@Autowired
	CustomerDetailRepository customerDetailRepository;
	
	@Autowired
	DisputeRepository disputeRepository;
	
	/*@Autowired
	FeedbackRepository feedbackRepository;*/
	
	@Autowired
	BuyerRatingRepository buyerRatingRepository;
	
	@Autowired
	SellerRatingRepository sellerRatingRepository;
	
	@Autowired
	TransactionRepository transactionRepository;
	
	@Autowired
	SampleRequestRepository sampleRequestRepository;
	
	@Autowired
	SellerProductImageRepository sellerProductImageRepository;
	
	@Autowired
	BuyerEnquiryResponseRepository buyerEnquiryResponseReository;
	
	@Autowired
	MasterTableRepository masterTableRepository;
	
	@Autowired
	EnquiryRepository enquiryRepository;
	
	@Autowired
	CurrencyRepository currencyRepository;
	
	@Autowired
	LanguageRepository languageRepository;
	
	@Autowired
	PaymentMethodRepository PaymentMethodRepository;
	
	@Autowired
	AddressDetailsRepository addressDetailsRepository;
	
	@Override
	public SellerEnquiryResponse responseEnquiry(
			SellerEnquiryResponse sellerEnquiryResponse,String response) {
		sellerEnquiryResponse.setStatus(response);
		sellerEnquiryResponse = sellerEnquiryResponseRepository.save(sellerEnquiryResponse);
		Enquiry enquiry = enquiryRepository.findOne(sellerEnquiryResponse.getEnquiry().getEnquiryId());
		sellerEnquiryResponse.setEnquiry(enquiry);
		MasterTable buyer = masterTableRepository.findOne(sellerEnquiryResponse.getBuyer().getMasterTableId());
		sellerEnquiryResponse.setBuyer(buyer);
		MasterTable seller = masterTableRepository.findOne(sellerEnquiryResponse.getSeller().getMasterTableId());
		sellerEnquiryResponse.setSeller(seller);
		SellerProduct sellerProduct = sellerProductRepository.findOne(sellerEnquiryResponse.getSellerProduct().getSellerProductId());
		sellerEnquiryResponse.setSellerProduct(sellerProduct);
		Set<Notification> notifications = new HashSet<Notification>();
		if(sellerEnquiryResponse.getEnquiry()!=null){
			if(sellerEnquiryResponse.getEnquiry().getBuyer()!=null){
				if(sellerEnquiryResponse.getEnquiry().getBuyer().getNotifications()!=null){
					notifications = sellerEnquiryResponse.getEnquiry().getBuyer().getNotifications();
				}
			}
		}
		Notification notification = new Notification();
		notification.setMasterTable(sellerEnquiryResponse.getEnquiry().getBuyer());
		notification.setNotificationDesc("New response for your enquiry with id "+sellerEnquiryResponse.getEnquiry().getEnquiryId()+" from "+sellerEnquiryResponse.getSeller().getUserName());
		notification.setNotificationType("Enquiry response");
		notification.setActive(true);
		notification.setCreatedTime(new Date());
		notification = notificationRepository.save(notification);
		//notifications.add(notification);
		//sellerEnquiryResponse.getEnquiry().getBuyer().setNotifications(notifications);
		return sellerEnquiryResponse;
	}

	@Override
	public List<Notification> getNotifications(MasterTable masterTable) {
		return notificationRepository.findAllNotifications(masterTable.getMasterTableId());
	}

	@Override
	public SellerProduct addSellerProduct(SellerProduct sellerProduct,MasterTable masterTable) {
		sellerProduct.setStatus("pending_approval");
		sellerProduct.setActive(true);
		sellerProduct.setPriority(10000);
		sellerProduct.setMasterTable(masterTable);
		Set<SellerProductImage> sellerProductImages = new HashSet<SellerProductImage>();
		if(sellerProduct.getSellerProductImage()!=null){
			sellerProductImages = sellerProduct.getSellerProductImage();
			sellerProduct.setSellerProductImage(null);
		}
		sellerProduct = sellerProductRepository.save(sellerProduct);
		if(sellerProductImages!=null){
			Set<SellerProductImage> productImages = new HashSet<SellerProductImage>();
			for (SellerProductImage sellerProductImage : sellerProductImages) {
				sellerProductImage.setSellerProduct(sellerProduct);
				sellerProductImage = sellerProductImageRepository.save(sellerProductImage);
				productImages.add(sellerProductImage);
			}
			sellerProduct.setSellerProductImage(productImages);
		}
		return sellerProduct;
	}

	@Override
	public String removeSellerProduct(long sellerProductId,MasterTable masterTable) throws SellerException{
		SellerProduct sellerProduct = sellerProductRepository.findBySellerProductId(sellerProductId);
		if(sellerProduct.getMasterTable().getMasterTableId() == masterTable.getMasterTableId()){
			sellerProduct.setActive(false);
			String message = "";
			try {
				sellerProductRepository.save(sellerProduct);
				message = "Product successfully removed";
			} catch (Exception e) {
				message = "Unable to delete object";
				throw new SellerException("Unable to delete product");
			}
			return message;
		}else{
			throw new SellerException("You are not allowed to remove this product");
		}
	}

	@Override
	public List<SellerProduct> getSellerProduct(MasterTable masterTable , String status) {
		return sellerProductRepository.findByStatus(status , masterTable.getMasterTableId(),true);
	}

	@Override
	public List<SellerEnquiry> getSellerEnquiry(MasterTable masterTable) {
		return sellerEnquiryRepository.findByIsActive(true,masterTable.getMasterTableId());
	}

	@Override
	public List<SellerProduct> getSellerProductShowCase(MasterTable masterTable) {
		int priority=0;
		long membershipTypeId=masterTable.getSellerDescription().getMembershipType().getMembershipTypeId();
		if(membershipTypeId==1){
			priority = 40;
		}else if(membershipTypeId==2){
			priority = 25;
		}else if(membershipTypeId==3){
			priority=15;
		}else{
			priority=1;
		}
		return sellerProductRepository.getSellerProductShowCase(priority,masterTable.getMasterTableId());
	}

	@Override
	public SellerProduct setSellerProductPriority(long sellerProductId,
			int priority , MasterTable masterTable) throws SellerException {
		SellerProduct sellerProduct = sellerProductRepository.findOne(sellerProductId);
		if(sellerProduct!=null){
			if(sellerProduct.getMasterTable().getMasterTableId()==masterTable.getMasterTableId()){
				sellerProduct.setPriority(priority);
				sellerProduct = sellerProductRepository.save(sellerProduct);
			}else{
				throw new SellerException("You are not allowed to change priority of this product");
			}
			return sellerProduct;
		}else{
			throw new SellerException("You are not allowed to change priority of this product");
		}
	}

	@Override
	public SellerEnquiry rejectEnquiry(long enquiryId) {
		SellerEnquiry sellerEnquiry = sellerEnquiryRepository.findByEnquiry(enquiryId);
		sellerEnquiry.setActive(false);
		sellerEnquiry = sellerEnquiryRepository.save(sellerEnquiry); 
		return sellerEnquiry;
	}

	@Override
	public SellerDescription getSellerDescription(MasterTable masterTable) {
		SellerDescription sellerDescription = sellerDescriptionRepository.findBySellerId(masterTable.getMasterTableId());
		return sellerDescription;
	}

	@Override
	public TradeShow saveTradeShow(TradeShow tradeShow) {
		tradeShow = tradeShowRepository.save(tradeShow);
		return tradeShow;
	}

	@Override
	public CustomerDetail saveCustomerDetail(CustomerDetail customerDetail) {
		customerDetail = customerDetailRepository.save(customerDetail);
		return customerDetail;
	}

	/*@Override
	public CompanyProfileDto saveCompanyProfile(JSONArray companyProfileDto) {
		CompanyProfile companyProfile = (CompanyProfile) companyProfileDto.get(0);
		companyProfile = companyProfileRespository.save(companyProfile);
		System.out.println("com is "+companyProfile);
		if(companyProfileDto.get(1)!=null){
			TradeShow tradeShow = (TradeShow) companyProfileDto.get(1);
			tradeShow.setCompanyProfile(companyProfile);
			tradeShow = saveTradeShow(tradeShow);
			System.out.println("trade show is "+tradeShow);
		}
		if(companyProfileDto.get(2)!=null){
			CustomerDetail customerDetail = (CustomerDetail) companyProfileDto.get(2);
			customerDetail.setCompanyProfile(companyProfile);
			customerDetail=saveCustomerDetail(customerDetail);
			System.out.println("customer is "+customerDetail);
		}
		return new CompanyProfileDto();
		
		CompanyProfile companyProfile = companyProfileDto.getCompanyProfile();
		CompanyProfileDto profileDto = new CompanyProfileDto();
		companyProfile = companyProfileRespository.save(companyProfile);
		profileDto.setCompanyProfile(companyProfile);
		if(companyProfileDto.getTradeShow()!=null){
			TradeShow tradeShow = companyProfileDto.getTradeShow();
			tradeShow.setCompanyProfile(companyProfile);
			tradeShow = saveTradeShow(tradeShow);
			profileDto.setTradeShow(tradeShow);
		}
		if(companyProfileDto.getCustomerDetail()!=null){
			CustomerDetail customerDetail = companyProfileDto.getCustomerDetail();
			customerDetail.setCompanyProfile(companyProfile);
			customerDetail=saveCustomerDetail(customerDetail);
			profileDto.setCustomerDetail(customerDetail);
		}
		return profileDto;
	}*/

	@Override
	public Dispute createDispute(Dispute dispute,MasterTable masterTable) throws SellerException {
		Transaction transaction = transactionRepository.findOne(dispute.getTransaction().getTransactionId());
		if(transaction!=null&&transaction.getSeller().getMasterTableId()==masterTable.getMasterTableId()){
			dispute.setRaisedBy(transaction.getSeller());
			dispute.setRaisedFor(transaction.getBuyer());
			System.out.println("transaction "+transaction);
			dispute= disputeRepository.save(dispute);
			return dispute;
		}
		else if(transaction==null){
			throw new SellerException("You can not raise a dispute for this transaction");
		}
		else{
			throw new SellerException("You can not raise a dispute for this transaction");
		}
	}

	@Override
	public List<Dispute> getAllDisputes(MasterTable masterTable,String type) throws SellerException {
		if(type.equals("raised")){
			return disputeRepository.findAllRaisedBy(masterTable.getMasterTableId());
		}else if(type.equals("received")){
			return disputeRepository.findAllRecievedBy(masterTable.getMasterTableId());
		}else{
			throw new SellerException("No dispute found");
		}
	}

	/*
	@Override
	public Feedback createFeedback(Feedback feedback) {
		return feedbackRepository.save(feedback);
	}

	@Override
	public List<Feedback> getAllFeedbacks(MasterTable masterTable) {
		return feedbackRepository.findAllById();
	}
*/
	@Override
	public BuyerRating rateBuyer(BuyerRating buyerRating,MasterTable masterTable) throws SellerException {
		Transaction transaction = transactionRepository.findOne(buyerRating.getTransaction().getTransactionId());
		if(transaction!=null&&transaction.getSeller().getMasterTableId()==masterTable.getMasterTableId()){
			return buyerRatingRepository.save(buyerRating);
		}else if(transaction==null){
			throw new SellerException("You have not transacted with this Buyer");
		}else{
			throw new SellerException("You have not transacted with this Buyer");
		}
	}

	@Override
	public List<SellerRating> getAllSellerRating(MasterTable masterTable) {
		return sellerRatingRepository.findAllById(masterTable.getMasterTableId());
	}

	@Override
	public List<Transaction> getAllSellerOrders(MasterTable masterTable) {
		return transactionRepository.getAllSellerOrder(masterTable.getMasterTableId());
	}

	@Override
	public List<SampleRequest> getAllSampleRequest(MasterTable masterTable,
			String status) {
		return sampleRequestRepository.findSampleByStatusSeller(masterTable.getMasterTableId(),status);
	}

	@Override
	public CompanyProfile saveCompanyProfile(CompanyProfile companyProfile) {
		CompanyProfile companyProfile2 = 
				companyProfileRespository.findUnique(companyProfile.getMasterTable().getMasterTableId());
		if(companyProfile2 == null){
			List<TradeShow> tradeShows = companyProfile.getTradeShow();
			List<CustomerDetail> customerDetails = companyProfile.getCustomerDetails();
			List<TradeShow> tradeShows2 = new ArrayList<TradeShow>();
			List<CustomerDetail> customerDetails2 = new ArrayList<CustomerDetail>();
			companyProfile.setTradeShow(null);
			companyProfile.setCustomerDetails(null);
			companyProfile = companyProfileRespository.save(companyProfile);
			if(tradeShows!=null){
				for (TradeShow tradeShow : tradeShows) {
					tradeShow.setCompanyProfile(companyProfile);
					tradeShow = tradeShowRepository.save(tradeShow);
					tradeShows2.add(tradeShow);
				}
			}
			if(customerDetails!=null){
				for (CustomerDetail customerDetail : customerDetails) {
					customerDetail.setCompanyProfile(companyProfile);
					customerDetail = customerDetailRepository.save(customerDetail);
					customerDetails2.add(customerDetail);
				}
			}
			companyProfile.setTradeShow(tradeShows2);
			companyProfile.setCustomerDetails(customerDetails2);
			return companyProfile;
		}else{
			companyProfile.setCompanyProfileId(companyProfile2.getCompanyProfileId());
			return companyProfileRespository.save(companyProfile);
		}
	}

	@Override
	public SampleRequest setSampleRequestStatus(String status,
			long sampleRequestId, MasterTable masterTable) throws SellerException {
		SampleRequest sampleRequest = sampleRequestRepository.findOne(sampleRequestId);
		if(sampleRequest.getSellerEnquiryResponse().getSeller().getMasterTableId()==masterTable.getMasterTableId()){
			sampleRequest.setStatus(status);
			return sampleRequestRepository.save(sampleRequest);
		}else{
			throw new SellerException("You are not authorised to change the status of this request");
		}
	}

	@Override
	public CompanyProfile saveCompanyProfil(CompanyDto companyProfileDto,MasterTable masterTable) throws SellerException {
		CompanyProfile companyProfile = companyProfileDto.getCompanyProfile();
		companyProfile.setMasterTable(masterTable);
		CompanyProfile companyProfile2= companyProfileRespository.findUnique(masterTable.getMasterTableId());
		if(companyProfile2 == null){
		companyProfile = companyProfileRespository.save(companyProfile);
		
		List<TradeShow> tradeShows = companyProfileDto.getTradeShows();
		List<CustomerDetail> customerDetails = companyProfileDto.getCustomerDetails();
		
		List<TradeShow> tradeShows2 = new ArrayList<TradeShow>();
		List<CustomerDetail> customerDetails2 = new ArrayList<CustomerDetail>();
		
		if(customerDetails!=null){
			for (CustomerDetail customerDetail : customerDetails) {
				CompanyProfile profile = new CompanyProfile();
				profile.setCompanyProfileId(companyProfile.getCompanyProfileId());
				customerDetail.setCompanyProfile(profile);
				customerDetail = customerDetailRepository.save(customerDetail);
				customerDetails2.add(customerDetail);
			}
		}
		
		if(tradeShows!=null){
			for (TradeShow tradeShow : tradeShows) {
				tradeShow.setCompanyProfile(companyProfile);
				tradeShow = tradeShowRepository.save(tradeShow);
				tradeShows2.add(tradeShow);
			}
		}
		
		companyProfile.setTradeShow(tradeShows2);
		companyProfile.setCustomerDetails(customerDetails2);
		//companyProfile=companyProfileRespository.save(companyProfile);
		
		}else{
			/*companyProfile.setCompanyProfileId(companyProfile2.getCompanyProfileId());
			List<TradeShow> tradeShows = companyProfile2.getTradeShow();
			List<CustomerDetail> customerDetails = companyProfile2.getCustomerDetails();
			for (TradeShow tradeShow : companyProfileDto.getTradeShows()) {
				if (tradeShow.getTradeShowId()!=0) {
					tradeShows.remove(tradeShow);
				}
				tradeShow = tradeShowRepository.save(tradeShow);
				tradeShows.add(tradeShow);
			}
			for (CustomerDetail customerDetail : companyProfileDto.getCustomerDetails()) {
				if(customerDetail.getCustomerId()!=0){
					customerDetails.remove(customerDetail);
				}
				customerDetail = customerDetailRepository.save(customerDetail);
				customerDetails.add(customerDetail);
			}
			companyProfile.setTradeShow(tradeShows);
			companyProfile.setCustomerDetails(customerDetails);
			//return companyProfileRespository.save(companyProfile);
*/		
		throw new SellerException("Your Company profile is already saved");	
		}
		return companyProfile;
	}

	@Override
	public List<BuyerEnquiryResponse> getBuyerResponses(MasterTable seller , String type) {
		List<BuyerEnquiryResponse> buyerEnquiryResponses = buyerEnquiryResponseReository.findByTypeResponse(type,seller.getMasterTableId());
		return buyerEnquiryResponses;
	}

	@Override
	public MasterTable saveCompanyProfilePage2(UserInfo userInfo,MasterTable masterTable) {
		masterTable = masterTableRepository.findByMasterTableId(masterTable.getMasterTableId());
		SellerDescription sellerDescription = sellerDescriptionRepository.findBySellerId(masterTable.getMasterTableId());
		if(sellerDescription==null){
			sellerDescription = new SellerDescription();
		}
		sellerDescription.setDescriptionAboutCompany(userInfo.getDescriptionAboutCompany());
		sellerDescription.setEstablishment(userInfo.getEstablishment());
		sellerDescription.setMaximumCapacity(userInfo.getMaximumCapacity());
		sellerDescription.setPort(userInfo.getPort());
		sellerDescription.setTurnover(userInfo.getTurnover());
		sellerDescription.setNumberOfEmployees(userInfo.getNumberOfEmployees());
		sellerDescription = sellerDescriptionRepository.save(sellerDescription);
		List<AddressDetails> addressDetails = addressDetailsRepository.findByUserId(masterTable.getMasterTableId());
		masterTable.setAddressDetails(null);
		if(addressDetails==null){
			addressDetails = new ArrayList<AddressDetails>();
		}
		AddressDetails addressDetails2 = new AddressDetails();
		addressDetails2.setAddressLine1(userInfo.getAddressLine1());
		addressDetails2.setAddressLine2(userInfo.getAddressLine2());
		addressDetails2.setPincode(userInfo.getPincode());
		addressDetails2.setCity(userInfo.getCity());
		CountryLookup countryLookup = new CountryLookup();
		countryLookup.setCountryLookupId(userInfo.getCountryLookupId());
		addressDetails2.setCountryLookup(countryLookup);
		StateLookup stateLookup = new StateLookup();
		stateLookup.setStateLookupId(userInfo.getStateLookupId());
		addressDetails2.setStateLookup(stateLookup);
		addressDetails2.setAddressType(userInfo.getAddressType());
		addressDetails2.setMasterTable(masterTable);
		addressDetails2 = addressDetailsRepository.save(addressDetails2);
		addressDetails.add(addressDetails2);
		masterTable.setAddressDetails(addressDetails);
		Set<Currency> currencies = masterTable.getCurrencies();
		masterTable.setCurrencies(null);
		if(currencies==null){
			currencies=new HashSet<Currency>();
		}
		long[] currencyIds=userInfo.getCurrencyId();
		for (long currencyId : currencyIds) {
			Currency currency=currencyRepository.findOne(currencyId);
			currencies.add(currency);
		}
		masterTable.setCurrencies(currencies);
		
		Set<Language> languages = masterTable.getLanguages();
		masterTable.setLanguages(null);
		if(languages==null){
			languages=new HashSet<Language>();
		}
		long[] languageIds=userInfo.getLanguageId();
		for (long languageId : languageIds) {
			Language language=languageRepository.findOne(languageId);
			languages.add(language);
		}
		masterTable.setLanguages(languages);
		
		Set<PaymentMethod> paymentMethods = masterTable.getPaymentMethod();
		masterTable.setPaymentMethod(null);
		if(paymentMethods==null){
			paymentMethods=new HashSet<PaymentMethod>();
		}
		long[] paymentMethodIds=userInfo.getPaymentMethodIds();
		for (long paymentMethodId : paymentMethodIds) {
			PaymentMethod paymentMethod=PaymentMethodRepository.findOne(paymentMethodId);
			paymentMethods.add(paymentMethod);
		}
		masterTable.setPaymentMethod(paymentMethods);
		masterTable = masterTableRepository.save(masterTable);
		return masterTable;
	}

}
