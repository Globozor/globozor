package com.globozor.domain.services;

import org.json.simple.JSONObject;
import org.springframework.mail.MailException;

import com.globozor.domain.entity.MasterTable;

public interface EmailSender {
	public void sendEmail(JSONObject jsonObject, MasterTable masterTable) throws MailException;
}
