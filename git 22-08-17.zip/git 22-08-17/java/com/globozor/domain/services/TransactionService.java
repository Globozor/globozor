package com.globozor.domain.services;

import java.util.List;

import com.globozor.domain.entity.Transaction;
import com.globozor.domain.entity.TransactionFile;
import com.globozor.domain.entity.TransactionTracker;

public interface TransactionService {

	public Transaction getTransactionDetail(long transactionId);

	public TransactionFile saveFile(TransactionFile transactionFile);

	public List<TransactionFile> getFile(TransactionFile transactionFile);

	public Transaction saveTransaction(Transaction transaction);

	public TransactionTracker saveTransactionTracker(
			TransactionTracker transactionTracker);

	public TransactionTracker getTransactionTracker(long transactionId);

}
