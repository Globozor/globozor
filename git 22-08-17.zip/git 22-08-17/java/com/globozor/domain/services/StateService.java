package com.globozor.domain.services;

import java.util.List;

import com.globozor.domain.entity.StateLookup;

public interface StateService {

	public List<StateLookup> getStateByCountry(long countryId);

}
