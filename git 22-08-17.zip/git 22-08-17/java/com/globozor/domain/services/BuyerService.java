package com.globozor.domain.services;

import java.util.List;
import java.util.Set;

import com.globozor.domain.dtos.ResponseDto;
import com.globozor.domain.entity.BuyerEnquiryResponse;
import com.globozor.domain.entity.BuyerRating;
import com.globozor.domain.entity.CompanyProfile;
import com.globozor.domain.entity.Dispute;
import com.globozor.domain.entity.Enquiry;
import com.globozor.domain.entity.Favourite;
import com.globozor.domain.entity.MasterTable;
import com.globozor.domain.entity.PaymentMethod;
import com.globozor.domain.entity.SampleRequest;
import com.globozor.domain.entity.SellerEnquiryResponse;
import com.globozor.domain.entity.SellerRating;
import com.globozor.domain.entity.Transaction;
import com.globozor.domain.exceptions.BuyerException;

public interface BuyerService {

	public List<Transaction> getAllOrders(MasterTable masterTable);

	public SellerRating rateSeller(SellerRating sellerRating, MasterTable masterTable) throws BuyerException;

	public List<BuyerRating> getAllBuyerRating(MasterTable masterTable);

	public Dispute createDispute(Dispute dispute, MasterTable masterTable) throws BuyerException;

	public List<Dispute> getAllDisputes(MasterTable masterTable, String type) throws BuyerException;

	public List<SampleRequest> getAllSampleRequest(MasterTable masterTable,
			String status);

	public List<Enquiry> getBuyerAllEnquiries(MasterTable masterTable);

	public List<SellerEnquiryResponse> getSellerEnquiryResponse(String type,
			MasterTable masterTable);

	public CompanyProfile saveCompanyProfile(CompanyProfile companyProfile);

	public Favourite addFavourite(MasterTable masterTable, long id);

	public List<Favourite> getAllFavourites(MasterTable masterTable);

	public BuyerEnquiryResponse responseSellerEnquiryResponse(String response,
			BuyerEnquiryResponse buyerEnquiryResponse);

	public Set<PaymentMethod> getPaymentMethods(MasterTable masterTable);

	public CompanyProfile getSellerCompanyProfile(MasterTable masterTable);
	
}
