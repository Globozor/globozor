package com.globozor.domain.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.globozor.domain.entity.DashboardLink;

public interface DashboardRepository extends JpaRepository<DashboardLink, Long>{

	public List<DashboardLink> findByRole(String role);
}
