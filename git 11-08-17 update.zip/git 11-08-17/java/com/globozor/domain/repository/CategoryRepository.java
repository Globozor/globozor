package com.globozor.domain.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.globozor.domain.entity.Category;

public interface CategoryRepository extends JpaRepository<Category, Long>{

}
