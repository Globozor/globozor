package com.globozor.domain.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.globozor.domain.entity.Product;
import com.globozor.domain.entity.SubProduct;

public interface SubProductRepository extends JpaRepository<SubProduct, Long>{

	public List<SubProduct> findByProduct(Product product);

	public SubProduct findBySubProductName(String subProduct);
	@Query("select s.subProductName from SubProduct s")
	public List<String> findSubProductNames();
}
