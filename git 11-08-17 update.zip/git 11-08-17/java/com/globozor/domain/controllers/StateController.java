package com.globozor.domain.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.globozor.domain.entity.StateLookup;
import com.globozor.domain.services.StateService;

@RestController
@RequestMapping("/state")
public class StateController {

	@Autowired
	StateService stateService;
	
	@RequestMapping("/getStateByCountry")
	public List<StateLookup> getStateByCountry(@RequestParam long countryId){
		return stateService.getStateByCountry(countryId);
	}
}
