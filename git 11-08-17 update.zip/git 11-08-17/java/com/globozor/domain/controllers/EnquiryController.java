package com.globozor.domain.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.globozor.domain.entity.Enquiry;
import com.globozor.domain.services.EnquiryService;

@RestController
@RequestMapping("/enquiry")
public class EnquiryController {

	@Autowired
	EnquiryService enquiryService;
	
	@RequestMapping(value="/getEnquiry",method=RequestMethod.GET)
	public Enquiry getEnquiry(@RequestParam long enquiryId){
		return enquiryService.getEnquiry(enquiryId);
	}
}
