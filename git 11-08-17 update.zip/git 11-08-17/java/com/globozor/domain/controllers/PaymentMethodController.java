package com.globozor.domain.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.globozor.domain.entity.PaymentMethod;
import com.globozor.domain.services.PaymentMethodService;

@RestController
@RequestMapping("/payment")
public class PaymentMethodController {

	@Autowired
	PaymentMethodService paymentMethodService;
	
	@RequestMapping(value="/getPayments")
	public List<PaymentMethod> getPayments(){
		return paymentMethodService.getPayments();
	}
	
}
