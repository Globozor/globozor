package com.globozor.domain.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;


@Table
@Entity
public class SellerProductImage {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO, generator="sellerProductImageIdGenerator")
	@SequenceGenerator(name="sellerProductImageIdGenerator", sequenceName="seq_seller_product_image")
	private long sellerProductImageId;
	
	@ManyToOne
	@JsonIgnore
	@JoinColumn(name="seller_product_id")
	private SellerProduct sellerProduct;
	
	@Column(name="filepath")
	private String filePath;
	
	public SellerProductImage() {
		// TODO Auto-generated constructor stub
	}

	public SellerProductImage(long sellerProductImageId,
			SellerProduct sellerProduct, String filePath) {
		super();
		this.sellerProductImageId = sellerProductImageId;
		this.sellerProduct = sellerProduct;
		this.filePath = filePath;
	}

	public long getSellerProductImageId() {
		return sellerProductImageId;
	}

	public void setSellerProductImageId(long sellerProductImageId) {
		this.sellerProductImageId = sellerProductImageId;
	}

	public SellerProduct getSellerProduct() {
		return sellerProduct;
	}

	public void setSellerProduct(SellerProduct sellerProduct) {
		this.sellerProduct = sellerProduct;
	}

	public String getFilePath() {
		return filePath;
	}

	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}

	@Override
	public String toString() {
		return "SellerProductImage [sellerProductImageId="
				+ sellerProductImageId + ", filePath=" + filePath + "]";
	}
}
