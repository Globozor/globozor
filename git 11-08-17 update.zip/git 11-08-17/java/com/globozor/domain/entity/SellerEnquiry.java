package com.globozor.domain.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class SellerEnquiry {

	
	@Id
	private SellerEnquiryPk id;
	
	@Column
	private boolean isActive;

	public SellerEnquiryPk getId() {
		return id;
	}

	public void setId(SellerEnquiryPk id) {
		this.id = id;
	}

	public boolean isActive() {
		return isActive;
	}

	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}
}
