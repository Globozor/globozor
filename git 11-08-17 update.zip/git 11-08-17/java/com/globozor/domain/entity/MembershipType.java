package com.globozor.domain.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class MembershipType {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column
	private long membershipTypeId;
	
	@Column
	private String membershipTypeName;

	@Column
	private String membershipTypeDescription;

	public long getMembershipTypeId() {
		return membershipTypeId;
	}

	public void setMembershipTypeId(long membershipTypeId) {
		this.membershipTypeId = membershipTypeId;
	}

	public String getMembershipTypeName() {
		return membershipTypeName;
	}

	public void setMembershipTypeName(String membershipTypeName) {
		this.membershipTypeName = membershipTypeName;
	}

	public String getMembershipTypeDescription() {
		return membershipTypeDescription;
	}

	public void setMembershipTypeDescription(String membershipTypeDescription) {
		this.membershipTypeDescription = membershipTypeDescription;
	}
}
