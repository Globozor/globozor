package com.globozor.domain.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Table
@Entity
public class CompanyProfile {

	@Id
	private long companyProfileId;
}
