package com.globozor.domain.services;

import java.util.List;

import org.springframework.transaction.annotation.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.globozor.domain.entity.Product;
import com.globozor.domain.entity.SubProduct;
import com.globozor.domain.repository.SubProductRepository;

@Service
@Transactional
public class SubProductServiceImpl implements SubProductService{

	@Autowired
	SubProductRepository subProductRepository;

	@Override
	public List<SubProduct> getSubProductByProduct(Product product) {
		return subProductRepository.findByProduct(product);
	}
	
}
