package com.globozor.domain.services;

import java.util.List;

import org.springframework.transaction.annotation.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.globozor.domain.entity.Category;
import com.globozor.domain.entity.SubCategory;
import com.globozor.domain.repository.SubCategoryRepository;

@Service
@Transactional
public class SubCategoryServiceImpl implements SubCategoryService{

	@Autowired
	SubCategoryRepository subCategoryRepository;

	@Override
	public List<SubCategory> getSubCategoryByCategory(Category category) {
		return subCategoryRepository.findByCategory(category);
	}
	
}
