package com.globozor.domain.services;

import java.util.List;

import com.globozor.domain.entity.Category;
import com.globozor.domain.entity.Product;
import com.globozor.domain.entity.SubCategory;

public interface SubCategoryService {

	public List<SubCategory> getSubCategoryByCategory(Category category);
}
