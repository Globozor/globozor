package com.globozor.domain.services;

import java.util.List;

import com.globozor.domain.entity.CompanyProfile;
import com.globozor.domain.entity.Notification;
import com.globozor.domain.entity.SellerEnquiry;
import com.globozor.domain.entity.SellerEnquiryResponse;
import com.globozor.domain.entity.SellerProduct;
import com.globozor.domain.exceptions.SellerException;

public interface SellerService {

	public SellerEnquiryResponse responseEnquiry(
			SellerEnquiryResponse sellerEnquiryResponse);

	public List<Notification> getNotifications();

	public SellerProduct addSellerProduct(SellerProduct sellerProduct);

	public String removeSellerProduct(long sellerProductId) throws SellerException;

	public List<SellerProduct> getSellerProduct(String status);

	public List<SellerEnquiry> getSellerEnquiry();

	public List<SellerProduct> getSellerProductShowCase();

	public SellerProduct setSellerProductPriority(long sellerProductId, int priority);

	public SellerEnquiry rejectEnquiry(long enquiryId);

	public CompanyProfile saveCompanyProfile(CompanyProfile companyProfile);

}
