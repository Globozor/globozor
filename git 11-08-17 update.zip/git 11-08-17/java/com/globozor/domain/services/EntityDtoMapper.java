package com.globozor.domain.services;

import com.globozor.domain.dtos.MasterTableDto;
import com.globozor.domain.dtos.SellerDto;
import com.globozor.domain.dtos.SellerEnquiryDto;
import com.globozor.domain.dtos.SellerProductDto;
import com.globozor.domain.entity.MasterTable;
import com.globozor.domain.entity.SellerEnquiry;
import com.globozor.domain.entity.SellerProduct;

public interface EntityDtoMapper {

	public SellerDto sellerEntityToDto(MasterTable masterTable);
	public MasterTable masterTableDtoToEntity(MasterTableDto masterTableDto);
	public SellerProductDto sellerProductToDto(SellerProduct sellerProduct);
	public SellerEnquiryDto sellerEnquiryToDto(SellerEnquiry sellerEnquiry);
}
