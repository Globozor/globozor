package com.globozor.domain.services;

import java.util.List;

import com.globozor.domain.entity.DashboardLink;

public interface DashboardService {

	public List<DashboardLink> getLinks(String role);

}
