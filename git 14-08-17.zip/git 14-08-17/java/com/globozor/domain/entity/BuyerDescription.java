package com.globozor.domain.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table
public class BuyerDescription {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long buyerDescriptionId;
	
	@OneToOne
	@JoinColumn(name="masterTableId")
	@JsonIgnore
	private MasterTable buyer;
	
	@Column
	private String descriptionAboutCompany;
	
	@Column
	private int establishment;
	
	@Column
	private long maximumCapacity;
	
	@Column
	private String turnover;

	@Column
	private String port;
	
	@Column
	private long numberOfEmployees;

	public long getBuyerDescriptionId() {
		return buyerDescriptionId;
	}

	public void setBuyerDescriptionId(long buyerDescriptionId) {
		this.buyerDescriptionId = buyerDescriptionId;
	}

	public MasterTable getBuyer() {
		return buyer;
	}

	public void setBuyer(MasterTable buyer) {
		this.buyer = buyer;
	}

	public String getDescriptionAboutCompany() {
		return descriptionAboutCompany;
	}

	public void setDescriptionAboutCompany(String descriptionAboutCompany) {
		this.descriptionAboutCompany = descriptionAboutCompany;
	}

	public int getEstablishment() {
		return establishment;
	}

	public void setEstablishment(int establishment) {
		this.establishment = establishment;
	}

	public long getMaximumCapacity() {
		return maximumCapacity;
	}

	public void setMaximumCapacity(long maximumCapacity) {
		this.maximumCapacity = maximumCapacity;
	}

	public String getTurnover() {
		return turnover;
	}

	public void setTurnover(String turnover) {
		this.turnover = turnover;
	}

	public String getPort() {
		return port;
	}

	public void setPort(String port) {
		this.port = port;
	}

	public long getNumberOfEmployees() {
		return numberOfEmployees;
	}

	public void setNumberOfEmployees(long numberOfEmployees) {
		this.numberOfEmployees = numberOfEmployees;
	}
	
}
