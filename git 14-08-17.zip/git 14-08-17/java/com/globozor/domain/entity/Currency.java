package com.globozor.domain.entity;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Table
@Entity
public class Currency {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column
	private long currencyId;
	
	@Column
	private String currencyName;
	
	@Column
	private String currencyCountry;

	@ManyToMany(mappedBy="currencies")
	@JsonIgnore
	private Set<MasterTable> masterTables;
	
	public long getCurrencyId() {
		return currencyId;
	}

	public void setCurrencyId(long currencyId) {
		this.currencyId = currencyId;
	}

	public String getCurrencyName() {
		return currencyName;
	}

	public void setCurrencyName(String currencyName) {
		this.currencyName = currencyName;
	}

	public String getCurrencyCountry() {
		return currencyCountry;
	}

	public void setCurrencyCountry(String currencyCountry) {
		this.currencyCountry = currencyCountry;
	}

	public Set<MasterTable> getMasterTables() {
		return masterTables;
	}

	public void setMasterTables(Set<MasterTable> masterTables) {
		this.masterTables = masterTables;
	}

	@Override
	public String toString() {
		return "Currency [currencyId=" + currencyId + ", currencyName="
				+ currencyName + ", currencyCountry=" + currencyCountry + "]";
	}
}
