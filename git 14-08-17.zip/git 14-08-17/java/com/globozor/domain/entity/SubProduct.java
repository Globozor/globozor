package com.globozor.domain.entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Table(name="subproduct")
@Entity
public class SubProduct {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO, generator="subProductIdGenerator")
	@SequenceGenerator(name="subProductIdGenerator", sequenceName="seq_subproduct")
	@Column(name="subproductId")
	private long subProductId;
	
	@Column(name="subproductName")
	private String subProductName;
	
	@Column(name="subproductDescription")
	private String subProductDescription;
	
	@OneToMany(mappedBy="subProduct",cascade=CascadeType.ALL)
	private Set<SubProductImage> subProductImage;
	
	@ManyToMany(mappedBy="subProduct")
	@JsonIgnore
	private Set<Product> product;
	
	public SubProduct() {
		// TODO Auto-generated constructor stub
	}

	public SubProduct(long subProductId,
			String subProductName, String subProductDescription,
			Set<SubProductImage> subProductImage) {
		super();
		this.subProductId = subProductId;
		this.subProductName = subProductName;
		this.subProductDescription = subProductDescription;
		this.subProductImage = subProductImage;
	}

	public long getSubProductId() {
		return subProductId;
	}

	public void setSubProductId(long subProductId) {
		this.subProductId = subProductId;
	}

	public String getSubProductName() {
		return subProductName;
	}

	public void setSubProductName(String subProductName) {
		this.subProductName = subProductName;
	}

	public String getSubProductDescription() {
		return subProductDescription;
	}

	public void setSubProductDescription(String subProductDescription) {
		this.subProductDescription = subProductDescription;
	}

	public Set<SubProductImage> getSubProductImage() {
		return subProductImage;
	}

	public void setSubProductImage(Set<SubProductImage> subProductImage) {
		this.subProductImage = subProductImage;
	}

	public Set<Product> getProduct() {
		return product;
	}

	public void setProduct(Set<Product> product) {
		this.product = product;
	}
}
