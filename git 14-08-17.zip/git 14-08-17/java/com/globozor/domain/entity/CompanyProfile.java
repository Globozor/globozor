package com.globozor.domain.entity;

import java.util.Arrays;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

@Table
@Entity
@JsonIdentityInfo(
		  generator = ObjectIdGenerators.PropertyGenerator.class, 
		  property = "companyProfileId")
public class CompanyProfile {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column
	private long companyProfileId;
	
	@OneToOne
	@JoinColumn(name="masterTableId")
	@JsonManagedReference
	private MasterTable masterTable;
	
	@Column
	private String businessType;
	
	@Column
	private String exportPercentage;
	
	@Column(name="sourceIndustry")
	private String sourceAcrossMultipleIndustries;
	
	@Column
	private String averageLeadTime;
	
	@Column
	private String overseasOffice;
	
	@Column
	private String[] certificateFilePath;
	
	@OneToMany(mappedBy="companyProfile")
	@JsonManagedReference(value="company-tradeshow")
	private List<TradeShow> tradeShow;

	@OneToMany(mappedBy="companyProfile")
	@JsonManagedReference(value="company-customer")
	private List<CustomerDetail> customerDetails;
	
	public long getCompanyProfileId() {
		return companyProfileId;
	}

	public void setCompanyProfileId(long companyProfileId) {
		this.companyProfileId = companyProfileId;
	}

	public MasterTable getMasterTable() {
		return masterTable;
	}

	public void setMasterTable(MasterTable masterTable) {
		this.masterTable = masterTable;
	}

	public String getBusinessType() {
		return businessType;
	}

	public void setBusinessType(String businessType) {
		this.businessType = businessType;
	}

	public String getExportPercentage() {
		return exportPercentage;
	}

	public void setExportPercentage(String exportPercentage) {
		this.exportPercentage = exportPercentage;
	}

	public String getSourceAcrossMultipleIndustries() {
		return sourceAcrossMultipleIndustries;
	}

	public void setSourceAcrossMultipleIndustries(
			String sourceAcrossMultipleIndustries) {
		this.sourceAcrossMultipleIndustries = sourceAcrossMultipleIndustries;
	}

	public String getAverageLeadTime() {
		return averageLeadTime;
	}

	public void setAverageLeadTime(String averageLeadTime) {
		this.averageLeadTime = averageLeadTime;
	}

	public String getOverseasOffice() {
		return overseasOffice;
	}

	public void setOverseasOffice(String overseasOffice) {
		this.overseasOffice = overseasOffice;
	}

	public String[] getCertificateFilePath() {
		return certificateFilePath;
	}

	public void setCertificateFilePath(String[] certificateFilePath) {
		this.certificateFilePath = certificateFilePath;
	}

	public List<TradeShow> getTradeShow() {
		return tradeShow;
	}

	public void setTradeShow(List<TradeShow> tradeShow) {
		this.tradeShow = tradeShow;
	}

	public List<CustomerDetail> getCustomerDetails() {
		return customerDetails;
	}

	public void setCustomerDetails(List<CustomerDetail> customerDetails) {
		this.customerDetails = customerDetails;
	}

	@Override
	public String toString() {
		return "CompanyProfile [companyProfileId=" + companyProfileId
				+ ", businessType=" + businessType + ", exportPercentage="
				+ exportPercentage + ", sourceAcrossMultipleIndustries="
				+ sourceAcrossMultipleIndustries + ", averageLeadTime="
				+ averageLeadTime + ", overseasOffice=" + overseasOffice
				+ ", certificateFilePath="
				+ Arrays.toString(certificateFilePath) + ", tradeShow="
				+ tradeShow + ", customerDetails=" + customerDetails + "]";
	}
}
