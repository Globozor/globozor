package com.globozor.domain.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

@Entity
@Table
@JsonIdentityInfo(
		generator= ObjectIdGenerators.PropertyGenerator.class,
		property="buyerEnquiryResponseId")
public class BuyerEnquiryResponse {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column
	private long buyerEnquiryResponseId;
	
	@OneToOne
	@JoinColumn(name="enquiryId")
	@JsonManagedReference
	private Enquiry enquiry;
	
	@OneToOne
	@JoinColumn(name="sellerEnquiryResponseId")
	@JsonManagedReference
	private SellerEnquiryResponse sellerEnquiryResponse;
	
	@Column
	private long quantity;
	
	@Column
	private String unit;
	
	@Column
	private String enquiryDescription;
	
	@Column
	private String status;
	
	@Column
	private String unitPrice;

	public long getBuyerEnquiryResponseId() {
		return buyerEnquiryResponseId;
	}

	public void setBuyerEnquiryResponseId(long buyerEnquiryResponseId) {
		this.buyerEnquiryResponseId = buyerEnquiryResponseId;
	}

	public Enquiry getEnquiry() {
		return enquiry;
	}

	public void setEnquiry(Enquiry enquiry) {
		this.enquiry = enquiry;
	}

	public SellerEnquiryResponse getSellerEnquiryResponse() {
		return sellerEnquiryResponse;
	}

	public void setSellerEnquiryResponse(SellerEnquiryResponse sellerEnquiryResponse) {
		this.sellerEnquiryResponse = sellerEnquiryResponse;
	}

	public long getQuantity() {
		return quantity;
	}

	public void setQuantity(long quantity) {
		this.quantity = quantity;
	}

	public String getUnit() {
		return unit;
	}

	public void setUnit(String unit) {
		this.unit = unit;
	}

	public String getEnquiryDescription() {
		return enquiryDescription;
	}

	public void setEnquiryDescription(String enquiryDescription) {
		this.enquiryDescription = enquiryDescription;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(String unitPrice) {
		this.unitPrice = unitPrice;
	}
	
}
