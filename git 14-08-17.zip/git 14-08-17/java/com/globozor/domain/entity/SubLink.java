package com.globozor.domain.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Table(name="sublink")
@Entity
public class SubLink {

	@Id
	private long sublinkId;
	
	@Column(name="sublinkName")
	private String subLink;
	
	@ManyToOne
	@JsonIgnore
	@JoinColumn(name="dashboardLinkId")
	private DashboardLink dashboardLink;

	public long getSublinkId() {
		return sublinkId;
	}

	public void setSublinkId(long sublinkId) {
		this.sublinkId = sublinkId;
	}

	public String getSubLink() {
		return subLink;
	}

	public void setSubLink(String subLink) {
		this.subLink = subLink;
	}

	public DashboardLink getDashboardLink() {
		return dashboardLink;
	}

	public void setDashboardLink(DashboardLink dashboardLink) {
		this.dashboardLink = dashboardLink;
	}
	
}
