package com.globozor.domain.entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


@Table
@Entity
public class Category {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column
	private long categoryId;
	
	@Column
	private String categoryName;
	
	@ManyToMany(cascade=CascadeType.ALL)
	@JoinTable(name="category_subcategory",joinColumns=@JoinColumn(name="categoryId",referencedColumnName="categoryId"),inverseJoinColumns=@JoinColumn(name="subcategoryId",referencedColumnName="subcategoryId"))
	private Set<SubCategory> subCategory;
	
	public Category() {

	}

	public Category(long categoryId, String categoryName,
			Set<SubCategory> subCategory) {
		super();
		this.categoryId = categoryId;
		this.categoryName = categoryName;
		this.subCategory = subCategory;
	}

	public long getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(long categoryId) {
		this.categoryId = categoryId;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	public Set<SubCategory> getSubCategory() {
		return subCategory;
	}

	public void setSubCategory(Set<SubCategory> subCategory) {
		this.subCategory = subCategory;
	}
}
