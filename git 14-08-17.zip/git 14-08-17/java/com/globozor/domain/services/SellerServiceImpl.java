package com.globozor.domain.services;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;

import org.json.simple.JSONArray;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.globozor.domain.dtos.CompanyProfileDto;
import com.globozor.domain.entity.BuyerRating;
import com.globozor.domain.entity.CompanyProfile;
import com.globozor.domain.entity.CustomerDetail;
import com.globozor.domain.entity.Dispute;
import com.globozor.domain.entity.Feedback;
import com.globozor.domain.entity.MasterTable;
import com.globozor.domain.entity.Notification;
import com.globozor.domain.entity.SampleRequest;
import com.globozor.domain.entity.SellerDescription;
import com.globozor.domain.entity.SellerEnquiry;
import com.globozor.domain.entity.SellerEnquiryResponse;
import com.globozor.domain.entity.SellerProduct;
import com.globozor.domain.entity.SellerRating;
import com.globozor.domain.entity.TradeShow;
import com.globozor.domain.entity.Transaction;
import com.globozor.domain.exceptions.SellerException;
import com.globozor.domain.repository.BuyerRatingRepository;
import com.globozor.domain.repository.CompanyProfileRespository;
import com.globozor.domain.repository.CustomerDetailRepository;
import com.globozor.domain.repository.DisputeRepository;
import com.globozor.domain.repository.NotificationRepository;
import com.globozor.domain.repository.SampleRequestRepository;
import com.globozor.domain.repository.SellerDescriptionRepository;
import com.globozor.domain.repository.SellerEnquiryRepository;
import com.globozor.domain.repository.SellerEnquiryResponseRepository;
import com.globozor.domain.repository.SellerProductRepository;
import com.globozor.domain.repository.SellerRatingRepository;
import com.globozor.domain.repository.TradeShowRepository;
import com.globozor.domain.repository.TransactionRepository;

@Service
public class SellerServiceImpl implements SellerService{

	@Autowired
	SellerEnquiryResponseRepository sellerEnquiryResponseRepository;
	
	@Autowired
	NotificationRepository notificationRepository;
	
	@Autowired
	SellerProductRepository sellerProductRepository;
	
	@Autowired
	SellerEnquiryRepository sellerEnquiryRepository;
	
	@Autowired
	SellerDescriptionRepository sellerDescriptionRepository;
	
	@Autowired
	CompanyProfileRespository companyProfileRespository;
	
	@Autowired
	TradeShowRepository tradeShowRepository;
	
	@Autowired
	CustomerDetailRepository customerDetailRepository;
	
	@Autowired
	DisputeRepository disputeRepository;
	
	/*@Autowired
	FeedbackRepository feedbackRepository;*/
	
	@Autowired
	BuyerRatingRepository buyerRatingRepository;
	
	@Autowired
	SellerRatingRepository sellerRatingRepository;
	
	@Autowired
	TransactionRepository transactionRepository;
	
	@Autowired
	SampleRequestRepository sampleRequestRepository;
	
	public SellerEnquiryResponse responseEnquiry(
			SellerEnquiryResponse sellerEnquiryResponse) {
		sellerEnquiryResponse = sellerEnquiryResponseRepository.save(sellerEnquiryResponse);
		Set<Notification> notifications = sellerEnquiryResponse.getEnquiry().getBuyer().getNotifications();
		Notification notification = new Notification();
		notification.setMasterTable(sellerEnquiryResponse.getEnquiry().getBuyer());
		notification.setNotificationDesc("New response for your enquiry with id "+sellerEnquiryResponse.getEnquiry().getEnquiryId()+" from "+sellerEnquiryResponse.getSeller().getUserName());
		notification.setNotificationType("RFQ response");
		notification.setActive(true);
		notification.setCreatedTime(new Date());
		notification = notificationRepository.save(notification);
		notifications.add(notification);
		sellerEnquiryResponse.getEnquiry().getBuyer().setNotifications(notifications);
		return sellerEnquiryResponse;
	}

	public List<Notification> getNotifications() {
		return notificationRepository.findAllNotifications();
	}

	public SellerProduct addSellerProduct(SellerProduct sellerProduct) {
		sellerProduct.setStatus("pending_approval");
		return sellerProductRepository.save(sellerProduct);
	}

	@Override
	public String removeSellerProduct(long sellerProductId) throws SellerException{
		SellerProduct sellerProduct = sellerProductRepository.findBySellerProductId(sellerProductId);
		sellerProduct.setActive(false);
		String message = "";
		try {
			sellerProductRepository.save(sellerProduct);
			message = "Product successfully removed";
		} catch (Exception e) {
			message = "Unable to delete object";
			throw new SellerException("Unable to delete product");
		}
		return message;
	}

	@Override
	public List<SellerProduct> getSellerProduct(MasterTable masterTable , String status) {
		return sellerProductRepository.findByStatus(status , masterTable.getMasterTableId());
	}

	@Override
	public List<SellerEnquiry> getSellerEnquiry(MasterTable masterTable) {
		return sellerEnquiryRepository.findByIsActive(true,masterTable.getMasterTableId());
	}

	@Override
	public List<SellerProduct> getSellerProductShowCase(MasterTable masterTable) {
		int priority=0;
		int membershipTypeId=0;
		if(membershipTypeId==1){
			priority = 40;
		}else if(membershipTypeId==2){
			priority = 25;
		}else if(membershipTypeId==3){
			priority=15;
		}else{
			priority=1;
		}
		return sellerProductRepository.getSellerProductShowCase(priority,masterTable.getMasterTableId());
	}

	@Override
	public SellerProduct setSellerProductPriority(long sellerProductId,
			int priority , MasterTable masterTable) {
		SellerProduct sellerProduct = sellerProductRepository.findOne(sellerProductId);
		if(sellerProduct.getMasterTable().getMasterTableId()==masterTable.getMasterTableId()){
			sellerProduct.setPriority(priority);
			sellerProduct = sellerProductRepository.save(sellerProduct);
		}
		return sellerProduct;
	}

	@Override
	public SellerEnquiry rejectEnquiry(long enquiryId) {
		SellerEnquiry sellerEnquiry = sellerEnquiryRepository.findByEnquiry(enquiryId);
		sellerEnquiry.setActive(false);
		sellerEnquiry = sellerEnquiryRepository.save(sellerEnquiry); 
		return sellerEnquiry;
	}

	@Override
	public SellerDescription getSellerDescription(MasterTable masterTable) {
		SellerDescription sellerDescription = sellerDescriptionRepository.findBySellerId(masterTable.getMasterTableId());
		return sellerDescription;
	}

	@Override
	public TradeShow saveTradeShow(TradeShow tradeShow) {
		tradeShow = tradeShowRepository.save(tradeShow);
		return tradeShow;
	}

	@Override
	public CustomerDetail saveCustomerDetail(CustomerDetail customerDetail) {
		customerDetail = customerDetailRepository.save(customerDetail);
		return customerDetail;
	}

	/*@Override
	public CompanyProfileDto saveCompanyProfile(JSONArray companyProfileDto) {
		CompanyProfile companyProfile = (CompanyProfile) companyProfileDto.get(0);
		companyProfile = companyProfileRespository.save(companyProfile);
		System.out.println("com is "+companyProfile);
		if(companyProfileDto.get(1)!=null){
			TradeShow tradeShow = (TradeShow) companyProfileDto.get(1);
			tradeShow.setCompanyProfile(companyProfile);
			tradeShow = saveTradeShow(tradeShow);
			System.out.println("trade show is "+tradeShow);
		}
		if(companyProfileDto.get(2)!=null){
			CustomerDetail customerDetail = (CustomerDetail) companyProfileDto.get(2);
			customerDetail.setCompanyProfile(companyProfile);
			customerDetail=saveCustomerDetail(customerDetail);
			System.out.println("customer is "+customerDetail);
		}
		return new CompanyProfileDto();
		
		CompanyProfile companyProfile = companyProfileDto.getCompanyProfile();
		CompanyProfileDto profileDto = new CompanyProfileDto();
		companyProfile = companyProfileRespository.save(companyProfile);
		profileDto.setCompanyProfile(companyProfile);
		if(companyProfileDto.getTradeShow()!=null){
			TradeShow tradeShow = companyProfileDto.getTradeShow();
			tradeShow.setCompanyProfile(companyProfile);
			tradeShow = saveTradeShow(tradeShow);
			profileDto.setTradeShow(tradeShow);
		}
		if(companyProfileDto.getCustomerDetail()!=null){
			CustomerDetail customerDetail = companyProfileDto.getCustomerDetail();
			customerDetail.setCompanyProfile(companyProfile);
			customerDetail=saveCustomerDetail(customerDetail);
			profileDto.setCustomerDetail(customerDetail);
		}
		return profileDto;
	}*/

	@Override
	public Dispute createDispute(Dispute dispute) {
		return disputeRepository.save(dispute);
	}

	@Override
	public List<Dispute> getAllDisputes(MasterTable masterTable) {
		return disputeRepository.findAllSellerById(masterTable.getMasterTableId());
	}

	/*
	@Override
	public Feedback createFeedback(Feedback feedback) {
		return feedbackRepository.save(feedback);
	}

	@Override
	public List<Feedback> getAllFeedbacks(MasterTable masterTable) {
		return feedbackRepository.findAllById();
	}
*/
	@Override
	public BuyerRating rateBuyer(BuyerRating buyerRating) {
		return buyerRatingRepository.save(buyerRating);
	}

	@Override
	public List<SellerRating> getAllSellerRating(MasterTable masterTable) {
		return sellerRatingRepository.findAllById(masterTable.getMasterTableId());
	}

	@Override
	public List<Transaction> getAllSellerOrders(MasterTable masterTable) {
		return transactionRepository.getAllSellerOrder(masterTable.getMasterTableId());
	}

	@Override
	public List<SampleRequest> getAllSampleRequest(MasterTable masterTable,
			String status) {
		return sampleRequestRepository.findSampleByStatusSeller(masterTable.getMasterTableId(),status);
	}

	@Override
	public CompanyProfile saveCompanyProfile(CompanyProfile companyProfile) {
		CompanyProfile companyProfile2 = 
				companyProfileRespository.findUnique	(companyProfile.getMasterTable().getMasterTableId());
		if(companyProfile2 == null){
			List<TradeShow> tradeShows = companyProfile.getTradeShow();
			List<CustomerDetail> customerDetails = companyProfile.getCustomerDetails();
			List<TradeShow> tradeShows2 = new ArrayList<TradeShow>();
			List<CustomerDetail> customerDetails2 = new ArrayList<CustomerDetail>();
			companyProfile.setTradeShow(null);
			companyProfile.setCustomerDetails(null);
			companyProfile = companyProfileRespository.save(companyProfile);
			for (TradeShow tradeShow : tradeShows) {
				tradeShow.setCompanyProfile(companyProfile);
				tradeShow = tradeShowRepository.save(tradeShow);
				tradeShows2.add(tradeShow);
			}
			for (CustomerDetail customerDetail : customerDetails) {
				customerDetail.setCompanyProfile(companyProfile);
				customerDetail = customerDetailRepository.save(customerDetail);
				customerDetails2.add(customerDetail);
			}
			companyProfile.setTradeShow(tradeShows2);
			companyProfile.setCustomerDetails(customerDetails2);
			return companyProfile;
		}else{
			companyProfile.setCompanyProfileId(companyProfile2.getCompanyProfileId());
			return companyProfileRespository.save(companyProfile);
		}
	}

}
