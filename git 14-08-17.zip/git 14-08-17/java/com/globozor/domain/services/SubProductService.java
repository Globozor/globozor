package com.globozor.domain.services;

import java.util.List;

import com.globozor.domain.entity.Category;
import com.globozor.domain.entity.Product;
import com.globozor.domain.entity.SubCategory;
import com.globozor.domain.entity.SubProduct;

public interface SubProductService {

	public List<SubProduct> getSubProductByProduct(Product product);
}
