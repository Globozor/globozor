package com.globozor.domain.services;

import java.util.List;

import com.globozor.domain.entity.Category;

public interface CategoryService {

	public List<Category> getCategory();
}
