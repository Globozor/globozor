package com.globozor.domain.services;

import java.util.List;

import com.globozor.domain.entity.Product;
import com.globozor.domain.entity.SubCategory;

public interface ProductService {

	public List<Product> getProductBySubCategory(SubCategory subCategory);
}
