package com.globozor.domain.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.globozor.domain.entity.BuyerRating;
import com.globozor.domain.entity.CompanyProfile;
import com.globozor.domain.entity.CustomerDetail;
import com.globozor.domain.entity.Dispute;
import com.globozor.domain.entity.Enquiry;
import com.globozor.domain.entity.Favourite;
import com.globozor.domain.entity.MasterTable;
import com.globozor.domain.entity.SampleRequest;
import com.globozor.domain.entity.SellerEnquiryResponse;
import com.globozor.domain.entity.SellerProduct;
import com.globozor.domain.entity.SellerRating;
import com.globozor.domain.entity.TradeShow;
import com.globozor.domain.entity.Transaction;
import com.globozor.domain.repository.BuyerRatingRepository;
import com.globozor.domain.repository.CompanyProfileRespository;
import com.globozor.domain.repository.CustomerDetailRepository;
import com.globozor.domain.repository.DisputeRepository;
import com.globozor.domain.repository.EnquiryRepository;
import com.globozor.domain.repository.SampleRequestRepository;
import com.globozor.domain.repository.SellerEnquiryResponseRepository;
import com.globozor.domain.repository.SellerRatingRepository;
import com.globozor.domain.repository.TradeShowRepository;
import com.globozor.domain.repository.TransactionRepository;

@Service
@Transactional
public class BuyerServiceImpl implements BuyerService {

	@Autowired
	TransactionRepository transactionRepository;
	
	@Autowired
	SellerRatingRepository sellerRatingRepository;
	
	@Autowired
	BuyerRatingRepository buyerRatingRepository;
	
	@Autowired
	DisputeRepository disputeRepository;
	
	@Autowired
	SampleRequestRepository sampleRequestRepository;
	
	@Autowired
	EnquiryRepository enquiryRepository;
	
	@Autowired
	SellerEnquiryResponseRepository sellerEnquiryResponseRepository;
	
	@Autowired
	CompanyProfileRespository companyProfileRespository;
	
	@Autowired
	TradeShowRepository tradeShowRepository;
	
	@Autowired
	CustomerDetailRepository customerDetailRepository;
	
	@Autowired
	FavouriteRepository favouriteRepository;
	
	@Override
	public List<Transaction> getAllOrders(MasterTable masterTable) {
		return transactionRepository.getAllBuyerOrder(masterTable.getMasterTableId());
	}

	@Override
	public SellerRating rateSeller(SellerRating sellerRating) {
		return sellerRatingRepository.save(sellerRating);
	}

	@Override
	public List<BuyerRating> getAllBuyerRating(MasterTable masterTable) {
		return buyerRatingRepository.findAllById(masterTable.getMasterTableId());
	}

	@Override
	public Dispute createDispute(Dispute dispute) {
		return disputeRepository.save(dispute);
	}

	@Override
	public List<Dispute> getAllDisputes(MasterTable masterTable) {
		return disputeRepository.findAllBuyerById(masterTable.getMasterTableId());
	}

	@Override
	public List<SampleRequest> getAllSampleRequest(MasterTable masterTable,
			String status) {
		return sampleRequestRepository.findSampleByStatusBuyer(masterTable.getMasterTableId(),status);
	}

	@Override
	public List<Enquiry> getBuyerAllEnquiries(MasterTable masterTable) {
		return enquiryRepository.findAllByBuyerId(masterTable.getMasterTableId());
	}

	@Override
	public List<SellerEnquiryResponse> getSellerEnquiryResponse(String type,
			MasterTable masterTable) {
		if(type.equals("all")){
			return sellerEnquiryResponseRepository.findAllResponse(masterTable.getMasterTableId());
		}else if(type.equals("negotiated")){
			return sellerEnquiryResponseRepository.findAllResponseWithStatus(type,masterTable.getMasterTableId());
		}else{
			return null;
		}
	}

	@Override
	public CompanyProfile saveCompanyProfile(CompanyProfile companyProfile) {
		CompanyProfile companyProfile2 = 
				companyProfileRespository.findUnique	(companyProfile.getMasterTable().getMasterTableId());
		if(companyProfile2 == null){
			List<TradeShow> tradeShows = companyProfile.getTradeShow();
			List<CustomerDetail> customerDetails = companyProfile.getCustomerDetails();
			List<TradeShow> tradeShows2 = new ArrayList<TradeShow>();
			List<CustomerDetail> customerDetails2 = new ArrayList<CustomerDetail>();
			companyProfile.setTradeShow(null);
			companyProfile.setCustomerDetails(null);
			companyProfile = companyProfileRespository.save(companyProfile);
			for (TradeShow tradeShow : tradeShows) {
				tradeShow.setCompanyProfile(companyProfile);
				tradeShow = tradeShowRepository.save(tradeShow);
				tradeShows2.add(tradeShow);
			}
			for (CustomerDetail customerDetail : customerDetails) {
				customerDetail.setCompanyProfile(companyProfile);
				customerDetail = customerDetailRepository.save(customerDetail);
				customerDetails2.add(customerDetail);
			}
			companyProfile.setTradeShow(tradeShows2);
			companyProfile.setCustomerDetails(customerDetails2);
			return companyProfile;
		}else{
			companyProfile.setCompanyProfileId(companyProfile2.getCompanyProfileId());
			return companyProfileRespository.save(companyProfile);
		}
	}

	@Override
	public Favourite addFavourite(MasterTable masterTable, long id) {
		Favourite favourite = new Favourite();
		SellerProduct sellerProduct = new SellerProduct();
		sellerProduct.setSellerProductId(id);
		favourite.setSellerProduct(sellerProduct);
		favourite.setBuyer(masterTable);
		return favouriteRepository.save(favourite);
	}

	@Override
	public List<Favourite> getAllFavourites(MasterTable masterTable) {
		return favouriteRepository.getAllFavourites(masterTable.getMasterTableId());
	}

}
