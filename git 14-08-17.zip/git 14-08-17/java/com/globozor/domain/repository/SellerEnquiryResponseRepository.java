package com.globozor.domain.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.globozor.domain.entity.SellerEnquiryResponse;

public interface SellerEnquiryResponseRepository extends JpaRepository<SellerEnquiryResponse, Long>{

	@Query("select s from SellerEnquiryResponse s where s.buyer.masterTableId=?1")
	public List<SellerEnquiryResponse> findAllResponse(long masterTableId);
	
	@Query("select s from SellerEnquiryResponse s where s.status=?1 and s.buyer.masterTableId=?2")
	public List<SellerEnquiryResponse> findAllResponseWithStatus(String type,
			long masterTableId);

}
