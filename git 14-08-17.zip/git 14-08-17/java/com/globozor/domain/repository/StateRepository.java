package com.globozor.domain.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.globozor.domain.entity.StateLookup;

public interface StateRepository extends JpaRepository<StateLookup, Long>{

	@Query("select s from StateLookup s where s.countryLookup.countryLookupId=?1")
	public List<StateLookup> findStateByCountry(long countryLookupId);

}