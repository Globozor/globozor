package com.globozor.domain.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.globozor.domain.entity.Transaction;

public interface TransactionRepository extends JpaRepository<Transaction, Long>{

	@Query("select t from Transaction t where t.seller.masterTableId=?1")
	public List<Transaction> getAllSellerOrder(long masterTableId);
	@Query("select t from Transaction t where t.buyer.masterTableId=?1")
	public List<Transaction> getAllBuyerOrder(long masterTableId);

}
