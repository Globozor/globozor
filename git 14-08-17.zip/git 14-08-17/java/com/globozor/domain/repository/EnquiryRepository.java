package com.globozor.domain.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.globozor.domain.entity.Enquiry;

public interface EnquiryRepository extends JpaRepository<Enquiry, Long>{

	@Query("select e from Enquiry e where e.buyer.masterTableId=?1")
	public List<Enquiry> findAllByBuyerId(long masterTableId);

}
