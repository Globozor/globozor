package com.globozor.domain.controllers;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.globozor.domain.dtos.MasterTableDto;
import com.globozor.domain.dtos.ResponseDto;
import com.globozor.domain.dtos.SellerDto;
import com.globozor.domain.dtos.SellerEnquiryDto;
import com.globozor.domain.dtos.SellerProductDto;
import com.globozor.domain.entity.BuyerEnquiryResponse;
import com.globozor.domain.entity.BuyerRating;
import com.globozor.domain.entity.CompanyProfile;
import com.globozor.domain.entity.CustomerDetail;
import com.globozor.domain.entity.Dispute;
import com.globozor.domain.entity.MasterTable;
import com.globozor.domain.entity.Notification;
import com.globozor.domain.entity.SampleRequest;
import com.globozor.domain.entity.SellerDescription;
import com.globozor.domain.entity.SellerEnquiry;
import com.globozor.domain.entity.SellerEnquiryResponse;
import com.globozor.domain.entity.SellerProduct;
import com.globozor.domain.entity.SellerRating;
import com.globozor.domain.entity.TradeShow;
import com.globozor.domain.entity.Transaction;
import com.globozor.domain.exceptions.SellerException;
import com.globozor.domain.services.EmailSender;
import com.globozor.domain.services.EntityDtoMapper;
import com.globozor.domain.services.SellerService;
import com.globozor.domain.services.UserService;

@RestController
@RequestMapping("/seller")
public class SellerController {

	@Autowired
	SellerService sellerService;
	
	@Autowired
	EntityDtoMapper mapper;
	
	@Autowired
	EmailSender emailSender;
	
	@Autowired
	UserService userService;
	
	@RequestMapping(value="/getSellerDescription")
	public ResponseDto getSellerDescription(HttpServletRequest request){
		HttpSession session = request.getSession(false);
		ResponseDto responseDto = new ResponseDto();
		if(session!=null){
			Object object = session.getAttribute("mastertable");
			MasterTable masterTable = (MasterTable) object;
			List<Object> objects = new ArrayList<Object>();
			SellerDescription sellerDescription = sellerService.getSellerDescription(masterTable);
			objects.add(sellerDescription);
			responseDto = new ResponseDto(objects);
		}else{
			responseDto = new ResponseDto("Session has expired");
		}
		return responseDto;
	}
	
	@RequestMapping(value="/saveTradeShow")
	public ResponseDto saveTradeShow(@RequestBody TradeShow tradeShow){
		ResponseDto responseDto = new ResponseDto();
		tradeShow = sellerService.saveTradeShow(tradeShow);
		List<Object> objects = new ArrayList<Object>();
		objects.add(tradeShow);
		responseDto = new ResponseDto(objects);
		return responseDto;
	}
	
	@RequestMapping(value="/saveCustomerDetail")
	public ResponseDto saveCustomerDetail(@RequestBody CustomerDetail customerDetail){
		ResponseDto responseDto = new ResponseDto();
		customerDetail = sellerService.saveCustomerDetail(customerDetail);
		List<Object> objects = new ArrayList<Object>();
		objects.add(customerDetail);
		responseDto = new ResponseDto(objects);
		return responseDto;
	}
	
	@RequestMapping(value="/responseEnquiry",method=RequestMethod.POST)
	public SellerEnquiryResponse responseEnquiry(@RequestBody SellerEnquiryResponse sellerEnquiryResponse){
		return sellerService.responseEnquiry(sellerEnquiryResponse);
	}
	
	@RequestMapping(value="/getNotifications",method=RequestMethod.GET)
	public List<Notification> getNotifications() {
		return sellerService.getNotifications();
	}
	
	@RequestMapping(value = "/addSellerProduct",method=RequestMethod.POST)
	public SellerProduct addSellerProduct(@RequestBody SellerProduct sellerProduct){
		return sellerService.addSellerProduct(sellerProduct);
	}
	
	@RequestMapping(value="/removeSellerProduct")
	public ResponseDto removeSellerProduct(@RequestParam long sellerProductId){
		String message = "";
		try {
			message = sellerService.removeSellerProduct(sellerProductId);
		} catch (SellerException e) {
			return new ResponseDto(e.getMessage());
		}
		return new ResponseDto(message);
	}
	
	@RequestMapping("/getAllSellerProduct")
	public List<SellerProductDto> getSellerProduct(@RequestParam String status , HttpServletRequest request){
		List<SellerProductDto> sellerProductDtos = new ArrayList<SellerProductDto>();
		HttpSession session = request.getSession(false);
		ResponseDto responseDto = new ResponseDto();
		if(session!=null){
			Object object = session.getAttribute("mastertable");
			MasterTable masterTable = (MasterTable) object;
			List<SellerProduct> sellerProducts = sellerService.getSellerProduct(masterTable,status);
			for (SellerProduct sellerProduct : sellerProducts) {
				SellerProductDto sellerProductDto = mapper.sellerProductToDto(sellerProduct);
				sellerProductDtos.add(sellerProductDto);
			}
		}
		return sellerProductDtos;
	}
	
	@RequestMapping("/getSellerEnquiry")
	public List<SellerEnquiryDto> getSellerEnquiry(HttpServletRequest request){
		List<SellerEnquiryDto> sellerEnquiryDtos = new ArrayList<SellerEnquiryDto>();
		HttpSession session = request.getSession(false);
		ResponseDto responseDto = new ResponseDto();
		if(session!=null){
			Object object = session.getAttribute("mastertable");
			MasterTable masterTable = (MasterTable) object;
			List<SellerEnquiry> sellerEnquiries =  sellerService.getSellerEnquiry(masterTable);
			for (SellerEnquiry sellerEnquiry : sellerEnquiries) {
				SellerEnquiryDto sellerEnquiryDto = mapper.sellerEnquiryToDto(sellerEnquiry);
				sellerEnquiryDtos.add(sellerEnquiryDto);
			}
		}
		return sellerEnquiryDtos;
	}
	
	@RequestMapping("/rejectEnquiry")
	public String rejectEnquiry(@RequestParam long enquiryId){
		SellerEnquiry sellerEnquiry = sellerService.rejectEnquiry(enquiryId);
		String status = null;
		if(sellerEnquiry != null){
			status = "removed";
		}
		return status;
	}
	
	@RequestMapping("/getSellerProductShowCase")
	public List<SellerProductDto> getSellerProductShowCase(HttpServletRequest request){
		HttpSession session = request.getSession(false);
		List<SellerProductDto> sellerProductDtos = new ArrayList<SellerProductDto>();
		ResponseDto responseDto = new ResponseDto();
		if(session!=null){
			Object object = session.getAttribute("mastertable");
			MasterTable masterTable = (MasterTable) object;
			List<SellerProduct> sellerProducts = sellerService.getSellerProductShowCase(masterTable);
			for (SellerProduct sellerProduct : sellerProducts) {
				SellerProductDto sellerProductDto = mapper.sellerProductToDto(sellerProduct);
				sellerProductDtos.add(sellerProductDto);
			}
		}
		return sellerProductDtos;
	}
	
	@RequestMapping("/setSellerProductPriority")
	public SellerProductDto setSellerProductPriority(@RequestParam long sellerProductId , @RequestParam int priority , HttpServletRequest request){
		HttpSession session = request.getSession(false);
		ResponseDto responseDto = new ResponseDto();
		if(session!=null){
			Object object = session.getAttribute("mastertable");
			MasterTable masterTable = (MasterTable) object;
			SellerProduct sellerProduct = sellerService.setSellerProductPriority(sellerProductId,priority,masterTable);
			SellerProductDto sellerProductDto = mapper.sellerProductToDto(sellerProduct);
			return sellerProductDto;
		}
		return null;
	}
	
	/*@RequestBody("/getModifiedEnquiry")
	public */
	/*@RequestMapping("/saveCompanyProfile")
	public CompanyProfileDto saveCompanyProfile(@RequestBody String jsonArray){
		ObjectMapper mapper = new ObjectMapper();
		System.out.println("string is "+jsonArray);
		JsonNode node;
		try {
			node = mapper.readTree(jsonArray);
			System.out.println("node is "+node);
			CompanyProfile companyProfile = mapper.convertValue(node.get(0), CompanyProfile.class);
			System.out.println("company is "+companyProfile);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
		//return sellerService.saveCompanyProfile(jsonArray);
	}*/
	
	@RequestMapping("/saveCompanyProfile")
	public CompanyProfile saveCompanyProfile(@RequestBody CompanyProfile companyProfile , HttpServletRequest request){
		HttpSession session = request.getSession(false);
		ResponseDto responseDto = new ResponseDto();
		if(session!=null){
			Object object = session.getAttribute("mastertable");
			MasterTable masterTable = (MasterTable) object;
			companyProfile.setMasterTable(masterTable);
			return sellerService.saveCompanyProfile(companyProfile);
		}
		return null;
	}
	
	@RequestMapping("/getBuyerResponse")
	public BuyerEnquiryResponse getBuyerEnquiryResponse(){
		//return sellerService.getBuyerEnquiryResponse();
		return null;
	}
	
	@RequestMapping("/createDispute")
	public Dispute createDispute(@RequestBody Dispute dispute){
		return sellerService.createDispute(dispute);
	}
	
	@RequestMapping("/getSellerAllDisputes")
	public List<Dispute> getAllDisputes(HttpServletRequest request){
		HttpSession session = request.getSession(false);
		ResponseDto responseDto = new ResponseDto();
		if(session!=null){
			Object object = session.getAttribute("mastertable");
			MasterTable masterTable = (MasterTable) object;
			return sellerService.getAllDisputes(masterTable);
		}
		return null;
	}

	@RequestMapping("/rateBuyer")
	public BuyerRating rateBuyer(@RequestBody BuyerRating buyerRating){
		return sellerService.rateBuyer(buyerRating);
	}
	
	@RequestMapping("/getSellerAllRatings")
	public List<SellerRating> getAllSellerRating(HttpServletRequest request){
		HttpSession session = request.getSession(false);
		ResponseDto responseDto = new ResponseDto();
		if(session!=null){
			Object object = session.getAttribute("mastertable");
			MasterTable masterTable = (MasterTable) object;
			return sellerService.getAllSellerRating(masterTable);
		}
		return null;
	}
	
	@RequestMapping(value="getSellerAllOrders")
	public List<Transaction> getAllSellerOrders(HttpServletRequest request){
		HttpSession session = request.getSession(false);
		ResponseDto responseDto = new ResponseDto();
		if(session!=null){
			Object object = session.getAttribute("mastertable");
			MasterTable masterTable = (MasterTable) object;
			return sellerService.getAllSellerOrders(masterTable);
		}
		return null;
	}
	
	@RequestMapping(value="/getSellerAllSampleRequests")
	public List<SampleRequest> getSellerAllSampleRequests(@RequestParam String status , HttpServletRequest request){
		HttpSession session = request.getSession(false);
		ResponseDto responseDto = new ResponseDto();
		if(session!=null){
			Object object = session.getAttribute("mastertable");
			MasterTable masterTable = (MasterTable) object;
			return sellerService.getAllSampleRequest(masterTable,status);
		}
		return null;
	}
	
	@RequestMapping(value="/sendEmailToAdmin")
	public void sendEmailToAdmin(@RequestBody JSONObject jsonObject , HttpServletRequest request){
		HttpSession session = request.getSession(false);
		ResponseDto responseDto = new ResponseDto();
		if(session!=null){
			Object object = session.getAttribute("mastertable");
			MasterTable masterTable = (MasterTable) object;
			emailSender.sendEmail(jsonObject,masterTable);
		}
	}
	
	@RequestMapping(value="/updateSeller")
	public SellerDto updateSeller(@RequestBody MasterTable seller , HttpServletRequest request){
		HttpSession session = request.getSession(false);
		ResponseDto responseDto = new ResponseDto();
		if(session!=null){
			Object object = session.getAttribute("mastertable");
			MasterTable masterTable = (MasterTable) object;
			seller.setMasterTableId(masterTable.getMasterTableId());
			seller = userService.updateUser(seller);
			System.out.println("seller is "+seller);
			return mapper.sellerEntityToDto(seller);
		}
		return null;
	}
}
