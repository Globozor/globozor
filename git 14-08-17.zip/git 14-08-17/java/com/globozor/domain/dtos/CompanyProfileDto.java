package com.globozor.domain.dtos;

public class CompanyProfileDto {
	
	private String logo;
	private String businessType;
	private String exportPercentage;
	private String sourceAcrossMultipleIndustries;
	private String averageLeadTime;
	private String overseasOffice;
	private String descriptioAboutCompany;
	private int    establishment;
	private String   maximumCapacity;
	private String turnOver;
	private String port;
	private long   numberOfEmployees;
	private String addressLine1;
	private String addressLine2;
	private long   pincode;
	private String city;
	private String addressType;
	private String state;
	private String country;
	public String getLogo() {
		return logo;
	}
	public void setLogo(String logo) {
		this.logo = logo;
	}
	public String getBusinessType() {
		return businessType;
	}
	public void setBusinessType(String businessType) {
		this.businessType = businessType;
	}
	public String getExportPercentage() {
		return exportPercentage;
	}
	public void setExportPercentage(String exportPercentage) {
		this.exportPercentage = exportPercentage;
	}
	public String getSourceAcrossMultipleIndustries() {
		return sourceAcrossMultipleIndustries;
	}
	public void setSourceAcrossMultipleIndustries(
			String sourceAcrossMultipleIndustries) {
		this.sourceAcrossMultipleIndustries = sourceAcrossMultipleIndustries;
	}
	public String getAverageLeadTime() {
		return averageLeadTime;
	}
	public void setAverageLeadTime(String averageLeadTime) {
		this.averageLeadTime = averageLeadTime;
	}
	public String getOverseasOffice() {
		return overseasOffice;
	}
	public void setOverseasOffice(String overseasOffice) {
		this.overseasOffice = overseasOffice;
	}
	public String getDescriptioAboutCompany() {
		return descriptioAboutCompany;
	}
	public void setDescriptioAboutCompany(String descriptioAboutCompany) {
		this.descriptioAboutCompany = descriptioAboutCompany;
	}
	public int getEstablishment() {
		return establishment;
	}
	public void setEstablishment(int establishment) {
		this.establishment = establishment;
	}

	public String getMaximumCapacity() {
		return maximumCapacity;
	}
	public void setMaximumCapacity(String maximumCapacity) {
		this.maximumCapacity = maximumCapacity;
	}
	public String getTurnOver() {
		return turnOver;
	}
	public void setTurnOver(String turnOver) {
		this.turnOver = turnOver;
	}
	public String getPort() {
		return port;
	}
	public void setPort(String port) {
		this.port = port;
	}
	public long getNumberOfEmployees() {
		return numberOfEmployees;
	}
	public void setNumberOfEmployees(long numberOfEmployees) {
		this.numberOfEmployees = numberOfEmployees;
	}
	public String getAddressLine1() {
		return addressLine1;
	}
	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}
	public String getAddressLine2() {
		return addressLine2;
	}
	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}
	public long getPincode() {
		return pincode;
	}
	public void setPincode(long pincode) {
		this.pincode = pincode;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getAddressType() {
		return addressType;
	}
	public void setAddressType(String addressType) {
		this.addressType = addressType;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
}
