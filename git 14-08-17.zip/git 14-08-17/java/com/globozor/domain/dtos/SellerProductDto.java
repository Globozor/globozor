package com.globozor.domain.dtos;

import java.util.Set;

public class SellerProductDto {

	private String sellerProductName;
	private String subProductName;
	private String sellerProductDesc;
	private long minimumQuantity;
	private long unitPrice;
	private int priority;
	private Set<String> sellerProductImage;
	
	public String getSellerProductName() {
		return sellerProductName;
	}
	public void setSellerProductName(String sellerProductName) {
		this.sellerProductName = sellerProductName;
	}
	public String getSubProductName() {
		return subProductName;
	}
	public void setSubProductName(String subProductName) {
		this.subProductName = subProductName;
	}
	public String getSellerProductDesc() {
		return sellerProductDesc;
	}
	public void setSellerProductDesc(String sellerProductDesc) {
		this.sellerProductDesc = sellerProductDesc;
	}
	public long getMinimumQuantity() {
		return minimumQuantity;
	}
	public void setMinimumQuantity(long minimumQuantity) {
		this.minimumQuantity = minimumQuantity;
	}
	public long getUnitPrice() {
		return unitPrice;
	}
	public void setUnitPrice(long unitPrice) {
		this.unitPrice = unitPrice;
	}
	public int getPriority() {
		return priority;
	}
	public void setPriority(int priority) {
		this.priority = priority;
	}
	public Set<String> getSellerProductImage() {
		return sellerProductImage;
	}
	public void setSellerProductImage(Set<String> sellerProductImage) {
		this.sellerProductImage = sellerProductImage;
	}
}
